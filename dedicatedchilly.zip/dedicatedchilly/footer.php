<?php query_posts('category_name=hosting-panel' . '&showposts=1' . '&order=ASC') ; ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php the_content(); ?>
<?php endwhile; ?>
<?php endif; ?>
<!-- BEGIN FOOTER -->

<div id="footer" style="clear:both;width:990px;border:solid 0px #090!important; float:left;">
  <div id="footerWidgets">
    <div id="footerWidgetsInner" style="position:relative">
      <div class="boxFooter">
        <ul class="foootermenu">
          <?php 
        $locations = get_registered_nav_menus();
        $menus = wp_get_nav_menus();
        $menu_locations = get_nav_menu_locations();
        
        $location_id = 'footer_menu1';
        
        if (isset($menu_locations[ $location_id ])) 
		{			
			foreach ($menus as $menu) 
			{
			
				if ($menu->term_id == $menu_locations[ $location_id ]) 
				{
					echo '<h2>'.$menu->name.'</h2>';
					// Get the items for this menu
					$menu_items = wp_get_nav_menu_items($menu);
					
					foreach ( $menu_items as $item )
					{
						
						$id = get_post_meta( $item->ID, '_menu_item_object_id', true );
						$page = get_page( $id );
						//$link = get_page_link( $id ); ?>
          <li><a href="<?php echo $item->url; ?>" > <?php echo $page->post_title; ?> </a></li>
          <?php 
					}
					
					break;
				}
			}
        }    
        ?>
        </ul>
      </div>
      <div class="boxFooter">
        <ul class="foootermenu">
          <?php 
        $locations = get_registered_nav_menus();
        $menus = wp_get_nav_menus();
        $menu_locations = get_nav_menu_locations();
        
        $location_id = 'footer_menu2';
        
        if (isset($menu_locations[ $location_id ])) 
		{			
			foreach ($menus as $menu) 
			{
			
				if ($menu->term_id == $menu_locations[ $location_id ]) 
				{
					echo '<h2>'.$menu->name.'</h2>';
					// Get the items for this menu
					$menu_items = wp_get_nav_menu_items($menu);
					
					foreach ( $menu_items as $item )
					{
						
						$id = get_post_meta( $item->ID, '_menu_item_object_id', true );
						$page = get_page( $id );
						//$link = get_page_link( $id ); ?>
          <li><a href="<?php echo $item->url; ?>" > <?php echo $page->post_title; ?> </a></li>
          <?php 
					}
					
					break;
				}
			}
        }    
        ?>
        </ul>
      </div>
      <div class="boxFooter">
        <ul class="foootermenu">
          <?php 
        $locations = get_registered_nav_menus();
        $menus = wp_get_nav_menus();
        $menu_locations = get_nav_menu_locations();
        
        $location_id = 'footer_menu3';
        
        if (isset($menu_locations[ $location_id ])) 
		{			
			foreach ($menus as $menu) 
			{
			
				if ($menu->term_id == $menu_locations[ $location_id ]) 
				{
					echo '<h2>'.$menu->name.'</h2>';
					// Get the items for this menu
					$menu_items = wp_get_nav_menu_items($menu);
					
					foreach ( $menu_items as $item )
					{
						
						$id = get_post_meta( $item->ID, '_menu_item_object_id', true );
						$page = get_page( $id );
						//$link = get_page_link( $id ); ?>
          <li><a href="<?php echo $item->url; ?>" > <?php echo $page->post_title; ?> </a></li>
          <?php 
					}
					
					break;
				}
			}
        }    
        ?>
        </ul>
      </div>
      <div class="boxFooter">
        <?php query_posts('category_name=datacenter' . '&showposts=1' . '&order=ASC') ; ?>
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php the_content(); ?>
        <?php endwhile; ?>
        <?php endif; ?>
      </div>
      <?php query_posts('category_name=company-info' . '&showposts=1' . '&order=ASC') ; ?>
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php the_content(); ?>
        <?php endwhile; ?>
        <?php endif; ?>
      <div id="copyright">
        <?php if (get_option('Theme_copyright') <> ""){
						echo stripslashes(stripslashes(get_option('Theme_copyright')));
						}else{
						echo 'Just go to Theme Options Page and edit copyright text';
						}?><br />
                        <?php 
        $locations = get_registered_nav_menus();
        $menus = wp_get_nav_menus();
        $menu_locations = get_nav_menu_locations();
        
        $location_id = 'footer_last';
        
        if (isset($menu_locations[ $location_id ])) 
		{			
			foreach ($menus as $menu) 
			{
			
				if ($menu->term_id == $menu_locations[ $location_id ]) 
				{
					// Get the items for this menu
					$menu_items = wp_get_nav_menu_items($menu);
					
					foreach ( $menu_items as $item )
					{
						
						$id = get_post_meta( $item->ID, '_menu_item_object_id', true );
						$page = get_page( $id );
						//$link = get_page_link( $id ); ?>
          <a href="<?php echo $item->url; ?>"><?php echo $page->post_title; ?></a>  / 
          <?php 
					}
					
					break;
				}
			}
        }    
        ?>

        <div id="Logobottom"> Theme Designed By:<a target="_blank" href="http://www.themechilly.com/"> <img src="<?php echo get_template_directory_uri(); ?>/images/themechilly.png" border="0" alt="" /></a> </div>
      </div>
      
      <!-- END COPYRIGHT --> 
    </div>
  </div>
</div>
<!-- END FOOTER -->
</div>
</div>
<!-- END MAINWRAPPER -->
<?php if (get_option(' Theme_analytics') <> "") { 
		echo stripslashes(stripslashes(get_option('Theme_analytics'))); 
	} ?>
<?php wp_footer(); ?>
</body></html>