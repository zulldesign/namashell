<?php get_header(); ?>
<?php
/*
Template Name: Page with SideBar
*/
?>

<!-- begin colLeft -->
	<div id="colLeft" style="border:solid 0px;margin-right:0px; width:990px; background:#FFF; border-radius:10px 10px 10px 10px;">    
    <div class="innerheader">
    <div class="headerimage"><?php the_post_thumbnail('large');?></div>
    <h1 class="innerh1" style="color:#011a23;text-shadow:none!important;text-transform:uppercase; font-size:30px;"><?php the_title(); ?></h1>    
    </div>
    <div class="breadcrumb"><?php if (function_exists('chilly_breadcrumbs')) chilly_breadcrumbs(); ?>    	
    </div>
    
    <div class="fullpage">
	<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery-1.js"></script>		
        <div class="pagecolumn">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<?php the_content(); ?>

        <?php endwhile;?>
		<?php endif; ?>
        
        
<script type="text/javascript" language="javascript">
jQuery().ready(function(){jQuery(".trigger").click(function(){jQuery(this).parent().next(".positiontxt").slideToggle();return(false)});jQuery(".trigger").toggle(function(){jQuery(this).addClass("open")},function(){jQuery(this).removeClass("open")});});
</script>
</div>
<?php get_sidebar(); ?>	
</div>
        
        

</div>

 <!-- END CONTENT -->
</div><!-- END WRAPPER --> 
<?php get_footer(); ?>