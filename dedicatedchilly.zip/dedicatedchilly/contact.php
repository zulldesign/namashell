<?php
/*
Template Name: Contact
*/
?>

<?php get_header(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.form.js"></script>
 <script type="text/javascript">
			 
			 /* $('#contact').ajaxForm(function(data) {
				 if (data==1){
					 $('#success').fadeIn("slow");
					 $('#bademail').fadeOut("slow");
					 $('#badserver').fadeOut("slow");
					 $('#contact').resetForm();
					 }
				 else if (data==2){
						 $('#badserver').fadeIn("slow");
					  }
				 else if (data==3)
					{
					 $('#bademail').fadeIn("slow");
					}
					});*/
				 
				 function submit_form_c()
				 {
					  $('#success').fadeOut("slow");
					 $('#bademail').fadeOut("slow");
					 $('#badserver').fadeOut("slow");
									 
					 var a=$('#nameinput').val();
					 var b=$('#emailinput').val();
				 	var c=$('#commentinput').val();
				 var regExpr = new RegExp(/^((([a-z]|\d|[-_]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))))@((([a-z])|(([a-z])*([a-z])))\.)+(([a-z])|(([a-z])*([a-z])))$/i);

				 
				 if(a=='' || b=='' || c=='' || !regExpr.test(b))
				 {
					 $('#bademail').fadeIn("slow");
				 }
				 else
				 {
					 
					 var form=$('#contact');
					$.ajax
					({
							type: "POST",
							url: "<?php echo get_template_directory_uri(); ?>/sendmail.php",
							data: form.serialize(),
							cache: false,
							success: function(data1)
							{
								 if (data1==1){
									 $('#success').fadeIn("slow");
									 $('#bademail').fadeOut("slow");
									 $('#badserver').fadeOut("slow");
									 $('#nameinput').val('');
									 $('#emailinput').val('');
									 $('#commentinput').val('');
								 }
								 else if (data1==2){
										 $('#badserver').fadeIn("slow");
									  }
								 else if (data1==3)
									{
									 $('#bademail').fadeIn("slow");
									}
							}
					});
					 
				 }
				 }
				 
	</script>
<!-- begin colLeft -->
	<div id="colLeft" style="border:solid 0px;margin-right:0px; width:990px; background:#FFF; border-radius:10px 10px 10px 10px; ">   
    <div class="innerheader">
    <div class="headerimage"><?php the_post_thumbnail('large');?></div>
    <h1 class="innerh1" style="color:#011a23;text-shadow:none!important;text-transform:uppercase; font-size:30px;"><?php the_title(); ?></h1>    
    </div>
    <div class="breadcrumb"><?php if (function_exists('chilly_breadcrumbs')) chilly_breadcrumbs(); ?>    	
    </div>
    
    <div class="fullpage">
	
    <div class="pagecolumn">
    
    <h3>Contact Us</h3>
    
    <div style="float:left; border:solid 0px; width:320px; margin-top:10px;">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>		
	<?php the_content(); ?>
	<?php endwhile; ?>
	<?php endif; ?>
    </div>
    
    <div style="float:right; border:solid 0px; margin-top:15px;">
    <div style="padding:10px;" class="formcontactbox">
			<p id="success" class="successmsg" style="display:none;">Your email has been sent! Thank you!</p>
			<p id="bademail" class="errormsg" style="display:none;">Please enter your name, a message and a valid email address.</p>
			<p id="badserver" class="errormsg" style="display:none;">Your email failed. Try again later.</p>

			<form id="contact" action="<?php echo get_template_directory_uri(); ?>/sendmail.php" method="post">
			<label for="name">Your name: *</label>
				<input type="text" id="nameinput" name="name" value=""/>
			<label for="email">Your email: *</label>
				<input type="text" id="emailinput" name="email" value=""/>
			<label for="comment">Your message: *</label>
				<textarea cols="10" rows="7" id="commentinput" style="width:300px" name="comment"></textarea><br />
			<input type="button" onclick="submit_form_c()" id="submitinput" name="submit" class="submit" value="SEND MESSAGE"/>
			<input type="hidden" id="receiver" name="receiver" value="<?php echo strhex(get_option('Theme_contact_email')); ?>"/>
			</form>
    </div>
    </div>
    
    <div style="float:left;clear:both; width:690px; margin-top:20px;"><?php echo stripslashes(stripslashes(get_option('Theme_contact_text')))?></div>
            
    
	</div>           
	
	<?php get_sidebar(); ?>				
	</div>
  

</div> <!-- END CONTENT -->
</div><!-- END WRAPPER --> 
<?php get_footer(); ?>


