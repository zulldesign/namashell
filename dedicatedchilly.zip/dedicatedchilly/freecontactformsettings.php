
<?php

$email_to = preg_replace("([\r\n])", "", hexstr($_POST['receiver'])); // your email address
$email_subject = "Quote Form"; // email subject line
$thankyou = home_url( '/' ) . "/thankyou"; // thank you page

// if you update the question on the form -
// you need to update the questions answer below
$antispam_answer = "25";

?>