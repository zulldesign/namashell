<?php get_header(); ?>
<?php
/*
Template Name: Full Page
*/
?>

<!-- begin colLeft -->

<div id="colLeft" style="border:solid 0px;margin-right:0px; width:990px; background:#FFF; border-radius:10px 10px 10px 10px; ">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <?php the_excerpt();?>
  
  <!--<div class="innerheader">
    <div class="headerimage"><?php the_post_thumbnail('large');?></div>
    <h1 class="innerh1" style="color:#011a23;text-shadow:none!important;text-transform:uppercase; font-size:30px;"><?php the_title(); ?></h1>    
    </div>-->
  
  <div class="breadcrumb">
    <?php if (function_exists('chilly_breadcrumbs')) chilly_breadcrumbs(); ?>
  </div>
  <div class="fullpage">
    <?php the_content(); ?>
  </div>
  <?php endwhile; else: ?>
  <p>
    <?php _e('Sorry, no posts matched your criteria.', 'cloudchilly'); ?>
  </p>
  <?php endif; ?>
</div>
<!-- end colleft -->

<?php //get_sidebar(); ?>
</div>
<!-- END CONTENT --> 
<!-- END WRAPPER -->

<?php get_footer(); ?>
