<?php get_header(); ?>

<div class="homebanner" style="clear:both">
  <?php query_posts('category_name=home-banner' . '&showposts=6' . '&order=ASC') ; ?>
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <?php the_content(); ?>
    <?php endwhile; ?>
    <?php endif; ?>
  </div>
</div>
<div class="contentwrap">
  <div class="maincol">
    <?php query_posts('category_name=welcome-intro' . '&showposts=1' . '&order=ASC') ; ?>
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
      <?php the_content(); ?>
      <?php endwhile; ?>
      <?php endif; ?>
    </div>
    <?php query_posts('category_name=home-dedicated-plan' . '&showposts=1' . '&order=ASC') ; ?>
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
      <?php the_content(); ?>
      <?php endwhile; ?>
      <?php endif; ?>
    </div>
    <div class="homenews">
      <h2>
        <?php $cat_obj = get_category_by_slug( 'latest-news' ); echo $cat_obj->name; ?>
      </h2>
      <?php if(get_option('Theme_features_actions')!="no") {?>
      <?php query_posts('category_name=latest-news' . '&showposts=2' . '&order=ASC') ; ?>
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <div id="post-<?php the_ID(); ?>" <?php post_class(); ?> ></div>
      <h1><a href="<?php the_permalink() ?>">
        <?php short_title('...', 40); ?>
        </a></h1>
      <?php the_excerpt(10); ?>
      <?php endwhile; ?>
      <?php endif; ?>
      <?php } ?>
    </div>
    <div class="hometestimonials">
      <h2>
        <?php $cat_obj = get_category_by_slug( 'testimonials' ); echo $cat_obj->name; ?>
      </h2>
      <script type="text/javascript">var root="";var toh=40;</script>
      <?php if(get_option('Theme_features_actions')!="no") {?>
      <?php query_posts('category_name=testimonials' . '&showposts=1' . '&order=ASC') ; ?>
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <div id="post-<?php the_ID(); ?>" <?php post_class(); ?> ></div>
      <?php the_content(); ?>
      <?php endwhile; ?>
      <?php endif; ?>
      <?php } ?>
      <script type="text/javascript">

		// Add a script element as a child of the body

		function downloadJSAtOnload() {

		var element = document.createElement("script");

		element.src = "<?php echo get_template_directory_uri(); ?>/js/testimonials.js";

		document.body.appendChild(element);

		}

		 // Check for browser support of event handling capability

		if (window.addEventListener)

		window.addEventListener("load", downloadJSAtOnload, false);

		else if (window.attachEvent)

		window.attachEvent("onload", downloadJSAtOnload);

		else window.onload = downloadJSAtOnload;

		</script> 
    </div>
  </div>
  <div class="homesidebar">
    <?php query_posts('category_name=home-sidebar' . '&showposts=4' . '&order=DESC') ; ?>
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="postsgap">
      <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <form style="float:left" name="freecontactform" method="post" action="<?php echo get_template_directory_uri(); ?>/freecontactformprocess.php" onSubmit="return validate.check(this)">
          <?php the_content(); ?>
          <input type="hidden" id="receiver" name="receiver" value="<?php echo strhex(get_option('Theme_quote_email')); ?>"/>
        </form>
      </div>
    </div>
    <?php endwhile; ?>
    <?php endif; ?>
    <script language="javascript" type="text/javascript">

	  required.add('Full_Name','NOT_EMPTY','Full Name');

	  required.add('Email_Address','EMAIL','Email Address');

	  required.add('Subject_Name','NOT_EMPTY','Subject Name');

	  required.add('Your_Message','NOT_EMPTY','Your Message');

	  required.add('AntiSpam','NOT_EMPTY','Anti-Spam Question');

	  </script> 
  </div>
</div>
</div>
<?php get_footer(); ?>
