<?php



function mod_mce($initArray) {

	$initArray['verify_html'] = false;

	return $initArray;

}

add_filter('tiny_mce_before_init', 'mod_mce');



function get_post_by_name($post_name, $post_type = 'post', $output = OBJECT) {

    global $wpdb;

    $post = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_name = %s AND post_type= %s", $post_name, $post_type ));

    if ( $post ) return get_post($post, $output);

    return null;

}



add_action( 'edit_page_form', 'pe_add_box');

add_action('init', 'pe_init');



function pe_init() {

	if(function_exists("add_post_type_support")) //support 3.1 and greater

	{

		add_post_type_support( 'page', 'excerpt' );

	}

}



function pe_page_excerpt_meta_box($post) {

?>

<label class="hidden" for="excerpt"><?php _e('Excerpt') ?></label><textarea rows="1" cols="40" name="excerpt" tabindex="6" id="excerpt"><?php echo $post->post_excerpt ?></textarea>

<p><?php _e('Excerpts are optional hand-crafted summaries of your content. You can <a href="http://codex.wordpress.org/Template_Tags/the_excerpt" target="_blank">use them in your template</a>'); ?></p>

<?php

}





function pe_add_box()

{

	if(!function_exists("add_post_type_support")) //legacy

	{		add_meta_box('postexcerpt', __('Page Excerpt'), 'pe_page_excerpt_meta_box', 'page', 'advanced', 'core');

	}

}



/*******************************

 MANAGE PARENT PAGE CATEGORY SUPPORT

********************************/



function is_parentpage($pid) {      // $pid = The ID of the page we're looking for pages underneath

    global $post;         // load details about this page

    $anc = get_post_ancestors( $post->ID );

	if (is_page()) {

    foreach($anc as $ancestor) {

        if(is_page() && $ancestor == $pid) {

            return true;

        }

    }

	}

    if(is_page()&&(is_page($pid))) 

               return true;   // we're at the page or at a sub page

    else 

               return false;  // we're elsewhere

};





$string = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $string);



// This theme allows users to set a custom background

add_custom_background();



// Add a way for the custom header to be styled in the admin panel that controls

// custom headers. See twentyeleven_admin_header_style(), below.

add_custom_image_header( 'cloudchilly_admin_header_image', 'cloudchilly_admin_header_image', 'cloudchilly_admin_header_image' );



if ( ! function_exists( 'cloudchilly_admin_header_image' ) ) :

/**

 * Custom header image markup displayed on the Appearance > Header admin panel.

 *

 * Referenced via add_custom_image_header() in twentyeleven_setup().

 *

 * @since Twenty Eleven 1.0

 */

function cloudchilly_admin_header_image() { ?>

	

<?php }

endif; // twentyeleven_admin_header_image



// This theme styles the visual editor with editor-style.css to match the theme style.

add_editor_style();





load_theme_textdomain( 'cloudchilly', TEMPLATEPATH.'/localization' );



$locale = get_locale();

$locale_file = TEMPLATEPATH."/localization/$locale.php";

if (is_readable($locale_file))

    require_once($locale_file);





// Add default posts and comments RSS feed links to head

	add_theme_support( 'automatic-feed-links' );



/**

 * Set the content width based on the theme's design and stylesheet.

 */

if ( ! isset( $content_width ) )

	$content_width = 960;





/*******************************

 REMOVE CATEGORY SUPPORT

********************************/



// Refresh rules on activation/deactivation/category changes

register_activation_hook(__FILE__,'no_category_base_refresh_rules');

add_action('created_category','no_category_base_refresh_rules');

add_action('edited_category','no_category_base_refresh_rules');

add_action('delete_category','no_category_base_refresh_rules');

function no_category_base_refresh_rules() {

	global $wp_rewrite;

	$wp_rewrite->flush_rules();

}

register_deactivation_hook(__FILE__,'no_category_base_deactivate');

function no_category_base_deactivate() {

	remove_filter('category_rewrite_rules', 'no_category_base_rewrite_rules'); // We don't want to insert our custom rules again

	no_category_base_refresh_rules();

}



// Remove category base

add_action('init', 'no_category_base_permastruct');

function no_category_base_permastruct() {

	global $wp_rewrite;

	$wp_rewrite->extra_permastructs['category'][0] = '%category%';

}



// Add our custom category rewrite rules

add_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');

function no_category_base_rewrite_rules($category_rewrite) {

	//var_dump($category_rewrite); // For Debugging

	

	$category_rewrite=array();

	$categories=get_categories(array('hide_empty'=>false));

	foreach($categories as $category) {

		$category_nicename = $category->slug;

		if ( $category->parent == $category->cat_ID ) // recursive recursion

			$category->parent = 0;

		elseif ($category->parent != 0 )

			$category_nicename = get_category_parents( $category->parent, false, '/', true ) . $category_nicename;

		$category_rewrite['('.$category_nicename.')/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$'] = 'index.php?category_name=$matches[1]&feed=$matches[2]';

		$category_rewrite['('.$category_nicename.')/page/?([0-9]{1,})/?$'] = 'index.php?category_name=$matches[1]&paged=$matches[2]';

		$category_rewrite['('.$category_nicename.')/?$'] = 'index.php?category_name=$matches[1]';

	}

	// Redirect support from Old Category Base

	global $wp_rewrite;

	$old_category_base = get_option('category_base') ? get_option('category_base') : 'category';

	$old_category_base = trim($old_category_base, '/');

	$category_rewrite[$old_category_base.'/(.*)$'] = 'index.php?category_redirect=$matches[1]';

	

	//var_dump($category_rewrite); // For Debugging

	return $category_rewrite;

}



// Add 'category_redirect' query variable

add_filter('query_vars', 'no_category_base_query_vars');

function no_category_base_query_vars($public_query_vars) {

	$public_query_vars[] = 'category_redirect';

	return $public_query_vars;

}

// Redirect if 'category_redirect' is set

add_filter('request', 'no_category_base_request');

function no_category_base_request($query_vars) {

	//print_r($query_vars); // For Debugging

	if(isset($query_vars['category_redirect'])) {

		$catlink = trailingslashit(home_url( 'home' )) . user_trailingslashit( $query_vars['category_redirect'], 'category' );

		status_header(301);

		header("Location: $catlink");

		exit();

	}

	return $query_vars;

}



/*******************************

 BREADCRUMB SUPPORT

********************************/



function chilly_breadcrumbs() {

 

  $showOnHome = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show

  $delimiter = '<img class="bchomeicon" src="'.get_template_directory_uri().'/images/bc-sep.png" border="0" width="12" height="33" alt="" />'; // delimiter between crumbs

  $home = '<img class="bchomeicon" src="'.get_template_directory_uri().'/images/homeicon.png" border="0" width="16" height="14" alt="" />'; // text for the 'Home' link

  $showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show

  $before = '<span class="current">'; // tag before the current crumb

  $after = '</span>'; // tag after the current crumb

 

  global $post;

  $homeLink = home_url('/');

 

  if (is_home() || is_front_page()) {

 

    if ($showOnHome == 1) echo '<div id="crumbs"><a href="' . $homeLink . '">' . $home . '</a></div>';

 

  } else {

 

    echo '<div id="crumbs"><a href="' . $homeLink . '">' . $home . '</a> ' . $delimiter . ' ';

 

    if ( is_category() ) {

      global $wp_query;

      $cat_obj = $wp_query->get_queried_object();

      $thisCat = $cat_obj->term_id;

      $thisCat = get_category($thisCat);

      $parentCat = get_category($thisCat->parent);

      if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));

      echo $before . 'Archive by category "' . single_cat_title('', false) . '"' . $after;

 

    } elseif ( is_search() ) {

      echo $before . 'Search results for "' . get_search_query() . '"' . $after;

 

    } elseif ( is_day() ) {

      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';

      echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';

      echo $before . get_the_time('d') . $after;

 

    } elseif ( is_month() ) {

      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';

      echo $before . get_the_time('F') . $after;

 

    } elseif ( is_year() ) {

      echo $before . get_the_time('Y') . $after;

 

    } elseif ( is_single() && !is_attachment() ) {

      if ( get_post_type() != 'post' ) {

        $post_type = get_post_type_object(get_post_type());

        $slug = $post_type->rewrite;

        echo '<a href="' . $homeLink . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a> ' . $delimiter . ' ';

        if ($showCurrent == 1) echo $before . get_the_title() . $after;

      } else {

        $cat = get_the_category(); $cat = $cat[0];

        echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');

        if ($showCurrent == 1) echo $before . get_the_title() . $after;

      }

 

    } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {

      $post_type = get_post_type_object(get_post_type());

      echo $before . $post_type->labels->singular_name . $after;

 

    } elseif ( is_attachment() ) {

      $parent = get_post($post->post_parent);

      $cat = get_the_category($parent->ID); $cat = $cat[0];

      echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');

      echo '<a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' ';

      if ($showCurrent == 1) echo $before . get_the_title() . $after;

 

    } elseif ( is_page() && !$post->post_parent ) {

      if ($showCurrent == 1) echo $before . get_the_title() . $after;

 

    } elseif ( is_page() && $post->post_parent ) {

      $parent_id  = $post->post_parent;

      $breadcrumbs = array();

      while ($parent_id) {

        $page = get_page($parent_id);

        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';

        $parent_id  = $page->post_parent;

      }

      $breadcrumbs = array_reverse($breadcrumbs);

      foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';

      if ($showCurrent == 1) echo $before . get_the_title() . $after;

 

    } elseif ( is_tag() ) {

      echo $before . 'Posts tagged "' . single_tag_title('', false) . '"' . $after;

 

    } elseif ( is_author() ) {

       global $author;

      $userdata = get_userdata($author);

      echo $before . 'Articles posted by ' . $userdata->display_name . $after;

 

    } elseif ( is_404() ) {

      echo $before . 'Error 404' . $after;

    }

 

    if ( get_query_var('paged') ) {

      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';

      echo __('Page', 'cloudchilly') . ' ' . get_query_var('paged');

      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';

    }

 

    echo '</div>';

 

  }

}

 // end chilly_breadcrumbs()



/*******************************

 MENUS SUPPORT

********************************/

/*if ( function_exists( 'wp_nav_menu' ) ){

	if (function_exists('add_theme_support')) {

		add_theme_support('nav-menus');

		add_action( 'init', 'register_my_menus' );

		function register_my_menus() {

			register_nav_menus(

				array(

					'main-menu' => __( 'Main Menu', 'cloudchilly' )

				)

			);

		}

	}

}*/



// Add Your Menu Locations

function register_my_menus() {

  register_nav_menus(

    array(  

		'main-menu' => __( 'Main Menu', 'cloudchilly' ),

    	'footer_menu1' => __( 'Footer Menu 1' ),

		'footer_menu2' => __( 'Footer Menu 2' ),

		'footer_menu3' => __( 'Footer Menu 3' ),

		'footer_last' => __( 'Footer Last' ),

    )

  );

} 

add_action( 'init', 'register_my_menus' );





/* CallBack functions for menus in case of earlier than 3.0 Wordpress version or if no menu is set yet*/



function primarymenu(){ ?>



<div id="mainMenu" class="ddsmoothmenu">

  <ul>

    <?php wp_list_pages('title_li='); ?>

    <?php wp_list_categories('hide_empty=1&exclude=1&title_li='); ?>

  </ul>

</div>

<?php }



/*******************************

 THUMBNAIL SUPPORT

********************************/



add_theme_support( 'post-thumbnails' );

set_post_thumbnail_size( 300, 200, true );



/* Get the thumb original image full url */



function get_thumb_urlfull ($postID) {

$image_id = get_post_thumbnail_id($post);  

$image_url = wp_get_attachment_image_src($image_id,'large');  

$image_url = $image_url[0]; 

return $image_url;

}



/*******************************

 EXCERPT LENGTH ADJUST

********************************/



function home_excerpt_length($length) {

	return 10;

}

add_filter('excerpt_length', 'home_excerpt_length');



function short_title($after = '', $length) {

	$mytitle = get_the_title();

	if ( strlen($mytitle) > $length ) {

	$mytitle = substr($mytitle,0,$length);

	echo $mytitle . $after;

	} else {

	echo $mytitle;

	}

}



/*******************************

 WIDGETS AREAS

********************************/



if ( function_exists('register_sidebar') )

register_sidebar(array(

	'name' => 'Sidebar',

	'before_widget' => '<div class="rightBox">',

	'after_widget' => '</div>',

	'before_title' => '<h2>',

	'after_title' => '</h2>',

));



register_sidebar(array(

	'name' => 'Footer',

	'before_widget' => '<div class="boxFooter">',

	'after_widget' => '</div>',

	'before_title' => '<h2>',

	'after_title' => '</h2>',

));



register_sidebar(array(

	'name' => 'TopHeader',

	'before_widget' => '<div class="greyheader">',

	'after_widget' => '</div>',

	'before_title' => '<h2>',

	'after_title' => '</h2>',

));





register_sidebar(array(

	'name' => 'TopRightLinks',

	'before_widget' => '<div class="toprightlinks">',

	'after_widget' => '</div>',

	'before_title' => '<h2>',

	'after_title' => '</h2>',

));



register_sidebar(array(

	'name' => 'CompanyInfo',

	'before_widget' => '<div class="helplinks">',

	'after_widget' => '</div>',

	'before_title' => '<h2>',

	'after_title' => '</h2>',

));





register_sidebar(array(

	'name' => 'HomeDedicatedPlans',

	'before_widget' => '<div class="newssection">',

	'after_widget' => '</div>',

	'before_title' => '<h2>',

	'after_title' => '</h2>',

));



register_sidebar(array(

	'name' => 'HostingPanels',

	'before_widget' => '<div class="hostingpanel">',

	'after_widget' => '</div>',

	'before_title' => '<h2>',

	'after_title' => '</h2>',

));

	

/*******************************

 PAGINATION

********************************

 * Retrieve or display pagination code.

 *

 * The defaults for overwriting are:

 * 'page' - Default is null (int). The current page. This function will

 *      automatically determine the value.

 * 'pages' - Default is null (int). The total number of pages. This function will

 *      automatically determine the value.

 * 'range' - Default is 3 (int). The number of page links to show before and after

 *      the current page.

 * 'gap' - Default is 3 (int). The minimum number of pages before a gap is 

 *      replaced with ellipses (...).

 * 'anchor' - Default is 1 (int). The number of links to always show at begining

 *      and end of pagination

 * 'before' - Default is '<div class="emm-paginate">' (string). The html or text 

 *      to add before the pagination links.

 * 'after' - Default is '</div>' (string). The html or text to add after the

 *      pagination links.

 * 'title' - Default is '__('Pages:', 'cloudchilly')' (string). The text to display before the

 *      pagination links.

 * 'next_page' - Default is '__('&raquo;', 'cloudchilly')' (string). The text to use for the 

 *      next page link.

 * 'previous_page' - Default is '__('&laquo', 'cloudchilly')' (string). The text to use for the 

 *      previous page link.

 * 'echo' - Default is 1 (int). To return the code instead of echo'ing, set this

 *      to 0 (zero).

 *

 * @author Eric Martin <eric@ericmmartin.com>

 * @copyright Copyright (c) 2009, Eric Martin

 * @version 1.0

 *

 * @param array|string $args Optional. Override default arguments.

 * @return string HTML content, if not displaying.

 */

 

function emm_paginate($args = null) {

	$defaults = array(

		'page' => null, 'pages' => null, 

		'range' => 3, 'gap' => 3, 'anchor' => 1,

		'before' => '<div class="emm-paginate">', 'after' => '</div>',

		'title' => __('Pages:', 'cloudchilly'),

		'nextpage' => __('&raquo;', 'cloudchilly'), 'previouspage' => __('&laquo', 'cloudchilly'),

		'echo' => 1

	);



	$r = wp_parse_args($args, $defaults);

	extract($r, EXTR_SKIP);



	if (!$page && !$pages) {

		global $wp_query;



		$page = get_query_var('paged');

		$page = !empty($page) ? intval($page) : 1;



		$posts_per_page = intval(get_query_var('posts_per_page'));

		$pages = intval(ceil($wp_query->found_posts / $posts_per_page));

	}

	

	$output = "";

	if ($pages > 1) {	

		$output .= "$before<span class='emm-title'>$title</span>";

		$ellipsis = "<span class='emm-gap'>...</span>";



		if ($page > 1 && !empty($previouspage)) {

			$output .= "<a href='" . get_pagenum_link($page - 1) . "' class='emm-prev'>$previouspage</a>";

		}

		

		$min_links = $range * 2 + 1;

		$block_min = min($page - $range, $pages - $min_links);

		$block_high = max($page + $range, $min_links);

		$left_gap = (($block_min - $anchor - $gap) > 0) ? true : false;

		$right_gap = (($block_high + $anchor + $gap) < $pages) ? true : false;



		if ($left_gap && !$right_gap) {

			$output .= sprintf('%s%s%s', 

				emm_paginate_loop(1, $anchor), 

				$ellipsis, 

				emm_paginate_loop($block_min, $pages, $page)

			);

		}

		else if ($left_gap && $right_gap) {

			$output .= sprintf('%s%s%s%s%s', 

				emm_paginate_loop(1, $anchor), 

				$ellipsis, 

				emm_paginate_loop($block_min, $block_high, $page), 

				$ellipsis, 

				emm_paginate_loop(($pages - $anchor + 1), $pages)

			);

		}

		else if ($right_gap && !$left_gap) {

			$output .= sprintf('%s%s%s', 

				emm_paginate_loop(1, $block_high, $page),

				$ellipsis,

				emm_paginate_loop(($pages - $anchor + 1), $pages)

			);

		}

		else {

			$output .= emm_paginate_loop(1, $pages, $page);

		}



		if ($page < $pages && !empty($nextpage)) {

			$output .= "<a href='" . get_pagenum_link($page + 1) . "' class='emm-next'>$nextpage</a>";

		}



		$output .= $after;

	}



	if ($echo) {

		echo $output;

	}



	return $output;

}



/**

 * Helper function for pagination which builds the page links.

 *

 * @access private

 *

 * @author Eric Martin <eric@ericmmartin.com>

 * @copyright Copyright (c) 2009, Eric Martin

 * @version 1.0

 *

 * @param int $start The first link page.

 * @param int $max The last link page.

 * @return int $page Optional, default is 0. The current page.

 */

function emm_paginate_loop($start, $max, $page = 0) {

	$output = "";

	for ($i = $start; $i <= $max; $i++) {

		$output .= ($page === intval($i)) 

			? "<span class='emm-page emm-current'>$i</span>" 

			: "<a href='" . get_pagenum_link($i) . "' class='emm-page'>$i</a>";

	}

	return $output;

}



function post_is_in_descendant_category( $cats, $_post = null )

{

	foreach ( (array) $cats as $cat ) {

		// get_term_children() accepts integer ID only

		$descendants = get_term_children( (int) $cat, 'category');

		if ( $descendants && in_category( $descendants, $_post ) )

			return true;

	}

	return false;

}



/*******************************

 CUSTOM COMMENTS

********************************/



function mytheme_comment($comment, $args, $depth) {

   $GLOBALS['comment'] = $comment; ?>

<li <?php comment_class('clearfix'); ?> id="li-comment-<?php comment_ID() ?>">

  <div class="gravatar"> <?php echo get_avatar($comment,$size='50',$default='http://www.gravatar.com/avatar/61a58ec1c1fba116f8424035089b7c71?s=32&d=&r=G' ); ?>

    <div class="gravatar_mask"></div>

  </div>

  <div id="comment-<?php comment_ID(); ?>">

    <div class="comment-meta commentmetadata clearfix"> <?php printf(__('<strong>%s</strong>', 'cloudchilly'), get_comment_author_link()) ?>

      <?php edit_comment_link(__('(Edit)', 'cloudchilly'),'  ','') ?>

      <span><?php printf(__('%1$s at %2$s', 'cloudchilly'), get_comment_date(),  get_comment_time()) ?> </span> </div>

    <div class="text">

      <?php comment_text() ?>

    </div>

    <?php if ($comment->comment_approved == '0') : ?>

    <em>

    <?php _e('Your comment is awaiting moderation.', 'cloudchilly') ?>

    </em> <br />

    <?php endif; ?>

    <div class="reply">

      <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>

    </div>

  </div>

  <?php }



/*******************************

  THEME OPTIONS PAGE

********************************/



add_action('admin_menu', 'Theme_theme_page');

function Theme_theme_page ()

{

	if ( count($_POST) > 0 && isset($_POST['Theme_settings']) )

	{

		$options = array ('style','logo_img', 'logo_alt','contact_email','quote_email','contact_text','cufon','colorscheme','linkedin_link','twitter_user','latest_tweet','facebook_link','keywords','description','analytics','copyright','home_box1','home_box1_link','home_box2','home_box2_link','home_box3','home_box3_link','blurb_enable','blurb_text','blurb_link','blurb_page', 'footer_actions','client_actions','services_actions','actions_hide','portfolio','blog','slider','gplus_link','features_actions');

		

		foreach ( $options as $opt )

		{

			delete_option ( 'Theme_'.$opt, $_POST[$opt] );

			add_option ( 'Theme_'.$opt, $_POST[$opt] );	

		}			

		 

	}

	add_theme_page(__('Theme Options', 'cloudchilly'), __('Theme Options', 'cloudchilly'), 'edit_themes', basename(__FILE__), 'Theme_settings');

	

}

function Theme_settings()

{?>

  <link href="<?php echo get_template_directory_uri(); ?>/css/themeadmin.css" rel="stylesheet" type="text/css" />

  <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery-1.3.2.min.js"></script> 

  <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.smooth_tabs.js"></script> 

  <script type="text/javascript">

    	$(document).ready(function(){

            $('.smoothTabs').smoothTabs(180);

    	}); 

</script>

  <div class="wrap" style="width:827px;">

    <div class="themepanel-box">

      <div class="themeheader">

        <div class="logo"><img src="<?php echo get_template_directory_uri(); ?>/images/themechilly-logo.png" alt="" /></div>

        <div class="framework">

          <h2>DedicatedChilly <br />

            Genesite Framework</h2>

        </div>

        <div class="visit"><a href="http://www.themechilly.com" target="_blank"> www.themechilly.com</a></div>

        <div class="links"><a href="https://www.themechilly.com/manage/knowledgebase.php?action=displayarticle&id=16" target="_blank">Theme Tutorial</a> | <a href="https://www.themechilly.com/forum/index.php" target="_blank">Visit Forum</a> | <a href="http://www.themechilly.com/demo-wordpress.php?theme=dedicatedchilly" target="_blank">Theme Demo</a></div>

      </div>

      <div class="smoothTabs settingbox">

        <ul>

          <li><img src="<?php echo get_template_directory_uri(); ?>/images/setting-icon.png" alt="" /> General Settings</li>          

          <?php /*?><li><img src="<?php echo get_template_directory_uri(); ?>/images/home-icon.png" alt="" /> Homepage Settings</li><?php */?>

          <li><img src="<?php echo get_template_directory_uri(); ?>/images/contact-icon.png" alt="" /> Contact Page Settings</li>

          <li><img src="<?php echo get_template_directory_uri(); ?>/images/footer-icon.png" alt="" /> Footer Settings</li>

          <li style="border-bottom:0px;"><img src="<?php echo get_template_directory_uri(); ?>/images/seo-icon.png" alt="" /> SEO Settings</li>

        </ul>

        <form method="post" action="">

          <div class="settingcol">

            <fieldset style="border:1px solid #ddd; padding-bottom:20px; margin-top:20px;">

              <legend style="margin-left:5px; padding:0 5px;color:#2481C6; text-transform:uppercase;"><strong>General Settings</strong></legend>

              <table class="form-table">

                <!-- General settings -->

                

                <tr valign="top">

                  <th scope="row"><label for="logo_img">Change logo (full path to logo image)</label></th>

                  <td><input name="logo_img" type="text" id="logo_img" value="<?php echo get_option('Theme_logo_img'); ?>" class="regular-text" />

                    <br />

                    <em>current logo:</em> <br />

                    <img src="<?php echo get_option('Theme_logo_img'); ?>" alt="<?php echo get_option('Theme_logo_alt'); ?>" /></td>

                </tr>

                <tr valign="top">

                  <th scope="row"><label for="cufon">Cufon Font Replacement</label></th>

                  <td><select name="cufon" id="cufon">

                      <option value="yes" <?php if(get_option('Theme_cufon') == 'yes'){?>selected="selected"<?php }?>>Yes</option>

                      <option value="no" <?php if(get_option('Theme_cufon') == 'no'){?>selected="selected"<?php }?>>No</option>

                    </select></td>

                </tr>
                
                <tr valign="top">

                  <th scope="row"><label for="cufon">Theme Color Scheme</label></th>

                  <td>
                  <select id="colorscheme" name="colorscheme" class="of-input">
                  	<option value="">Blue</option>
                    <option value="red" <?php if(get_option('Theme_colorscheme') == 'red') echo 'selected';?>>Red</option>
                    <option value="green" <?php if(get_option('Theme_colorscheme') == 'green') echo 'selected';?>>Green</option>
                  </select>
                  </td>

                </tr>

              </table>

            </fieldset>

            <p class="submit">

              <input type="submit" name="Submit" class="button-primary" value="Save Changes" />

              <input type="hidden" name="Theme_settings" value="save" style="display:none;" />

            </p>

          </div>          

          <?php /*?><div class="settingcol">

            <fieldset style="border:1px solid #ddd; padding-bottom:20px; margin-top:20px;">

              <legend style="margin-left:5px; padding:0 5px;color:#2481C6; text-transform:uppercase;"><strong>Homepage Settings</strong></legend>

              <table class="form-table">

                

                <tr>

                  <th><label for="client_actions">Display Hosting Plans</label></th>

                  <td><select name="client_actions" id="client_actions">

                      <option value="yes" <?php if(get_option('Theme_client_actions') == 'yes'){?>selected="selected"<?php }?>>Yes</option>

                      <option value="no" <?php if(get_option('Theme_client_actions') == 'no'){?>selected="selected"<?php }?>>No</option>

                    </select></td>

                </tr>

                <tr>

                  <th><label for="features_actions">Display Features Content</label></th>

                  <td><select name="features_actions" id="features_actions">

                      <option value="yes" <?php if(get_option('Theme_features_actions') == 'yes'){?>selected="selected"<?php }?>>Yes</option>

                      <option value="no" <?php if(get_option('Theme_features_actions') == 'no'){?>selected="selected"<?php }?>>No</option>

                    </select></td>

                </tr>

                <tr>

                  <th><label for="services_actions">Display Domain Section</label></th>

                  <td><select name="services_actions" id="services_actions">

                      <option value="yes" <?php if(get_option('Theme_services_actions') == 'yes'){?>selected="selected"<?php }?>>Yes</option>

                      <option value="no" <?php if(get_option('Theme_services_actions') == 'no'){?>selected="selected"<?php }?>>No</option>

                    </select></td>

                </tr>

              </table>

            </fieldset>

            <p class="submit">

              <input type="submit" name="Submit" class="button-primary" value="Save Changes" />

              <input type="hidden" name="Theme_settings" value="save" style="display:none;" />

            </p>

          </div><?php */?>

          <div class="settingcol">

            <fieldset style="border:1px solid #ddd; padding-bottom:20px; margin-top:20px;">

              <legend style="margin-left:5px; padding:0 5px; color:#2481C6;text-transform:uppercase;"><strong>Contact Page Settings</strong></legend>

              <table class="form-table">

                <tr>

                  <td colspan="2"></td>

                </tr>

                <tr valign="top">

                  <th scope="row"><label for="contact_text">Contact Page Text</label></th>

                  <td><textarea name="contact_text" id="contact_text" rows="7" cols="70" style="font-size:11px;"><?php echo stripslashes(get_option('Theme_contact_text')); ?></textarea></td>

                </tr>

                <tr valign="top">

                  <th scope="row"><label for="contact_email">Email Address for Contact Form</label></th>

                  <td><input name="contact_email" type="text" id="contact_email" value="<?php echo get_option('Theme_contact_email'); ?>" class="regular-text" /></td>

                </tr>

                <tr valign="top">

                  <th scope="row"><label for="quote_email">Email Address for Quote Form</label></th>

                  <td><input name="quote_email" type="text" id="quote_email" value="<?php echo get_option('Theme_quote_email'); ?>" class="regular-text" /></td>

                </tr>

              </table>

            </fieldset>

            <p class="submit">

              <input type="submit" name="Submit" class="button-primary" value="Save Changes" />

              <input type="hidden" name="Theme_settings" value="save" style="display:none;" />

            </p>

          </div>

          <div class="settingcol">

            <fieldset style="border:1px solid #ddd; padding-bottom:20px; margin-top:20px;">

              <legend style="margin-left:5px; padding:0 5px; color:#2481C6;text-transform:uppercase;"><strong>Footer</strong></legend>

              <table class="form-table">

                <tr>

                  <th colspan="2"><strong>Copyright Info</strong></th>

                </tr>

                <tr>

                  <th><label for="copyright">Copyright Text</label></th>

                  <td><textarea name="copyright" id="copyright" rows="4" cols="70" style="font-size:11px;"><?php echo stripslashes(get_option('Theme_copyright')); ?></textarea>

                    <br />

                    <em>You can use HTML for links etc.</em></td>

                </tr>

              </table>

            </fieldset>

            <p class="submit">

              <input type="submit" name="Submit" class="button-primary" value="Save Changes" />

              <input type="hidden" name="Theme_settings" value="save" style="display:none;" />

            </p>

          </div>

          <div class="settingcol">

            <fieldset style="border:1px solid #ddd; padding-bottom:20px; margin-top:20px;">

              <legend style="margin-left:5px; padding:0 5px; color:#2481C6;text-transform:uppercase;"><strong>SEO</strong></legend>

              <table class="form-table">

                <tr>

                  <th><label for="keywords">Meta Keywords</label></th>

                  <td><textarea name="keywords" id="keywords" rows="7" cols="70" style="font-size:11px;"><?php echo get_option('Theme_keywords'); ?></textarea>

                    <br />

                    <em>Keywords comma separated</em></td>

                </tr>

                <tr>

                  <th><label for="description">Meta Description</label></th>

                  <td><textarea name="description" id="description" rows="7" cols="70" style="font-size:11px;"><?php echo get_option('Theme_description'); ?></textarea></td>

                </tr>

                <tr>

                  <th><label for="ads">Google Analytics code:</label></th>

                  <td><textarea name="analytics" id="analytics" rows="7" cols="70" style="font-size:11px;"><?php echo stripslashes(get_option('Theme_analytics')); ?></textarea></td>

                </tr>

              </table>

            </fieldset>

            <p class="submit">

              <input type="submit" name="Submit" class="button-primary" value="Save Changes" />

              <input type="hidden" name="Theme_settings" value="save" style="display:none;" />

            </p>

          </div>

        </form>

      </div>

      <div class="foottercopy">COPYRIGHT © 2012 THEMECHILLY. ALL RIGHTS RESERVED</div>

    </div>

  </div>

  <?php }

/*******************************

  CONTACT FORM 

********************************/



 function hexstr($hexstr) {

  $hexstr = str_replace(' ', '', $hexstr);

  $hexstr = str_replace('\x', '', $hexstr);

  $retstr = pack('H*', $hexstr);

  return $retstr;

}



function strhex($string) {

  $hexstr = unpack('H*', $string);

  return array_shift($hexstr);

}







//include file here

include('addons.php');



// added to widget functionality in 'widget_logic_expand_control' (above)

function widget_logic_empty_control() {}







// added to widget functionality in 'widget_logic_expand_control' (above)

function widget_logic_extra_control()

{	global $wp_registered_widget_controls, $wl_options;



	$params=func_get_args();

	$id=array_pop($params);



	// go to the original control function

	$callback=$wp_registered_widget_controls[$id]['callback_wl_redirect'];

	if (is_callable($callback))

		call_user_func_array($callback, $params);		

	

	$value = !empty( $wl_options[$id ] ) ? htmlspecialchars( stripslashes( $wl_options[$id ] ),ENT_QUOTES ) : '';



	// dealing with multiple widgets - get the number. if -1 this is the 'template' for the admin interface

	$number=$params[0]['number'];

	if ($number==-1) {$number="%i%"; $value="";}

	$id_disp=$id;

	if (isset($number)) $id_disp=$wp_registered_widget_controls[$id]['id_base'].'-'.$number;



	// output our extra widget logic field

	echo "<p><label for='".$id_disp."-widget_logic'>Widget logic <textarea class='widefat' type='text' name='".$id_disp."-widget_logic' id='".$id_disp."-widget_logic' >".$value."</textarea></label></p>";

}







// CALLED ON 'plugin_action_links' ACTION

function wl_charity($links, $file)

{	if ($file == plugin_basename(__FILE__))

		array_push($links, '');

	return $links;

}







// FRONT END FUNCTIONS...







// CALLED ON 'sidebars_widgets' FILTER

function widget_logic_filter_sidebars_widgets($sidebars_widgets)

{	global $wp_reset_query_is_done, $wl_options;



	// reset any database queries done now that we're about to make decisions based on the context given in the WP query for the page

	if ( !empty( $wl_options['widget_logic-options-wp_reset_query'] ) && ( $wl_options['widget_logic-options-wp_reset_query'] == 'checked' ) && empty( $wp_reset_query_is_done ) )

	{	wp_reset_query(); $wp_reset_query_is_done=true;	}



	// loop through every widget in every sidebar (barring 'wp_inactive_widgets') checking WL for each one

	foreach($sidebars_widgets as $widget_area => $widget_list)

	{	if ($widget_area=='wp_inactive_widgets' || empty($widget_list)) continue;



		foreach($widget_list as $pos => $widget_id)

		{

			$wl_value=(!empty($wl_options[$widget_id]))?	stripslashes($wl_options[$widget_id]) : "true";

			$wl_value =(stristr($wl_value,"return"))?		$wl_value: "return (" . $wl_value . ");";

			if (!eval($wl_value))

				unset($sidebars_widgets[$widget_area][$pos]);

		}

	}

	return $sidebars_widgets;

}







// If 'widget_logic-options-filter' is selected the widget_content filter is implemented...







// CALLED ON 'dynamic_sidebar_params' FILTER - this is called during 'dynamic_sidebar' just before each callback is run

// swap out the original call back and replace it with our own

function widget_logic_widget_display_callback($params)

{	global $wp_registered_widgets;

	$id=$params[0]['widget_id'];

	$wp_registered_widgets[$id]['callback_wl_redirect']=$wp_registered_widgets[$id]['callback'];

	$wp_registered_widgets[$id]['callback']='widget_logic_redirected_callback';

	return $params;

}





// the redirection comes here

function widget_logic_redirected_callback()

{	global $wp_registered_widgets, $wp_reset_query_is_done;



	// replace the original callback data

	$params=func_get_args();

	$id=$params[0]['widget_id'];

	$callback=$wp_registered_widgets[$id]['callback_wl_redirect'];

	$wp_registered_widgets[$id]['callback']=$callback;



	// run the callback but capture and filter the output using PHP output buffering

	if ( is_callable($callback) ) 

	{	ob_start();

		call_user_func_array($callback, $params);

		$widget_content = ob_get_contents();

		ob_end_clean();

		echo apply_filters( 'widget_content', $widget_content, $id);

	}

}



   if (!defined('WPINC'))

      die;



   define('NS_SHORTCODES_NAME','NS Shortcodes');

   define('NS_SHORTCODES_SLUG','ns-shortcodes');



   class NS_Shortcodes  {

     protected $plugin_name = NS_SHORTCODES_NAME ;

     protected $plugin_slug = NS_SHORTCODES_SLUG ;



     private $hook_settings_page;



    /**

     * Constructor

     */

    function __construct(){



      $this->hook_settings_page = 'appearance_page_'. $this->plugin_slug;



      register_activation_hook( __FILE__, array( $this, 'activate' ) );

      register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );



      add_action('admin_enqueue_scripts', array($this, 'register_admin_styles'));



      add_shortcode( 'ns-site-title' , array( $this, 'ns_site_title' ) );

      add_shortcode( 'ns-site-tagline' , array( $this, 'ns_site_tagline' ) );

      add_shortcode( 'th-site-url' , array( $this, 'ns_site_url' ) );

      add_shortcode( 'th-home-url' , array( $this, 'ns_home_url' ) );

      add_shortcode( 'ns-current-year' , array( $this, 'ns_current_year' ) );

      add_shortcode( 'ns-login-url' , array( $this, 'ns_login_url' ) );

      add_shortcode( 'ns-logout-url' , array( $this, 'ns_logout_url' ) );

      add_shortcode( 'ns-registration-url' , array( $this, 'ns_registration_url' ) );

      add_shortcode( 'ns-lost-password-url' , array( $this, 'ns_lost_password_url' ) );

      add_shortcode( 'th-theme-url' , array( $this, 'ns_theme_url' ) );

      add_shortcode( 'th-theme-name' , array( $this, 'ns_theme_name' ) );

      add_shortcode( 'ns-theme-author-url' , array( $this, 'ns_theme_author_url' ) );

      add_shortcode( 'ns-theme-author-name' , array( $this, 'ns_theme_author_name' ) );

      add_shortcode( 'ns-theme-version' , array( $this, 'ns_theme_version' ) );



      add_action('admin_menu', array( $this, 'ns_shortcodes_plugin_menu' ) );



      $plugin = plugin_basename(__FILE__);

      add_filter("plugin_action_links_$plugin", array($this, 'ns_shortcodes_add_settings_link'));



   }



   function activate(){

      //activation

   }



   function deactivate(){

      //deactivation

   }



   function ns_site_title(){

      return get_bloginfo('name');

   }

   function ns_site_tagline(){

      return get_bloginfo('description');

   }

   function ns_site_url(){

      return site_url();

   }

   function ns_home_url(){

      return home_url();

   }

   function ns_current_year(){

      return date('Y');

   }

   function ns_login_url($atts){

      extract( shortcode_atts( array(

         'redirect' => 'default'

         ), $atts ) );

      switch ($redirect) {

         case 'default':

         $output = wp_login_url();

         break;

         case 'current':

         $output = wp_login_url(get_permalink());

         break;

         case 'home':

         $output = wp_login_url(home_url());

         break;

      }

      return $output;

   }

   function ns_logout_url($atts){

      extract( shortcode_atts( array(

         'redirect' => 'default'

         ), $atts ) );

      switch ($redirect) {

         case 'default':

         $output = wp_logout_url();

         break;

         case 'current':

         $output = wp_logout_url(get_permalink());

         break;

         case 'home':

         $output = wp_logout_url(home_url());

         break;

      }

      return $output;

   }

   function ns_registration_url(){

      return wp_registration_url();

   }

   function ns_lost_password_url($atts){

      extract( shortcode_atts( array(

         'redirect' => 'default'

         ), $atts ) );

      switch ($redirect) {

         case 'default':

         $output = wp_lostpassword_url();

         break;

         case 'current':

         $output = wp_lostpassword_url(get_permalink());

         break;

         case 'home':

         $output = wp_lostpassword_url(home_url());

         break;

      }

      return $output;

   }

   function ns_theme_url(){

      $theme = wp_get_theme();

      return $theme->get( 'ThemeURI' );

   }

   function ns_theme_name(){

      $theme = wp_get_theme();

      return $theme->get( 'Name' );

   }

   function ns_theme_author_url(){

      $theme = wp_get_theme();

      return $theme->get( 'AuthorURI' );

   }

   function ns_theme_author_name(){

      $theme = wp_get_theme();

      return $theme->get( 'Author' );

   }

   function ns_theme_version(){

      $theme = wp_get_theme();

      return $theme->get( 'Version' );

   }



   function ns_shortcodes_plugin_menu()

   {

      add_theme_page( $this->plugin_name, $this->plugin_name, 'edit_theme_options', $this->plugin_slug,

         array($this, 'ns_shortcodes_admin_function'));

   }

   function ns_shortcodes_admin_function()

   {

     // require_once( ( plugin_dir_path(__FILE__) ) . '/admin/admin.php');

   }

   public function ns_shortcodes_add_settings_link($links)

   {

       $settings_link = '<a href="themes.php?page='.$this->plugin_slug.'">' . __("Settings", $this->plugin_slug) . '</a>';

       array_push($links, $settings_link);

       return $links;

   }

   public function register_admin_styles($hook)

   {

       if ($hook != $this->hook_settings_page)

       {

           return;

       }

       wp_enqueue_style($this->plugin_slug.'-admin-styles', plugins_url($this->plugin_slug.'/admin/css/admin.css'));

   }





}//end class



/**

 * Create new instance

 */

$ns_shortcode = new NS_Shortcodes();





