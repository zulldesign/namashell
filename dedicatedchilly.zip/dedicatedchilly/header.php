<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<meta name="keywords" content="<?php echo get_option('Theme_keywords'); ?>" />

<meta name="description" content="<?php echo get_option('Theme_description'); ?>" />

<meta name="viewport" content="width=1100" />

<title>

<?php wp_title('&laquo;', true, 'right'); ?>

<?php bloginfo('name'); ?>

</title>

<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />

<link href="<?php echo get_template_directory_uri(); ?>/css/ddsmoothmenu.css" rel="stylesheet" type="text/css" />

<link href="<?php echo get_template_directory_uri(); ?>/css/nivo-slider.css" rel="stylesheet" type="text/css" />

<link href="<?php echo get_template_directory_uri(); ?>/favicon.ico" rel="shortcut icon" type="image/x-icon" />

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery-1.4.2.min.js"></script>

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.form.js"></script>

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/custom.js"></script>

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/cufon-yui.js"></script>

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/Museo_Slab_500_400.font.js"></script>

<script type="text/javascript">



		<?php if(get_option('Theme_cufon')!="no"):?>



			Cufon.replace('h1',{hover: true})('h2',{hover: true})('h3')('.reply',{hover:true})('.more-link')('.highlight-feature .price')('.highlight-feature .deploy')('.highlight-feature .high')('.highlight-feature .virtual')('.price_col ul li.price b')('.price_col ul li.price-title')('.serverheading')('.domainbox .col1 h2')('.domainbox .col1 ul li')('.domainpricetable td')('.plansfeat .price');



Cufon.replace('.interior-left span', { textShadow: '#000 1px 1px 1px' })('.getlocation .location', { textShadow: '#fff 1px 1px 1px' })('.plansfeat .price', { textShadow: '#ccc 1px 1px 1px' });		



		 <?php endif ?>



</script>

<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php wp_get_archives('type=monthly&format=link'); ?>

<?php //comments_popup_script(); // off by default ?>

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.js"></script>

<script type="text/javascript" language="javascript">



  function showsupport(id) {



    document.getElementById(id).style.visibility = "visible";



  }



  function hidesupport(id) {



    document.getElementById(id).style.visibility = "hidden";



  }



</script>

<script type="text/javascript"> function mainmenu(){

$(" .menu ul ").css({display: "none"}); // Opera Fix

$(" .menu li").hover(function(){

		$(this).find('ul:first').css({visibility: "visible",display: "none"}).show(400);

		},function(){

		$(this).find('ul:first').css({visibility: "hidden"});

		});

}

 $(document).ready(function(){					

	mainmenu();

});</script>

<link href="<?php echo get_template_directory_uri(); ?>/css/testimonials.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/freecontactformvalidation.js"></script>

<link href="<?php echo get_template_directory_uri(); ?>/css/freecontactform.css" rel="stylesheet" type="text/css" />

<link href="<?php echo get_template_directory_uri(); ?>/css/slidercss.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/sliderjs.js"></script>

<link href="<?php echo get_template_directory_uri(); ?>/css/stylenew.css" rel="stylesheet" type="text/css" />

<?php if(get_option('Theme_colorscheme') != '') { ?>
<!-- custom color scheme css -->
<link rel="stylesheet" href="<?php bloginfo('template_directory');?>/skins/<?php echo get_option('Theme_colorscheme') ?>/style.css">
<?php } ?>

<?php wp_head(); ?>

</head>



<body <?php body_class(); ?> <?php if(is_home()){



				echo 'id="home"';



			}elseif(is_category(get_option('Theme_portfolio')) || post_is_in_descendant_category( get_option('Theme_portfolio')) && !is_single()){



				echo 'id="portfolio"';



			}?>>



<!-- BEGINN MAINWRAPPER -->



<div id="mainWrapper">



<!-- BEGIN WRAPPER -->



<div id="wrapper">



<!-- BEGIN HEADER -->



<div id="header" style="position:relative;">

  <?php $content_post = get_post_by_name('top-header');

if($content_post)

{

    $content = $content_post->post_content;

    // do whatever you want

    echo do_shortcode($content);

} ?>

  <?php if(get_option('Theme_colorscheme')=='green') {?>

  <div id="logo"><a href="<?php echo home_url( '/' ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/dedicatedchilly-logo3.png" alt="" /></a></div>

  <?php }

  elseif(get_option('Theme_colorscheme')=='red') {; ?>

  <div id="logo"><a href="<?php echo home_url( '/' ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/dedicatedchilly-logo2.png" alt="" /></a></div>

  <?php  }  else  { ?>

  <div id="logo"><a href="<?php echo home_url( '/' ); ?>"><img src="<?php echo get_option('Theme_logo_img'); ?>" alt="<?php echo get_option('Theme_logo_alt'); ?>" /></a></div>

  <?php }?>

  <?php $content_post = get_post_by_name('toll-free-no');

if($content_post)

{

    $content = $content_post->post_content;

    // do whatever you want

    echo do_shortcode($content);

} ?>

  

  <!-- BEGIN MAIN MENU -->

  

  <div class="mainmenu" style="clear:both; width:990px; margin-top:65px;">

    <?php if ( function_exists( 'wp_nav_menu' ) ){



					wp_nav_menu( array( 'theme_location' => 'main-menu', 'container_id' => 'mainMenu', 'container_class' => 'ddsmoothmenu', 'fallback_cb'=>'primarymenu') );



				}else{



					primarymenu();



			}?>

  </div>

  

  <!-- END MAIN MENU --> 

  

  <!-- BEGIN TOP SEARCH -->

  

  <div id="topSearch" style="display: none">

    <form id="searchform" action="<?php echo home_url( '/' ); ?>" method="get">

      <input type="submit" value="" id="searchsubmit"/>

      <input type="text" id="s" name="s" value="type your search" onblur="if (this.value=='') this.value='type your search';" onfocus="if (this.value=='type your search') this.value='';" />

    </form>

  </div>

  

  <!-- END TOP SEARCH --> 

  

</div>



<!-- END HEADER --> 



<!-- BEGIN CONTENT -->



<div id="content" class="contentbox">

