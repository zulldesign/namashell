<?php get_header();?>

<div id="colLeft" style="border:solid 0px;margin-right:0px; width:990px; background:#FFF; border-radius:10px 10px 10px 10px;">    
  <div class="innerheader">
  <div class="headerimage"><img src="<?php echo get_template_directory_uri(); ?>/images/pressreleasebig.png" width="80" height="80" alt="" /></div>
    <h1 class="innerh1" style="color:#011a23;text-shadow:none!important;text-transform:uppercase; font-size:30px;">Press Release <span>Welcome To<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?></span></h1>
  </div>
  <div class="breadcrumb">
    <?php if (function_exists('chilly_breadcrumbs')) chilly_breadcrumbs(); ?>    
  </div>
  
  <div class="fullpage" style="padding:0px; width:990px; float:left;">
    <div class="postItem" style="padding:0px 0px; width:700px; float:left; border:solid 0px; margin-left:30px;">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <div style="border-bottom:solid 1px #ccc; padding-bottom:10px; padding-top:0px; margin-top:20px;">
        <h1 style="font-size:26px;"> <?php the_title(); ?> </h1>
        <div class="meta">
          <?php the_time('M j, Y') ?>
          &nbsp;&nbsp;//&nbsp;&nbsp; by <span class="author">
          <?php the_author_link(); ?>
          </span> &nbsp;&nbsp;//&nbsp;&nbsp;
          <?php the_category(', ') ?>
          &nbsp;//&nbsp;
          <?php comments_popup_link('No Comments', '1 Comment ', '% Comments'); ?>
        </div>
        <div style="line-height:22px; text-align:justify; padding-right:10px;"><?php the_content(__('read more', 'cloudchilly')); ?></div>
        <div class="postTags">
          <?php the_tags(); ?>
        </div>
        <?php comments_template(); ?>     
    </div>
    <?php endwhile; else: ?>
    <p>Sorry, but you are looking for something that isn't here.</p>
    <?php endif; ?>
  </div>
  <?php get_sidebar(); ?>
</div>
</div>
</div>
<?php get_footer(); ?>
