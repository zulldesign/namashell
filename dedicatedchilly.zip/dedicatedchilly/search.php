<?php get_header(); ?>
<div id="colLeft" style="border:solid 0px; padding:20px 10px; width:980px; margin-right:0px;">
  <div class="innerheader">    
    <h1 class="innerh1" style="color:#011a23;text-shadow:none!important;text-transform:uppercase; font-size:30px;"><?php the_title(); ?></h1>
  </div>
  <div class="breadcrumb">
    <?php if (function_exists('chilly_breadcrumbs')) chilly_breadcrumbs(); ?>    
  </div>
  <div class="fullpage" style="padding:20px; width:958px; float:left;">
  
  <?php
	$page = (get_query_var('paged')) ? get_query_var('paged') : 1;
	$s = get_query_var('s');
	query_posts("s=$s&cat=-8,-6,-4,-10,-1&paged=$page");
	?>
    <div class="postItem" style="padding:10px; width:680px; float:left; border:solid 0px;">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <div style="border-bottom:solid 1px #ccc; padding-bottom:10px; padding-top:20px;">
      <h1><a href="<?php the_permalink() ?>">
        <?php the_title(); ?>
        </a></h1>
      	<div class="meta">
        <?php the_time('M j, Y') ?>
        &nbsp;&nbsp;//&nbsp;&nbsp; by <span class="author">
        <?php the_author_link(); ?>
        </span> &nbsp;&nbsp;//&nbsp;&nbsp;
        <?php the_category(', ') ?>
        &nbsp;//&nbsp;
        <?php comments_popup_link('No Comments', '1 Comment ', '% Comments'); ?>
      </div>
      <?php the_excerpt(); ?>
      </div>
      <?php endwhile; ?>
      <?php else : ?>      
      <?php endif; ?>
    </div>   
    <?php get_sidebar(); ?>
  </div>
</div>
</div>
</div>
<?php get_footer(); ?>