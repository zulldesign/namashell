
<!-- Begin #colLeft -->
		<div class="sidebar">
        <ul>
        <?php 
        $locations = get_registered_nav_menus();
        $menus = wp_get_nav_menus();
        $menu_locations = get_nav_menu_locations();
        
        $location_id = 'footer_menu2';
        
        if (isset($menu_locations[ $location_id ])) 
		{			
			foreach ($menus as $menu) 
			{
			
				if ($menu->term_id == $menu_locations[ $location_id ]) 
				{
					echo '<h2>'.$menu->name.'</h2>';
					// Get the items for this menu
					$menu_items = wp_get_nav_menu_items($menu);
					
					foreach ( $menu_items as $item )
					{
						
						$id = get_post_meta( $item->ID, '_menu_item_object_id', true );
						$page = get_page( $id );
						//$link = get_page_link( $id ); ?>
          <li><a href="<?php echo $item->url; ?>" > <?php echo $page->post_title; ?> </a></li>
          <?php 
					}
					
					break;
				}
			}
        }    
        ?>
		</ul>
		<?php /*?><?php 
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?><?php endif; ?><?php */?>
        
        
		
		</div>
<!-- End #colRight -->
		
