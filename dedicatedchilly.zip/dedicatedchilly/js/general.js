
$( window ).load( function() {

if ( $( '#featured-slider' ).length ) {
	/* Setup dynamic variables. */
	var autoInterval = parseInt( woo_slider_settings.auto ) * 1000;
	var speed = parseInt( woo_slider_settings.speed * 1000 );
	var effect = woo_slider_settings.effect;
	var hoverPause = woo_slider_settings.hoverpause;
	var nextPrev = woo_slider_settings.nextprev;
	var pagination = woo_slider_settings.pagination;
	var autoHeight = woo_slider_settings.autoheight;
	
	if ( hoverPause == 'true' ) { hoverPause = true; } else { hoverPause = false; }
	if ( nextPrev == 'true' ) { nextPrev = true; } else { nextPrev = false; }
	if ( pagination == 'true' ) { pagination = true; } else { pagination = false; }
	if ( autoHeight == 'true' ) { autoHeight = true; } else { autoHeight = false; }
	
	if ( effect != 'slide' && effect != 'fade' ) { effect = 'slide'; } // Sanity check.


	if ( $( '#featured-slider .slide' ).length > 1 ) {

		$( '#featured-slider' ).slides({
			autoHeight: autoHeight,
			effect: effect,		
			hoverPause: hoverPause,
			play: autoInterval,		
			slideSpeed: speed, 
			fadeSpeed: speed, 
			crossfade: false,
			generateNextPrev: nextPrev,
			generatePagination: pagination
		});
	
	} else {
		$( '#featured-slider .slide' ).fadeIn();
	}
}

});



