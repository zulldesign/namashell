<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('CREATEPROFILE', 'Skapa en ny kundprofil');
define('ALREADYSIGNEDUP', 'Redan registrerad?');
define('LOGINHERE', 'Logga in h&auml;r');
define('SIGNUPMESSAGE', 'Genom att registrera en kundprofil kan du handla snabbare och enklare p&aring; ');
define('REGISTER', 'Registrerings');
define('FORM', 'Formul&auml;r');
define('PASSWORD', 'L&ouml;senord');
define('CONFIRMPASSWORD', 'Bekr&auml;fta l&ouml;senord');
define('FIRSTNAME', 'F&ouml;rnamn');
define('LASTNAME', 'Efternamn');
define('EMAIL', 'E-post');
define('SECURITYCODE', 'S&auml;kerhetskod');
define('TYPESECURITYCODE', 'Ange s&auml;kerthetskoden');
define('YESEMAILME', 'Ja, jag vill f&aring; erbjudanden och nyheter fr&aring;n denna butik per e-post.');
define('SUBMIT', 'Skicka');
?>