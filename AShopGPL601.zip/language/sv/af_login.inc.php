<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('AFFILIATEPROGRAM', 'Affiliateprogram');
define('WRONGPASSWORD', 'Fel l&ouml;senord!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('LOGINMESSAGE', 'Tj&auml;na pengar genom att hj&auml;lpa oss s&auml;lja v&aring;ra produkter...');
define('SIGNUPMESSAGE1', 'Tack f&ouml;r att du registrerat dig i v&aring;rt affiliateprogram!<br>Ditt anv&auml;ndarnamn och l&ouml;senord har skickats till dig per e-post.<br>H&auml;mta din e-post och logga in...');
define('SIGNUPMESSAGE2', 'Om du redan har registrerat dig i v&aring;rt affiliateprogram kan du logga in h&auml;r:');
define('USER', 'Anv&auml;ndarnamn');
define('PASSWORD', 'L&ouml;senord');
define('LOGIN', 'Logga in');
define('FORGOTPASS', 'Gl&ouml;mt ditt l&ouml;senord?');
define('NEWAFFILIATE', 'Registrera dig som ny affiliate');
define('PARTIES', 'Partyn');
?>