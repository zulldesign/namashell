<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('LICENSEAGREE1', ' - Licensavtal f&ouml;r ');
define('LICENSEAGREE2', 'Licensavtal f&ouml;r ');
define('WINDOWCLOSE', 'St&auml;ng detta f&ouml;nster');
define('PURCHASEAGREEMENT', 'K&ouml;pvillkor');
?>