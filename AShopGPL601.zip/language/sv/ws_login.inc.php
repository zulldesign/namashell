<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('WHOLESALELOGIN', 'Inloggning, &aring;terf&ouml;rs&auml;ljare');
define('WRONGPASSWORD', 'Fel l&ouml;senord!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('USER', 'Anv&auml;ndarnamn');
define('PASSWORD', 'L&ouml;senord');
define('LOGIN', 'Logga in');
define('FORGOTPASS', 'Gl&ouml;mt ditt l&ouml;senord?');
define('NEWWSCUSTOMER', 'Registrera dig som ny &aring;terf&ouml;rs&auml;ljare');
?>