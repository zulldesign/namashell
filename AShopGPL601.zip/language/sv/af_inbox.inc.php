<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('WELCOME', 'V&auml;lkommen');
define('AFFILIATEID', 'Affiliateid');
define('VIEWPROFILE', '&Auml;ndra dina uppgifter');
define('CHANGEPASS', 'Byt l&ouml;senord');
define('ORDERHISTORY', 'Orderhistorik');
define('STATISTICS', 'Statistik');
define('LINKCODES', 'L&auml;nkkoder');
define('DOWNLINE', 'Downline');
define('LOGOUT', 'Logga ut');
define('LEADS', 'Leads');
define('INBOX', 'Inkorg');
define('SUBJECT', '&auml;mne');
define('RECEIVED', 'Mottaget');
define('FROM', 'Fr&aring;n');
define('SPONSOR', '[Sponsor]');
define('UPLINE', '[Upline]');
define('SHOPADMIN', 'Administrat&ouml;r');
define('MESSAGES', 'Meddelandearkiv');
define('UNREAD', 'Ol&auml;sta meddelanden');
define('NOMESSAGES', 'Du har inga meddelanden');
define('PARTIES', 'Partyn');
?>