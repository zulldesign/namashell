<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('WHOLESALE', '&aring;terf&ouml;rs&auml;ljare');
define('YOURPASSWORD', 'Ditt &aring;terf&ouml;rs&auml;ljar-l&ouml;senord');
define('YOURPASSWORDFOR', 'Ditt &aring;terf&ouml;rs&auml;ljar-l&ouml;senord till');
define('IS', '&auml;r');
define('PASSWORDSENT', 'Ditt l&ouml;senord har skickats');
define('PASSWORDSENTBYEMAIL', 'Ditt l&ouml;senord har skickats till dig per e-post');
define('WHOLESALELOGIN', 'Inloggning, &aring;terf&ouml;rs&auml;ljare');
define('NOTREGISTERED', 'Du &auml;r inte registrerad som &aring;terf&ouml;rs&auml;ljare');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('FORGOTPASSWORD', 'Gl&ouml;mt ditt l&ouml;senord?');
define('ENTERUSERNAME', 'Skriv ditt anv&auml;ndarnamn s&aring; skickar vi l&ouml;senordet till den e-postadress<br>du skrev n&auml;r du registrerade dig som &aring;terf&ouml;rs&auml;ljare...');
define('USERNAME', 'Anv&auml;ndarnamn');
define('SUBMIT', 'Skicka');
?>