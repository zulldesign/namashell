<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('AFFILIATEPROGRAM', 'affiliateprogram');
define('YOURPASSWORD', 'Ditt l�senord');
define('YOURPASSWORDFOR', 'Ditt affiliatel�senord till');
define('IS', '�r');
define('PASSWORDSENT', 'Ditt l&ouml;senord har skickats');
define('PASSWORDSENTBYEMAIL', 'Ditt l&ouml;senord har skickats till dig per e-post');
define('AFFILIATELOGIN', 'Logga in');
define('NOTREGISTERED', 'Du &auml;r inte registrerad i v&aring;rt affiliate-program');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('FORGOTPASSWORD', 'Gl&ouml;mt ditt l&ouml;senord?');
define('ENTERUSERNAME', 'Skriv ditt anv&auml;ndarnamn s&aring; skickar vi l&ouml;senordet till den e-postadress<br>du skrev n&auml;r du registrerade dig i v&aring;rt affiliateprogram...');
define('USERNAME', 'Anv&auml;ndarnamn');
define('SUBMIT', 'Skicka');
?>