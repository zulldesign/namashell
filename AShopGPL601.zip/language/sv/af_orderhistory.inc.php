<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('WELCOME', 'V&auml;lkommen');
define('AFFILIATEID', 'Affiliateid');
define('VIEWPROFILE', '&Auml;ndra dina uppgifter');
define('CHANGEPASS', 'Byt l&ouml;senord');
define('ORDERHISTORY', 'Orderhistorik');
define('STATISTICS', 'Statistik');
define('LINKCODES', 'L&auml;nkkoder');
define('DOWNLINE', 'Downline');
define('LOGOUT', 'Logga ut');
define('LEADS', 'Leads');
define('INBOX', 'Inkorg');
define('REFERENCE', 'Referens');
define('DATETIME', 'Datum, klockslag');
define('AMOUNT', 'Belopp');
define('PAIDBY', 'Betalt via');
define('TOTALUNPAID', 'Totalt obetalt');
define('TIER2', 'niv&aring;');
define('COMMISSIONHISTORY', 'Provisions- och betalningshistorik');
define('PARTIES', 'Partyn');
?>