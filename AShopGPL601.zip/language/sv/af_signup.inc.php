<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('FORGOTSOMETHING', 'Fel - du gl&ouml;mde n&aring;gonting!');
define('ERROR', 'Fel!');
define('YOUFORGOT', 'Du gl&ouml;mde att fylla i n&aring;got av de obligatoriska f&auml;lten!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('INVALIDUSERNAME', 'Fel - felaktigt anv&auml;ndarnamn');
define('THEUSERNAME', 'Anv&auml;ndarnamnet f&aring;r inte inneh&aring;lla mellanslag eller skiljetecken. Det f&aring;r inte heller vara l&auml;ngre &auml;n 10 tecken.');
define('INVALIDSECURITYCODE', 'Fel - felaktig s&auml;kerhetskod');
define('INCORRECTSECURITYCODE', 'S&auml;kerhetskoden &auml;r inte korrekt!');
define('USERNAMEINUSE', 'Anv&auml;ndarnamnet &auml;r upptaget!');
define('SORRY', 'Tyv&auml;rr!');
define('ALREADYINUSE', 'Anv&auml;ndarnamnet du skrev &auml;r upptaget!');
define('THANKYOUFORJOINING', 'Tack f&ouml;r att du registrerat dig i');
define('AFFILIATEPROGRAM', 'affiliateprogram!');
define('YOURUSERNAMEIS', 'Ditt anv&auml;ndarnamn &auml;r:');
define('ANDYOURPASSWORD', ', och ditt l&ouml;senord:');
define('TOMANUALLYREFER', 'F&ouml;r att h&auml;nvisa kunder manuellt kan du anv&auml;nda f&ouml;ljande h&auml;nvisningskod:');
define('LOGIN', 'Logga in f&ouml;r att f&aring; din l&auml;nkkod och kontrollera din statistik p&aring;');
define('AIDDOESNOTEXIST', 'The affiliate profile you tried to activate has already been activated or does not exist.');
define('YOUARERECEIVING', 'You are receiving this message because your email address has been used to sign up for an affiliate account at');
define('PLEASEVERIFY', 'Please verify that you wish to sign up as an affiliate by clicking on the following link:');
define('THANKYOUFORREGISTERING', 'Tack f&ouml;r att du anm&auml;lt dig till');
define('CHECKMAIL', 'Du kommer inom kort att f&aring; ett meddelande per e-post med en l&auml;nk som du klickar p&aring; f&ouml;r att aktivera ditt affiliatekonto.');
?>