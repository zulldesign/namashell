<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('WAIT', 'Startar filh&auml;mtning. Var god v&auml;nta...');
define('BACK', 'Tillbaka till leveranssidan.');
define('WRONGPASS', ' - Fel l&ouml;senord eller e-postadress!');
define('NOACCESS', 'Information om nedladdningen saknas! Detta kan h&auml;nda om din webbl&auml;sare blockerar cookies. Prova att s&auml;nka inst&auml;llningen f&ouml;r sekretessniv&aring; i din webbl&auml;sare eller se till s&aring; att cookies inte blockeras.');
define('DLLOGIN', 'Anv&auml;nd leveranssidan f&ouml;r att logga in.');
define('CLICK', 'Klicka h&auml;r');
define('WRONGPASSWORD', 'L&ouml;senordet eller e-postadressen du angav var felaktig!');
define('UNAUTHORIZED', ' - otill&aring;ten leverans!');
define('NOTALLOW', 'Du f&aring;r inte ladda ned denna produkt med ditt l&ouml;senord!');
define('AUTOREPORT', 'Detta har automatiskt rapporterats till oss!');
define('LIMIT', ' - nedladdningsgr&auml;ns &ouml;verskriden!');
define('ALREADY', 'Du har redan laddat ned denna fil det till&aring;tna antalet g&aring;nger.');
define('EXPIRED', ' - nedladdningstid &ouml;verskriden!');
define('TIMEEXPIRED', 'Din till&aring;tna tid f&ouml;r att ladda ned denna produkt har g&aring;tt ut!');
define('ERROR', 'Ett fel har uppst&aring;tt!');
define('ERRORTITLE', "fel!");
define('COULDNOTDOWNLOAD', 'Denna produkt kunde inte laddas ned.');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
?>