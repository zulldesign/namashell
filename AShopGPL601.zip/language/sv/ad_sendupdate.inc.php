<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('DOWNLOADUPDATE', 'H&auml;mta uppdateringen p&aring;');
define('LOGINWITH', 'Logga in med samma e-postadress som du anv&auml;nde d&aring; du k&ouml;pte produkten och med l&ouml;senordet');
?>