<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('TOCOMPLETEORDER', 'F&ouml;r att f&aring; k&ouml;pa och anv&auml;nda denna<br>vara m&aring;ste du acceptera dess licens!');
define('CLOSE', 'St&auml;ng detta f&ouml;nster');
define('ERROR', 'Fel! Varan du valde finns inte i v&aring;r katalog!');
define('NOTFOUND', 'Varan finns inte');
define('NOTINCATALOGUE', 'Varan du valde finns inte i v&aring;r katalog. Prova en annan l&auml;nk till denna vara eller kontakta butikens administrat&ouml;r f&ouml;r att f&aring; hj&auml;lp.');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('ADD', 'L&auml;gg till i &ouml;nskelista');
define('ITEM', 'Produkt');
define('SELECTOPTIONS', 'V&auml;lj alternativ');
define('TERMSFOR', 'f&ouml;r');
define('PUTINCART', 'L&auml;gg till i &ouml;nskelista');
define('CANCEL', 'Avbryt');
define('HASBEENADDED', 'har lagts till i din &ouml;nskelista');
?>