<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('CLICKHERE', 'Klicka h&auml;r!');
define('YOURHTMLCODE', 'Din l&auml;nkkod f&ouml;r butiken');
define('COPYHTMLCODE', 'Kopiera f&ouml;ljande kod och klistra in p&aring; dina webbsidor f&ouml;r att tj&auml;na pengar...');
define('BACKTOMALL', 'Tillbaka till butikslista');
define('NOTREGISTERED', 'Du &auml;r inte registrerad i v&aring;rt affiliate-program');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('PROMOTESHOP', 'Promota butiken ');
define('ENTERAFFILIATEID', 'Du kan tj&auml;na pengar p&aring; att hj&auml;lpa den h&auml;r butiken att s&auml;lja sina varor. Skriv ditt affiliate ID f&ouml;r att f&aring; en l&auml;nkkod som du kan kopiera och klistra in p&aring; dina webbsidor...');
define('AFFILIATEID', 'Affiliate ID');
define('SUBMIT', 'Skicka');
define('NOAFFID', 'Har du inget affiliate ID?');
define('NEWAFFILIATE', 'Registrera dig som ny affiliate');
?>