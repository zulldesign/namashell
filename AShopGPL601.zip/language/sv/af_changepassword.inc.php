<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('NOTREGISTERED', 'Du &auml;r inte registrerad!');
define('SORRY', 'Tyv&auml;rr!');
define('USERNAMENOTREGISTERED', 'Ditt anv&auml;ndarnamn eller e-postadress finns inte i v&aring;r databas!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('WRONGPASS', 'Fel l&ouml;senord!');
define('INCORRECTPASS', 'L&ouml;senordet du skrev &auml;r felaktigt.');
define('WELCOME', 'V&auml;lkommen');
define('AFFILIATEID', 'Affiliateid');
define('VIEWPROFILE', '&Auml;ndra dina uppgifter');
define('CHANGEPASSBTN', 'Byt l&ouml;senord');
define('ORDERHISTORY', 'Orderhistorik');
define('STATISTICS', 'Statistik');
define('LINKCODES', 'L&auml;nkkoder');
define('DOWNLINE', 'Downline');
define('LOGOUT', 'Logga ut');
define('LEADS', 'Leads');
define('INBOX', 'Inkorg');
define('DIDNOTMATCH', 'L&ouml;senorden &ouml;verensst&auml;mde inte!');
define('ERROR', 'Fel!');
define('CHANGEPASS', '&Auml;ndra ditt l&ouml;senord');
define('OLDPASS', 'Gammalt l&ouml;senord');
define('NEWPASS', 'Nytt l&ouml;senord');
define('CONFIRM', 'Bekr&auml;fta');
define('UPDATE', '&Auml;ndra');
define('PARTIES', 'Partyn');
?>