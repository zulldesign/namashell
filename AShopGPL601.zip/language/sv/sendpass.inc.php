<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('CUSTOMERPROFILE', 'kundprofil!');
define('YOURPASSWORD', 'Ditt kundl&ouml;senord');
define('YOURPASSWORDFOR', 'L&ouml;senordet till din kundprofil p&aring;');
define('IS', '&auml;r');
define('PASSWORDSENT', 'Ditt l&ouml;senord har skickats');
define('PASSWORDSENTBYEMAIL', 'Ditt l&ouml;senord har skickats till dig per e-post');
define('CUSTOMERLOGIN', 'Kundinloggning');
define('NOTREGISTERED', 'Du &auml;r inte registrerad som kund');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('FORGOTPASSWORD', 'Gl&ouml;mt ditt l&ouml;senord?');
define('ENTERUSERNAME', 'Skriv din e-post s&aring; skickar vi l&ouml;senordet till dig...');
define('USERNAME', 'E-post');
define('SUBMIT', 'Skicka');
?>