<?php
define('NEWSLETTERSIGNUP', 'F&aring; specialerbjudanden och rabatter!');
define('NLSIGNUP', 'Anm&auml;l dig f&ouml;r att f&aring; uppdateringar och nyheter per e-post...');
define('NLNAME', 'Namn');
define('NLEMAIL', 'E-post');
define('NLCODE', 'Kod');
define('NLCLOSE', 'St&auml;ng');
define('NLCODEDIDNOTMATCH', 'S&auml;kerhetskoden matchade inte! F&ouml;rs&ouml;k igen...');
define('NLSECURITYCODE', 'S&auml;kerhetskod');
define('NLNOSPAM', 'Vi tycker lika illa om spam som du och<br>ger aldrig din e-post vidare till n&aring;gon.');
define('NLTHANKYOU', 'Tack f&ouml;r att du anm&auml;lde dig!');
?>