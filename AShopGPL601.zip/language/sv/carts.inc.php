<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('ERROR', 'Fel - du gl&ouml;mde n&aring;got!');
define('ERR', 'Fel!');
define('FORGOT', 'Du gl&ouml;mde att ange din e-postadress!');
define('SHOPPINGCART', ' - Kundvagn');
define('SENT', 'Ditt l&ouml;senord har skickats');
define('SENTBY', 'Ditt l&ouml;senord har skickats till dig per e-post');
define('LOGIN', 'Logga in h&auml;r!');
define('NOTREGISTERED', 'Din e-postadress &auml;r inte registrerad i v&aring;r databas');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('INVALID', 'Fel - Ogiltigt l&ouml;senord');
define('MUSTCONTAIN', 'L&ouml;senordet f&aring;r inte inneh&aring;lla mellanslag eller specialtecken eller vara l&auml;ngre &auml;n 10 tecken!');
define('WRONG', 'Fel l&ouml;senord!');
define('WRONGPASS', 'L&ouml;senordet du angav var felaktigt.');
define('FORGOT2', 'Du gl&ouml;mde att ge nuvarande kundvagn ett namn!');
?>