<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('ORDERHISTORY', 'Best&auml;llningshistorik f&ouml;r');
define('CUSTOMERID', 'Kund nr.');
define('VIEWPROFILE', 'Visa/&auml;ndra profil');
define('REFERENCE', 'Orderid');
define('DATE', 'Datum');
define('DESCRIPTION', 'Beskrivning');
define('AMOUNT', 'Belopp');
define('TOTAL', 'Totalt');
define('DOWNLOAD', 'Ladda ner');
define('THEWORDLINK', 'L&auml;nk');
define('STATUS', 'Status');
?>