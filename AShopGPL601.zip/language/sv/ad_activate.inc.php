<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('HI', 'Hej');
define('THANKYOU', 'Tack f&ouml;r din best&auml;llning fr&aring;n');
define('PAYMENTRECEIVED', 'Vi har tagit emot din betalning och best&auml;llningen &auml;r slutf&ouml;rd.');
define('FILEDOWNLOAD', 'Ladda ner dina filer');
define('LOGINEMAIL', 'Anv&auml;ndarnamn (e-post)');
define('PASSWORD', 'L&ouml;senord');
define('DIFFICULTIES', 'Om du st&ouml;ter p&aring; n&aring;gra problem med den h&auml;r nedladdningen eller blir fr&aring;nkopplad innan nedladdningen &auml;r slutf&ouml;rd, anv&auml;nd l&auml;nken och l&ouml;senordet fr&aring;n detta meddelande f&ouml;r att ladda ner p&aring; nytt.');
define('PASSWORDVALID', 'Ditt l&ouml;senord &auml;r giltigt f&ouml;r');
define('DOWNLOADSWITHIN', 'nedladdningar inom');
define('DAYS', 'dag(ar).');
define('ACCESS', 'Du kan f&aring; tillg&aring;ng till de l&ouml;senordsskyddade sidor som du prenumererar p&aring; genom att logga in med din e-postadress och l&ouml;senordet');
define('AT', 'p&aring;');
define('DIFFICULTYACCESS', 'Om du st&ouml;ter p&aring; n&aring;gra problem med att f&aring; tillg&aring;ng till de skyddade sidorna s&aring; kan du kontakta oss');
?>