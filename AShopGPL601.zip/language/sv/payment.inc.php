<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('REDIRECTSERV', '&Ouml;ppnar betalningstj&auml;nst, var god v&auml;nta...');
define('DATABASEERROR', 'Tillf&auml;lligt databasfel! ');
define('ALREADYPAID1', 'Redan betalad!');
define('ALREADYPAID2', 'Denna faktura har redan blivit betalad!');
define('NOTEXIST1', 'Fakturan finns inte!');
define('NOTEXIST2', 'N&aring;gon faktura med detta nummer finns inte i v&aring;r databas. Var god f&ouml;rs&ouml;k igen eller kontakta v&aring;r support f&ouml;r hj&auml;lp.');
define('REDIRECTFORM', '&Ouml;ppnar betalningsformul&auml;r...');
define('EMPTYCART', 'Din kundvagn &auml;r tom!');
define('PAYMENTFOR', 'Betalning f&ouml;r faktura nummer:');
define('PRICE', 'Pris:');
define('TAX', 'Moms/Frakt:');
define('AMOUNT', 'Summa att betala:');
define('DISCOUNTED', 'rabatterad');
define('CHOOSE', 'V&auml;lj n&aring;got av f&ouml;ljande betalningsalternativ...');
define('IPLOG1', 'Ditt IP-nummer:');
define('IPLOG2', 'har registrerats av s&auml;kerhetssk&auml;l');
?>