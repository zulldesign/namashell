<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('CONFIRMPAYMENT', 'Klicka "Betala" f&ouml;r att slutf&ouml;ra din best&auml;llning och skicka beloppet: ');
define('PAYMENTDECLINED', 'Din betalning nekades!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('REASON', 'Anledning');
define('ERROR', 'Fel!');
define('SHIPPINGADDRESS', 'Leveransadress:');
define('ORDERDETAILS', 'Best&auml;llning:');
define('SORRY', 'Tyv&auml;rr!');
define('PROXYDETECTED', 'Vi uppt&auml;ckte att du kan vara ansluten via en proxy-server.<br />Av s&auml;kerhetssk&auml;l accepterar vi inte registreringar via proxy.');
define('IPCHECKFAILED', 'Ditt IP-nummer finns i ett annat land &auml;n det du angav. Av s&auml;kerhetssk&auml;l kan vi inte acceptera din best&auml;llning.');
?>