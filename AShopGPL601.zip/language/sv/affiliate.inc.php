<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('INCORRECT', 'Du angav en felaktig h&auml;nvisningskod');
define('TRYAGAIN', 'Var god f&ouml;rs&ouml;k igen...');
define('STRAIGHTTOTHE', '... eller g&aring; direkt till');
define('PRODUCTCATALOG', 'produktkatalogen');
define('WEREYOUREFERRED', 'Blev du h&auml;nvisad till oss av n&aring;gon?');
define('ENTERREFERRAL', 'Var god ange en h&auml;nvisningskod f&ouml;r v&aring;r samarbetspartner f&ouml;r att aktivera eventuella h&auml;nvisningsrabatter...');
define('STRAIGHTTO', '... eller g&aring; direkt till ');
define('THANKYOU', 'Tack! H&auml;nvisningskoden har registrerats!');
define('REDIRECTED', 'Nu kommer du automatiskt att g&aring; till ');
define('IFNOREDIRECT', 'Om sidan inte &ouml;ppnas inom 5 sekunder s&aring; kan du klicka ');
define('HERE', 'h&auml;r');
?>