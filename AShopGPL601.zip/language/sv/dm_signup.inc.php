<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('FORGOTSOMETHING', 'Fel - du gl&ouml;mde n&aring;gonting!');
define('ERROR', 'Fel!');
define('YOUFORGOT', 'Du gl&ouml;mde att fylla i n&aring;got av de obligatoriska f&auml;lten!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('INVALIDUSERNAME', 'Fel - felaktigt anv&auml;ndarnamn');
define('THEUSERNAME', 'Anv&auml;ndarnamnet f&aring;r inte inneh&aring;lla mellanslag eller skiljetecken. Det f&aring;r inte heller vara l&auml;ngre &auml;n 10 tecken.');
define('USERNAMEINUSE', 'Anv&auml;ndarnamnet &auml;r upptaget!');
define('INVALIDSECURITYCODE', 'Fel - felaktig s&auml;kerhetskod');
define('INCORRECTSECURITYCODE', 'S&auml;kerhetskoden matchade inte!');
define('EMAILINUSE', 'E-postadressen &auml;r upptagen!');
define('SORRY', 'Tyv&auml;rr!');
define('ALREADYINUSE', 'Anv&auml;ndarnamnet du skrev &auml;r upptaget!');
define('ALREADYINUSE2', 'E-postadressen du angav &auml;r redan upptagen!');
define('SUBDOMAINEXISTS', 'Butiksnamnet du valde &auml;r redan upptaget!');
define('THANKYOUFORJOINING', 'Tack f&ouml;r att du ans&ouml;kt om ett s&auml;ljarkonto i det virtuella k&ouml;pcentrat p&aring; ');
define('YOURUSERNAMEIS', 'Ditt anv&auml;ndarnamn &auml;r:');
define('YOURPASSWORDIS', ', ditt l&ouml;senord &auml;r:');
define('YOUCANLOGIN', 'Du kan logga in till din administrationspanel p&aring;:');
define('YOUSHOPISLOCATED', 'Din butik finns h&auml;r:');
define('YOURPASSWORD', ', ditt l&ouml;senord kommer att skickas till dig n&auml;r vi har godk&auml;nnt din ans&ouml;kan.');
define('SHOPPINGMALLAPPLICATION', 'Ans&ouml;kan om s&auml;jarkonto i virtuellt k&ouml;pcentra');
define('YOURAPPLICATION', 'Din ans&ouml;kan om s&auml;ljarkonto i det virtuella k&ouml;pcentrat p&aring;');
define('HASBEENRECEIVED', 'har mottagits.');
define('WILLBEREVIEWED', 'Din ans&ouml;kan kommer att kontrolleras manuellt av oss innan ditt medlemskap aktiveras. S&aring; snart den blivit godk&auml;nd skickar vi ett l&ouml;senord och en l&auml;nk till din butik till dig per e-post.');
define('ACCOUNTISACTIVE', 'Ditt konto &auml;r nu aktivt. Ett l&ouml;senord och en l&auml;nk till din nya butik har skickats till dig per e-post.');
?>