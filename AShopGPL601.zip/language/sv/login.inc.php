<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('LOGINMESSAGE', 'Kundinloggning');
define('SIGNUPMESSAGE1', 'Tack f&ouml;r att du registrerat dig som kund!');
define('SIGNUPMESSAGE2', 'Om du redan har registrerat dig som kund kan du logga in h&auml;r:');
define('USER', 'E-post');
define('USERNAME', 'Anv&auml;ndarnamn');
define('PASSWORD', 'L&ouml;senord');
define('LOGIN', 'Logga in');
define('FORGOTPASS', 'Gl&ouml;mt ditt l&ouml;senord?');
define('NEWCUSTOMER', 'Registrera ny kundprofil');
define('WRONGPASS', 'Fel l&ouml;senord!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('LOGGEDOUT', 'Du har loggat ut!');
?>