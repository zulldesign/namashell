<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('SEARCHING', 'S&ouml;ker, var god v&auml;nta...');
define('CATEGORIES', 'Kategorier');
define('ALLCATEGORIES', 'Alla butiker');
define('NEWSHOPS', 'Nya butiker');
define('TEXT', 'S&ouml;k');
define('POWEREDBYASHOP', 'Denna butik anv&auml;nder AShop Software! Kundvagns- och partnermarknadsf&ouml;ringsprogram');
define('SEARCHRESULT', 'S&ouml;kresultat');
define('LATESTADDITIONS', 'Nya butiker');
define('PAGE', 'Sida');
define('NEXTPAGE', 'N&auml;sta');
define('PREVIOUS', 'F&ouml;reg&aring;ende');
define('ERROR1', 'Fel');
define('ERROR2', 'Ett fel har uppst&aring;tt! Kan inte ansluta till butikens databas!');
define('ERROR3', 'Anv&auml;ndarnamnet eller l&ouml;senordet till databasen &auml;r felaktigt!');
define('ERROR4', 'Databasens namn &auml;r felaktigt!');
define('WEBSITE', 'Webbplats');
define('PROMOTESHOP', 'Promota butik');
define('SEARCH', 'S&ouml;k');
?>