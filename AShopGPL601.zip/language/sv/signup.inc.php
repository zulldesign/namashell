<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('FORGOTSOMETHING', 'Fel - du gl&ouml;mde n&aring;gonting!');
define('ERROR', 'Fel!');
define('YOUFORGOT', 'Du gl&ouml;mde att fylla i n&aring;got av de obligatoriska f&auml;lten!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('THEPASSWORD', 'L&ouml;senordet f&aring;r inte inneh&aring;lla mellanslag eller interpunktion. Det f&aring;r inte heller vara l&auml;ngre &auml;n 10 tecken.');
define('INVALIDSECURITYCODE', 'Fel - felaktig s&auml;kerhetskod');
define('INCORRECTSECURITYCODE', 'S&auml;kerhetskoden &auml;r inte korrekt!');
define('USERNAMEINUSE', 'Anv&auml;ndarnamnet &auml;r upptaget!');
define('SORRY', 'Tyv&auml;rr!');
define('ALREADYINUSE', 'E-postadressen du angav &auml;r upptagen!');
define('PROXYDETECTED', 'Vi uppt&auml;ckte att du kan vara ansluten via en proxy-server.<br />Av s&auml;kerhetssk&auml;l accepterar vi inte registreringar via proxy.');
define('THANKYOUFORREGISTERING', 'Tack f&ouml;r att du registrerat dig som kund hos');
define('CUSTOMERPROFILE', 'kundprofil!');
define('CUSTOMERREGISTRATION', 'Kundkonto-registrering hos');
define('YOURUSERNAMEIS', 'Ditt anv&auml;ndarnamn &auml;r:');
define('ANDYOURPASSWORD', ', och ditt l&ouml;senord:');
define('LOGINANDSTART', 'Logga in och b&ouml;rja handla hos');
define('REGISTER', 'Registrera dig');
define('CIDDOESNOTEXIST', 'Kundprofilen du f&ouml;rs&ouml;kte aktivera har redan aktiverats eller finns inte.');
define('YOUARERECEIVING', 'Du f&aring;r detta meddelande eftersom din e-postadress har anv&auml;nts f&ouml;r att registrera en kundprofil p&aring;');
define('PLEASEVERIFY', 'Var god bekr&auml;fta att du vill skapa en kundprofil genom att klicka p&aring; f&ouml;ljande l&auml;nk:');
define('THANKYOUFORREGISTERING', 'Tack f&ouml;r att du anm&auml;lt dig till');
define('CHECKMAIL', 'Du kommer inom kort att f&aring; ett meddelande per e-post med en l&auml;nk som du klickar p&aring; f&ouml;r att aktivera ditt kundkonto.');
?>