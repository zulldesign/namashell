<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('FORGOTSOMETHING', 'Fel - du gl&ouml;mde n&aring;gonting!');
define('ERROR', 'Fel!');
define('YOUFORGOT', 'Du gl&ouml;mde att fylla i n&aring;got av de obligatoriska f&auml;lten!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('YOUFORGOTTAX1', 'Du gl&ouml;mde att ange ditt');
define('YOUFORGOTTAX2', 'nummer!');
define('THEUSERNAME', 'Anv&auml;ndarnamnet f&aring;r inte inneh&aring;lla mellanslag eller skiljetecken. Det f&aring;r inte heller vara l&auml;ngre &auml;n 10 tecken.');
define('INCORRECTSECURITYCODE', 'S&auml;kerhetskoden &auml;r inte korrekt!');
define('USERNAMEINUSE', 'Anv&auml;ndarnamnet &auml;r upptaget!');
define('SORRY', 'Tyv&auml;rr!');
define('ALREADYINUSE', 'Anv&auml;ndarnamnet du skrev &auml;r upptaget!');
define('THANKYOUFORJOINING', 'Tack f&ouml;r att du ans&ouml;kt om ett &aring;terf&ouml;rs&auml;ljarkonto hos');
define('YOURUSERNAMEIS', 'Ditt anv&auml;ndarnamn &auml;r:');
define('YOURPASSWORD', 'ditt l&ouml;senord kommer att skickas till dig n&auml;r vi har godk&auml;nt din ans&ouml;kan.');
define('WHOLESALESUBJECT', 'ans&ouml;kan om &aring;terf&ouml;rs&auml;ljarkonto');
define('YOURAPPLICATION', 'Din ans&ouml;kan om &aring;terf&ouml;rs&auml;ljarkonto hos');
define('HASBEENRECEIVED', 'har skickats in.');
define('WILLBEREVIEWED', 'Din ans&ouml;kan kommer att kontrolleras manuellt innan ditt &aring;terf&ouml;rs&auml;ljarkonto aktiveras. N&auml;r den godk&auml;nts kommer du att f&aring; ett l&ouml;senord och en l&auml;nk till v&aring;r &aring;terf&ouml;rs&auml;ljarkatalog per e-post.');
?>