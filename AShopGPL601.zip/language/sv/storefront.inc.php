<?php
define('HOME', 'Hem');
define('PRODUCTS', 'Produkter');
define('ABOUTUS', 'Om oss');
define('CONTACTUS', 'Kontakta oss');
define('TERMSANDCONDITIONS', 'K&ouml;pvillkor');
define('LANGUAGE', 'Spr&aring;k');
define('CURRENCY', 'Valuta');
define('SEARCH', 'S&ouml;k');
define('YOURCART', 'Din kundvagn:');
define('NEWS', 'Nyheter');
define('WARRANTY', 'Garanti');
define('FEATURED', 'Veckans vara:');
define('FOOTERTEXT', '&copy; 2009 AShop Software');
define('NEWSLETTER', 'Nyhetsbrev');
define('CAMPAIGNS', 'Kampanjer');
define('SUPPORT', 'Kundservice:');
define('DOWNLOADS', 'Nedladdningar');
define('FORUMS', 'Diskussionsforum');
define('PRIVACY', 'Sekretesspolicy');
define('PRESS', 'Press');
define('MEDIA', 'Media');
define('AFFILIATES', 'Bli affiliate');
define('WHOLESALE', '&Aring;terf&ouml;rs&auml;ljare');
define('VENDORS', 'Handlare');
define('YOURACCOUNT', 'Din profil');
define('VIEWCART', 'Kundvagn');
?>