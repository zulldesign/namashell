<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('WELCOME', 'V&auml;lkommen');
define('AFFILIATEID', 'Affiliateid');
define('VIEWPROFILE', '&Auml;ndra dina uppgifter');
define('CHANGEPASS', 'Byt l&ouml;senord');
define('ORDERHISTORY', 'Orderhistorik');
define('STATISTICS', 'Statistik');
define('LINKCODES', 'L&auml;nkkoder');
define('DOWNLINE', 'Downline');
define('LOGOUT', 'Logga ut');
define('LEADS', 'Leads');
define('INBOX', 'Inkorg');
define('YOURLEADS', 'Dina leads');
define('NOLEADSFOUND', 'Inga matchande leads funna.');
define('NOLEADS', 'Du har inga tillg&auml;ngliga leads.');
define('NAME', 'Namn');
define('EMAIL', 'E-post');
define('PHONE', 'Telefon');
define('ORDERS', 'Best&auml;llningar');
define('STATE', 'Stat/provins');
define('PROVINCE', 'Omr&aring;de');
define('COUNTRY', 'Land');
define('CHOOSECOUNTRY', 'Alla l&auml;nder');
define('INTERESTS', 'K&ouml;p');
define('DOWNLOAD', 'Ladda ner CSV');
define('VIEW', 'Visa');
define('PARTIES', 'Partyn');
?>