<?php
define('TOP10', 'Topp 10');
define('LATEST', 'Senaste till&auml;gg');
?>