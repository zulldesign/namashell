<?php
// Swedish language module for AShop
$langname = "Svenska";

// Redirect URL...
$langredirect = "index.php";
?>