<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">');
define('PAYMENTDECLINED', 'Din betalning nekades!');
define('TRYAGAIN', 'F&ouml;rs&ouml;k igen!');
define('REASON', 'Anledning');
define('ERROR', 'Fel!');
define('SHIPPINGADDRESS', 'Leveransadress:');
define('ORDERDETAILS', 'Best&auml;llning:');
?>