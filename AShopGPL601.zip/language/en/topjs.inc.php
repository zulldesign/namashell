<?php
define('TOP10', 'Top 10');
define('LATEST', 'Latest Additions');
?>