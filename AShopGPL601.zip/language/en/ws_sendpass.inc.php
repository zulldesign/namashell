<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('WHOLESALE', 'Wholesale');
define('YOURPASSWORD', 'Your Wholesale Password');
define('YOURPASSWORDFOR', 'Your Wholesale password for');
define('IS', 'is');
define('PASSWORDSENT', 'Your password has been sent');
define('PASSWORDSENTBYEMAIL', 'Your password has been sent to you by email');
define('WHOLESALELOGIN', 'Wholesale Login');
define('NOTREGISTERED', 'You are not registered as a wholesale user');
define('TRYAGAIN', 'Try again!');
define('FORGOTPASSWORD', 'Forgot your password?');
define('ENTERUSERNAME', 'Enter your user name
and we will send you the password to the email address you entered
when you signed up as a wholesale user...');
define('USERNAME', 'User name');
define('SUBMIT', 'Submit');
?>