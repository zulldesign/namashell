<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('WELCOME', 'Welcome');
define('AFFILIATEID', 'Affiliate id');
define('VIEWPROFILE', 'View/Edit Profile');
define('CHANGEPASS', 'Change Password');
define('ORDERHISTORY', 'Order History');
define('STATISTICS', 'Statistics');
define('LINKCODES', 'Link Codes');
define('DOWNLINE', 'Downline');
define('LOGOUT', 'Logout');
define('LEADS', 'Leads');
define('INBOX', 'Inbox');
define('REFERENCE', 'Reference');
define('DATETIME', 'Date, Time');
define('AMOUNT', 'Amount');
define('PAIDBY', 'Paid by');
define('TOTALUNPAID', 'Total unpaid commission');
define('TIER2', 'tier');
define('COMMISSIONHISTORY', 'Commission & Payment History');
define('PARTIES', 'Parties');
?>