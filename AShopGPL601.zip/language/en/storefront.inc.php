<?php
define('HOME', 'Home');
define('PRODUCTS', 'Products');
define('ABOUTUS', 'About Us');
define('CONTACTUS', 'Contact Us');
define('TERMSANDCONDITIONS', 'Terms &amp; Conditions');
define('LANGUAGE', 'Language');
define('CURRENCY', 'Currency');
define('SEARCH', 'Search');
define('YOURCART', 'Your cart:');
define('NEWS', 'News/Links');
define('WARRANTY', 'Warranty');
define('FEATURED', 'Featured product:');
define('FOOTERTEXT', '&copy; 2009 AShop Software');
define('NEWSLETTER', 'Newsletter');
define('CAMPAIGNS', 'Campaigns');
define('SUPPORT', 'Customer Service:');
define('DOWNLOADS', 'Downloads');
define('FORUMS', 'Forums');
define('PRIVACY', 'Privacy Policy');
define('PRESS', 'Press');
define('MEDIA', 'Media');
define('AFFILIATES', 'Affiliates');
define('WHOLESALE', 'Wholesale');
define('VENDORS', 'Vendors');
define('YOURACCOUNT', 'Your Account');
define('VIEWCART', 'View Cart');
?>