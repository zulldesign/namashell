<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('ORDERHISTORY', 'Order history of');
define('CUSTOMERID', 'Customer ID');
define('VIEWPROFILE', 'View/Edit Profile');
define('REFERENCE', 'Order ID');
define('DATE', 'Date');
define('DESCRIPTION', 'Description');
define('AMOUNT', 'Amount');
define('TOTAL', 'Total');
define('DOWNLOAD', 'Download');
define('THEWORDLINK', 'Link');
define('STATUS', 'Status');
?>