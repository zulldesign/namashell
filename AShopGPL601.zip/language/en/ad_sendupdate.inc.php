<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('DOWNLOADUPDATE', 'Download the update at');
define('LOGINWITH', 'Login with the same email address that you used when you purchased this product and with the password');
?>