<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />');
define('SEARCHING', 'Searching, please wait...');
define('CATEGORIES', 'Category Search');
define('ALLCATEGORIES', 'All Shops');
define('NEWSHOPS', 'Latest Additions');
define('TEXT', 'Text Search');
define('POWEREDBYASHOP', 'Powered by AShop Software! Shopping Cart & Affiliate Marketing Software');
define('SEARCHRESULT', 'Search Result');
define('LATESTADDITIONS', 'Latest Additions');
define('PAGE', 'Page');
define('NEXTPAGE', 'Next');
define('PREVIOUS', 'Previous');
define('ERROR1', 'Error');
define('ERROR2', 'An error has occurred accessing this shops database!');
define('ERROR3', 'The username or password used to access the database is incorrect!');
define('ERROR4', 'The name of the database is incorrect!');
define('WEBSITE', 'Website');
define('PROMOTESHOP', 'Promote Shop');
define('SEARCH', 'Search');
?>