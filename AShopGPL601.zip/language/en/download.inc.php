<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('WAIT', 'Initializing download. Please wait...');
define('BACK', 'Back to delivery page.');
define('WRONGPASS', ' - Wrong Password or Email!');
define('NOACCESS', 'Download information missing! This could happen if your browser is blocking cookies. Try reducing the privacy level settings in your browser or make sure cookies are not being blocked.');
define('DLLOGIN', 'Use the delivery page to login.');
define('CLICK', 'Click here');
define('WRONGPASSWORD', 'The password or email you entered is incorrect!');
define('UNAUTHORIZED', ' - unauthorized delivery!');
define('NOTALLOW', 'You are not allowed to download this product with your password!');
define('AUTOREPORT', 'This has been automatically reported to us!');
define('LIMIT', ' - download limit exceeded!');
define('ALREADY', 'You have already downloaded this file the allowed number of times.');
define('EXPIRED', ' - download time expired!');
define('TIMEEXPIRED', 'Your allowed time to download this product has expired!');
define('ERROR', 'An error has occurred!');
define('ERRORTITLE', "error!");
define('COULDNOTDOWNLOAD', 'This product could not be downloaded.');
define('TRYAGAIN', 'Try again!');
?>