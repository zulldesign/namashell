<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('CUSTOMERPROFILE', 'customer profile!');
define('YOURPASSWORD', 'Your Customer Password');
define('YOURPASSWORDFOR', 'The password for your customer profile at');
define('IS', 'is');
define('PASSWORDSENT', 'Your password has been sent');
define('PASSWORDSENTBYEMAIL', 'Your password has been sent to you by email');
define('CUSTOMERLOGIN', 'Customer Login');
define('NOTREGISTERED', 'You are not registered as a customer');
define('TRYAGAIN', 'Try again!');
define('FORGOTPASSWORD', 'Forgot your password?');
define('ENTERUSERNAME', 'Enter your email and we will mail you the password...');
define('USERNAME', 'Email');
define('SUBMIT', 'Submit');
?>