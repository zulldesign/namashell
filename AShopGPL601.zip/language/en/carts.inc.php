<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('ERROR', 'Error - you forgot something!');
define('ERR', 'Error!');
define('FORGOT', 'You forgot to fill in your email address!');
define('SHOPPINGCART', ' - Shopping Cart');
define('SENT', 'Your password has been sent');
define('SENTBY', 'Your password has been sent to you by email');
define('LOGIN', 'Login here!');
define('NOTREGISTERED', 'Your email is not registered in our database');
define('TRYAGAIN', 'Try again!');
define('INVALID', 'Error - Invalid Password');
define('MUSTCONTAIN', 'The password must not contain spaces or punctuation or exceed 10 characters in length!');
define('WRONG', 'Wrong password!');
define('WRONGPASS', 'The password you entered was incorrect.');
define('FORGOT2', 'You forgot to enter a name for the current shopping cart!');
?>