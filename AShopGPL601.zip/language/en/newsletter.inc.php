<?php
define('NEWSLETTERSIGNUP', 'Get special offers and discounts!');
define('NLSIGNUP', 'Signup to receive updates and news by email...');
define('NLNAME', 'Name');
define('NLEMAIL', 'Email');
define('NLCODE', 'Code');
define('NLCLOSE', 'Close');
define('NLCODEDIDNOTMATCH', 'Security code did not match! Try again...');
define('NLSECURITYCODE', 'Security Code');
define('NLNOSPAM', 'We hate spam as much as you do and<br>will never give your email to anyone.');
define('NLTHANKYOU', 'Thank you for subscribing!');
?>