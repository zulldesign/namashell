<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('FORGOTSOMETHING', 'Error - you forgot something!');
define('ERROR', 'Error!');
define('YOUFORGOT', 'You forgot to fill in one of the required fields!');
define('TRYAGAIN', 'Try again!');
define('YOUFORGOTTAX1', 'You forgot to provide your');
define('YOUFORGOTTAX2', 'number!');
define('THEUSERNAME', 'The user name must not contain spaces or punctuation or exceed 10 characters in length!');
define('INCORRECTSECURITYCODE', 'Security code did not match!');
define('USERNAMEINUSE', 'Username already in use!');
define('SORRY', 'Sorry!');
define('ALREADYINUSE', 'The username or email address you wrote is already in use!');
define('THANKYOUFORJOINING', 'Thank you for applying for a wholesale account at');
define('YOURUSERNAMEIS', 'Your user name is:');
define('YOURPASSWORD', 'your password will be sent to you when we have approved your application.');
define('WHOLESALESUBJECT', 'wholesale account application');
define('YOURAPPLICATION', 'Your wholesale account application at');
define('HASBEENRECEIVED', 'has been received.');
define('WILLBEREVIEWED', 'Your application will be reviewed by a live person before your wholesale membership is activated. Once approved, a password and link to the wholesale catalogue will be emailed to you.');
?>