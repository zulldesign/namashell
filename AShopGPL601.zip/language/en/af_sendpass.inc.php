<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('AFFILIATEPROGRAM', 'affiliate program');
define('YOURPASSWORD', 'Your Affiliate Password');
define('YOURPASSWORDFOR', 'Your affiliate password for');
define('IS', 'is');
define('PASSWORDSENT', 'Your password has been sent');
define('PASSWORDSENTBYEMAIL', 'Your password has been sent to you by email');
define('AFFILIATELOGIN', 'Affiliate Login');
define('NOTREGISTERED', 'You are not registered in our affiliateprogram');
define('TRYAGAIN', 'Try again!');
define('FORGOTPASSWORD', 'Forgot your password?');
define('ENTERUSERNAME', 'Enter your user name and we will send you the password to the email<br>address you entered when you signed up with our affiliate program...');
define('USERNAME', 'User name');
define('SUBMIT', 'Submit');
?>