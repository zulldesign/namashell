<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('TOCOMPLETEORDER', 'To complete this order, you must<br>accept the terms of sale!');
define('CLOSE', 'Close this window');
define('ERROR', 'Error! The item you ordered is not in our catalogue!');
define('NOTFOUND', 'Item Not Found');
define('NOTINCATALOGUE', 'The selected item is not found in the catalogue. Try another link for this item or contact the store administrator for help.');
define('TRYAGAIN', 'Try again!');
define('ADD', 'Add To Wishlist');
define('ITEM', 'Item');
define('SELECTOPTIONS', 'Select Options');
define('TERMSFOR', 'for');
define('PUTINCART', 'Add to wishlist');
define('CANCEL', 'Cancel');
define('HASBEENADDED', 'has been added to your wishlist');
?>