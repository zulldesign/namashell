<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('LICENSEAGREE1', ' - License Agreement For ');
define('LICENSEAGREE2', 'License Agreement For ');
define('WINDOWCLOSE', 'Close this window');
define('PURCHASEAGREEMENT', 'Purchase Agreement');
?>