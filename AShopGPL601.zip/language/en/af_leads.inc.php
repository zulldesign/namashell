<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('WELCOME', 'Welcome');
define('AFFILIATEID', 'Affiliate id');
define('VIEWPROFILE', 'View/Edit Profile');
define('CHANGEPASS', 'Change Password');
define('ORDERHISTORY', 'Order History');
define('STATISTICS', 'Statistics');
define('LINKCODES', 'Link Codes');
define('DOWNLINE', 'Downline');
define('LOGOUT', 'Logout');
define('LEADS', 'Leads');
define('INBOX', 'Inbox');
define('YOURLEADS', 'Your Leads');
define('NOLEADSFOUND', 'No matching leads found.');
define('NOLEADS', 'You have no leads available.');
define('NAME', 'Name');
define('EMAIL', 'Email');
define('PHONE', 'Phone');
define('ORDERS', 'Orders');
define('STATE', 'State/Province');
define('PROVINCE', 'Region');
define('COUNTRY', 'Country');
define('CHOOSECOUNTRY', 'All Countries');
define('INTERESTS', 'Purchases');
define('DOWNLOAD', 'Download CSV');
define('VIEW', 'View');
define('PARTIES', 'Parties');
?>