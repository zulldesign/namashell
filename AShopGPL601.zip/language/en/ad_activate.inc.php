<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('HI', 'Hi');
define('THANKYOU', 'Thank you for your order from');
define('PAYMENTRECEIVED', 'Your payment has been received and the order is fulfilled.');
define('FILEDOWNLOAD', 'Product File Download');
define('LOGINEMAIL', 'Login eMail');
define('PASSWORD', 'Password');
define('DIFFICULTIES', 'If you experience any difficulty with this download or lose your connection before the download is complete, use the link and password from your e-mail receipt for a fresh download.');
define('PASSWORDVALID', 'Your password will be valid for');
define('DOWNLOADSWITHIN', 'downloads within');
define('DAYS', 'day(s).');
define('ACCESS', 'You can access the protected directories you have subscribed to by logging in with your email address and the password');
define('AT', 'at');
define('DIFFICULTYACCESS', 'If you experience any difficulty accessing these directories contact us');
?>