<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('INCORRECT', 'You entered an incorrect referral code');
define('TRYAGAIN', 'Please try again...');
define('STRAIGHTTOTHE', '... or go straight to the');
define('PRODUCTCATALOG', 'productcatalog');
define('WEREYOUREFERRED', 'Were you referred to us by someone?');
define('ENTERREFERRAL', 'Please enter a referral code to give our affiliate credit and to receive referral discounts...');
define('STRAIGHTTO', '... or go straight to ');
define('THANKYOU', 'Thank you. The referral code has been accepted!');
define('REDIRECTED', 'You will now be automatically redirected to ');
define('IFNOREDIRECT', 'If the page does not redirect within 5 seconds, please click ');
define('HERE', 'here');
?>