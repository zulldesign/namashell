<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('NOTREGISTERED', 'You haven\'t registered!');
define('SORRY', 'Sorry!');
define('USERNAMENOTREGISTERED', 'Your user name or email address is not registered.');
define('TRYAGAIN', 'Try again!');
define('WRONGPASS', 'Wrong password!');
define('INCORRECTPASS', 'The password you entered was incorrect.');
define('WELCOME', 'Welcome');
define('AFFILIATEID', 'Affiliate id');
define('VIEWPROFILE', 'View/Edit Profile');
define('CHANGEPASSBTN', 'Change Password');
define('ORDERHISTORY', 'Order History');
define('STATISTICS', 'Statistics');
define('LINKCODES', 'Link Codes');
define('DOWNLINE', 'Downline');
define('LOGOUT', 'Logout');
define('LEADS', 'Leads');
define('INBOX', 'Inbox');
define('DIDNOTMATCH', 'The passwords did not match!');
define('ERROR', 'Error!');
define('CHANGEPASS', 'Change your affiliate password');
define('OLDPASS', 'Old password');
define('NEWPASS', 'New password');
define('CONFIRM', 'Confirm');
define('UPDATE', 'Update');
define('PARTIES', 'Parties');
?>