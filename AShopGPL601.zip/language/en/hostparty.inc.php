<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('HOSTAPARTY', 'Host a Party');
define('HOSTAPARTYMESSAGE', 'Fill out the form below with the details of your party plan and we will get back to you with confirmation...');
define('EDITPARTYMESSAGE', 'Edit the party by changing the details in the form below...');
define('DATEANDTIME', 'When do you want to host the party?');
define('LOCATION', 'Where will the party take place?');
define('COMMENTS', 'Comments');
define('JAN', 'Jan');
define('FEB', 'Feb');
define('MAR', 'Mar');
define('APR', 'Apr');
define('MAY', 'May');
define('JUN', 'Jun');
define('JUL', 'Jul');
define('AUG', 'Aug');
define('SEP', 'Sep');
define('OCT', 'Oct');
define('NOV', 'Nov');
define('DEC', 'Dec');
define('FIRSTNAME', 'First name');
define('LASTNAME', 'Last name');
define('EMAIL', 'Email');
define('SECURITYCODE', 'Security code');
define('TYPESECURITYCODE', 'Type security code');
define('ERROR', 'Error!');
define('TRYAGAIN', 'Try again!');
define('INCORRECTSECURITYCODE', 'Security code did not match!');
define('SORRY', 'Sorry!');
define('PROXYDETECTED', 'We detected that you might be on a proxy connection.<br />For security reasons we do not accept customer registrations on a proxy.');

?>