<?php
// English language module for AShop Deluxe
$langname = "English";

// Redirect URL...
//$langredirect = "layoutexample.html";
?>