<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('CONFIRMPAYMENT', 'Press "Pay" to complete your order and send the amount: ');
define('PAYMENTDECLINED', 'Your payment was declined!');
define('TRYAGAIN', 'Try again!');
define('REASON', 'Reason');
define('ERROR', 'Error!');
define('SHIPPINGADDRESS', 'Shipping address:');
define('ORDERDETAILS', 'Order details:');
define('SORRY', 'Sorry!');
define('PROXYDETECTED', 'We detected that you might be on a proxy connection.<br />For security reasons we do not accept purchases on a proxy.');
define('IPCHECKFAILED', 'Your IP is located in a different country than the one you selected.<br />For security reasons we can not accept your purchase.');
?>