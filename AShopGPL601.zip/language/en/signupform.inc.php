<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />');
define('CREATEPROFILE', 'Create New Customer Profile');
define('ALREADYSIGNEDUP', 'Already signed up?');
define('LOGINHERE', 'Login Here');
define('SIGNUPMESSAGE', 'By registering a customer profile you will be able to shop quicker and easier at ');
define('REGISTER', 'Register');
define('FORM', 'Form');
define('PASSWORD', 'Password');
define('CONFIRMPASSWORD', 'Confirm password');
define('FIRSTNAME', 'First name');
define('LASTNAME', 'Last name');
define('EMAIL', 'Email');
define('SECURITYCODE', 'Security code');
define('TYPESECURITYCODE', 'Type security code');
define('YESEMAILME', 'Yes, I want to receive offers and news from this shop by email.');
define('SUBMIT', 'Submit');
?>