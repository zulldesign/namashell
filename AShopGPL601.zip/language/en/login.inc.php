<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('LOGINMESSAGE', 'Customer Login');
define('SIGNUPMESSAGE1', 'Thank you for registering as a customer!');
define('SIGNUPMESSAGE2', 'If you have already registered as a customer you can log in here:');
define('USER', 'Email');
define('USERNAME', 'Username');
define('PASSWORD', 'Password');
define('LOGIN', 'Login');
define('FORGOTPASS', 'Forgot your password?');
define('NEWCUSTOMER', 'New Customer Signup');
define('WRONGPASS', 'Wrong password!');
define('TRYAGAIN', 'Try again!');
define('LOGGEDOUT', 'You have been logged out!');
?>