<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('CLICKHERE', 'Click here!');
define('YOURHTMLCODE', 'Your link code for the shop');
define('COPYHTMLCODE', 'Copy the following code and paste it into your web pages to start making money...');
define('BACKTOMALL', 'Back to shopping mall');
define('NOTREGISTERED', 'You are not registered in our affiliateprogram');
define('TRYAGAIN', 'Try again!');
define('PROMOTESHOP', 'Promote the shop ');
define('ENTERAFFILIATEID', 'You can make money by helping this shop sell their products. Enter your affiliate ID to generate a link code that you can copy and paste into your web pages...');
define('AFFILIATEID', 'Affiliate ID');
define('SUBMIT', 'Submit');
define('NOAFFID', 'No affiliate ID?');
define('NEWAFFILIATE', 'Sign up with our affiliate program');
?>