<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('AFFILIATEPROGRAM', 'Affiliate Program');
define('WRONGPASSWORD', 'Wrong password!');
define('TRYAGAIN', 'Try again!');
define('LOGINMESSAGE', 'Make some money helping us sell our products...');
define('SIGNUPMESSAGE1', 'Thank you for signing up with our affiliate program!<br>Your user name and password has been mailed to you. Depending on how busy the mail server is, it may take 1 to 15 minutes to arrive at your mailbox. Check your mail and login...');
define('SIGNUPMESSAGE2', 'If you have already signed up with our affiliate program you can log in here:');
define('USER', 'User');
define('PASSWORD', 'Password');
define('LOGIN', 'Login');
define('FORGOTPASS', 'Forgot your password?');
define('NEWAFFILIATE', 'New Affiliate Signup');
define('PARTIES', 'Parties');
?>