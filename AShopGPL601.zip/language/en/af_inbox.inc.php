<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('WELCOME', 'Welcome');
define('AFFILIATEID', 'Affiliate id');
define('VIEWPROFILE', 'View/Edit Profile');
define('CHANGEPASS', 'Change Password');
define('ORDERHISTORY', 'Order History');
define('STATISTICS', 'Statistics');
define('LINKCODES', 'Link Codes');
define('DOWNLINE', 'Downline');
define('LOGOUT', 'Logout');
define('LEADS', 'Leads');
define('INBOX', 'Inbox');
define('SUBJECT', 'Subject');
define('RECEIVED', 'Received');
define('FROM', 'From');
define('SPONSOR', '[Sponsor]');
define('UPLINE', '[Upline]');
define('SHOPADMIN', 'Administrator');
define('MESSAGES', 'Message Archive');
define('UNREAD', 'Unread Messages');
define('NOMESSAGES', 'You Have No Messages');
define('PARTIES', 'Parties');
?>