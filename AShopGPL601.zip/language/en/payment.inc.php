<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('REDIRECTSERV', 'Redirecting to payment service, please wait...');
define('DATABASEERROR', 'Temporary database error! ');
define('ALREADYPAID1', 'Already Paid!');
define('ALREADYPAID2', 'This invoice has already been paid!');
define('NOTEXIST1', 'The Invoice Does Not Exist!');
define('NOTEXIST2', 'An invoice with that number does not exist. Please try again or contact our customer service department for assistance.');
define('REDIRECTFORM', 'Redirecting to payment form...');
define('EMPTYCART', 'Your shopping cart is empty!');
define('PAYMENTFOR', 'Payment for invoice number:');
define('PRICE', 'Price:');
define('TAX', 'Tax/Shipping:');
define('AMOUNT', 'Amount to pay:');
define('DISCOUNTED', 'discounted');
define('CHOOSE', 'Choose one of the following payment options...');
define('IPLOG1', 'Your IP number');
define('IPLOG2', 'has been logged for security');
?>