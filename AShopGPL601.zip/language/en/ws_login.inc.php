<?php
define('CHARSET', '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />');
define('WHOLESALELOGIN', 'Wholesale Login');
define('WRONGPASSWORD', 'Wrong password!');
define('TRYAGAIN', 'Try again!');
define('USER', 'User');
define('PASSWORD', 'Password');
define('LOGIN', 'Login');
define('FORGOTPASS', 'Forgot your password?');
define('NEWWSCUSTOMER', 'New Wholesale Customer Signup');
?>