<?php
// Default theme for BShop
$themename = "Standard";

// Allowed languages...
$themelanguages = array("en");

// Override buttons...
$usethemebuttons = "true";

// Override templates...
$usethemetemplates = "true";

// Use condensed catalogue layout...
$usecondensedlayout = "false";
?>