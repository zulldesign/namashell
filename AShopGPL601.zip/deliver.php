<?php
// AShop
// Copyright 2016 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

unset($shop);
unset($userid);
include "admin/config.inc.php";
include "admin/ashopfunc.inc.php";

// Apply selected theme...
$buttonpath = "";
$templatepath = "/templates";
if ($ashoptheme && $ashoptheme != "none" && file_exists("$ashoppath/themes/$ashoptheme/theme.cfg.php")) include "themes/$ashoptheme/theme.cfg.php";
if ($usethemebuttons == "true") $buttonpath = "themes/$ashoptheme/";
if ($usethemetemplates == "true") $templatepath = "/themes/$ashoptheme";
if ($lang && is_array($themelanguages)) {
	if (!in_array("$lang",$themelanguages)) unset($lang);
}

// Include language file...
if (!isset($lang) || !preg_match("/[a-z]+/", $lang) || strlen($lang) > 2) $lang = $defaultlanguage;
include "language/$lang/deliver.inc.php";

// Get the path to the logo image for error messages...
if ($ashopuser && file_exists("$ashoppath/members/files/$ashopuser/logo.gif")) $ashoplogopath = "$ashoppath/members/files/$ashopuser";
else $ashoplogopath = "images";

// Check if a mobile device is being used...
$device = ashop_mobile();

if (!$password || !$email) {

	if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplateheader("$ashoppath$templatepath/delivery-$lang.html");
	else ashop_showtemplateheader("$ashoppath$templatepath/delivery.html");

	echo "<div class=\"span5\">\n<p>".DOWNLOADPRODUCTS."</p><p>".PROBLEMS;
  if ($ashopphone) echo "<br>".PHONE." $ashopphone";
  if ($ashopemail) {
	  $safedisplayemail = str_replace("@","<img src=\"images/at.gif\" align=\"absbottom\">",$ashopemail);
	  echo "<br>".EMAILASHOP." $safedisplayemail";
  }
  if ($ashopaddress) echo "<br>".MAIL." $ashopaddress";
echo "</p></div>\n<div class=\"span7\">
    <form method=\"post\" action=\"deliver.php\">
    <div class=\"control-group\"> 
        <label class=\"control-label\">".EMAILLOGIN.":</label>
		<div class=\"controls\">
		  <input type=\"text\" name=\"email\" class=\"input-xlarge\">
		</div>
	</div>
    <div class=\"control-group\"> 
        <label class=\"control-label\">".PASSWORD.":</label>
		<div class=\"controls\">
		  <input type=\"password\" name=\"password\" class=\"input-xlarge\">
		</div>
	</div>
	<p><button class=\"btn btn-inverse\">".LOGIN."</button></p>
    </form>\n<br><br><br><br><br><br><br><br></div>\n";
	if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplatefooter("$ashoppath$templatepath/delivery-$lang.html");
	  else ashop_showtemplatefooter("$ashoppath$templatepath/delivery.html");
    exit;
}

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

// Check login information...
$isgift = "false";
$isupdate = "false";
$sql="SELECT customer.firstname, customer.lastname, orders.products, orders.orderid, orders.date, orders.paid, orders.payoptionid, orders.userid, orders.description FROM customer, orders WHERE orders.password='$password' AND (customer.email='$email' OR customer.alternativeemails LIKE '%$email%') AND orders.customerid=customer.customerid";
$result = @mysqli_query($db, "$sql");
if (@mysqli_num_rows($result) == 0) {
	$sql="SELECT * FROM updates WHERE password='$password'";
	$result2 = @mysqli_query($db, "$sql");
	if (@mysqli_num_rows($result2) == 0) {
		if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplateheader("$ashoppath$templatepath/delivery-$lang.html");
		else ashop_showtemplateheader("$ashoppath$templatepath/delivery.html");
		echo "<div class=\"span12\">\n<h4 class=\"text-center\">".PASSINCORRECT."</h4>
		<p class=\"text-center\"><a href=\"javascript:history.back()\">".TRYAGAIN."</a></p></div>\n";
		if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplatefooter("$ashoppath$templatepath/delivery-$lang.html");
		else ashop_showtemplatefooter("$ashoppath$templatepath/delivery.html");
		exit;
	} else {
		$updateproductid = @mysqli_result($result2, 0, "productid");
		$sql = "SELECT * FROM customer, orders WHERE (orders.products LIKE '%b$updateproductid"."a%' OR orders.products LIKE '%b$updateproductid"."d%') AND orders.customerid = customer.customerid AND customer.email = '$email' AND orders.paid != ''";
		$result3 = mysqli_query($db, "$sql");
		if (@mysqli_num_rows($result3) == 0) {
			if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplateheader("$ashoppath$templatepath/delivery-$lang.html");
			else ashop_showtemplateheader("$ashoppath$templatepath/delivery.html");
			echo "<div class=\"span12\">\n<h4 class=\"text-center\">".PASSINCORRECT."</h4>
			<p class=\"text-center\"><a href=\"javascript:history.back()\">".TRYAGAIN."</a></p></div>\n";
			if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplatefooter("$ashoppath$templatepath/delivery-$lang.html");
			else ashop_showtemplatefooter("$ashoppath$templatepath/delivery.html");
			exit;
		} else {
			$alloweddownloaddays = @mysqli_result($result2, 0, "alloweddays");
			$updatecaption = @mysqli_result($result2, 0, "title");
			$isupdate = "true";
		}
	}
}

// Check if this is a gift...
$description = explode("|",@mysqli_result($result,0,"description"));
if ($description[0] == "gift") {
	$isgift = "true";
	$giftdate = date("Y-m-d H:i:s", $description[1]);
}

// Check allowed download time...
if ($alloweddownloaddays) {
	$payoption = @mysqli_result($result, 0, "payoptionid");
	$result4 = @mysqli_query($db, "SELECT deliverpending FROM payoptions WHERE payoptionid='$payoption'");
	$deliverpending = @mysqli_result($result4, 0, "deliverpending");
	if ($isgift == "true") $orderdate = explode(" ",$giftdate);
	else if ($isupdate == "false" && $deliverpending) $orderdate = explode(" ",@mysqli_result($result, 0, "date"));
	else if ($isupdate == "false") $orderdate = explode(" ",@mysqli_result($result, 0, "paid"));
	else $orderdate = explode(" ",@mysqli_result($result2, 0, "date"));
	$orderdate = explode ("-",$orderdate[0]);
	$orderedtimestamp = mktime(0,0,0, (int) $orderdate[1], (int) $orderdate[2], (int) $orderdate[0]);
	if ((floor((time()+$timezoneoffset)/86400))*86400 - $orderedtimestamp > 86400 * ($alloweddownloaddays+1)) {
		if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplateheader("$ashoppath$templatepath/delivery-$lang.html");
		else ashop_showtemplateheader("$ashoppath$templatepath/delivery.html");
		echo "<div class=\"span12\">\n<h4 class=\"text-center\">".TIMEEXPIRED."</h4>
		<p class=\"text-center\"><a href=\"javascript:history.back()\">".TRYAGAIN."</a></p></div>\n";
		if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplatefooter("$ashoppath$templatepath/delivery-$lang.html");
		else ashop_showtemplatefooter("$ashoppath$templatepath/delivery.html");
		exit;
	}
}

// Display download page or start download...
if (@mysqli_num_rows($result) || @mysqli_num_rows($result2)) {
  if ($isupdate == "false") {
	  $orderid = @mysqli_result($result, 0, "orderid");
	  $firstname = @mysqli_result($result, 0, "firstname");
	  $lastname = @mysqli_result($result, 0, "lastname");
	  $products = ashop_striphandlingcost(@mysqli_result($result, 0, "products"));
  } else {
	  $products = "1b$updateproductid"."a";
	  $filename = @mysqli_result($result2, 0, "filename");
  }
  $items = ashop_parseproductstring($db, $products);
  if ($file) {
	  $fileidresult = @mysqli_query($db, "SELECT fileid, storage FROM productfiles WHERE id='$file'");
	  $fileid = @mysqli_result($fileidresult,0,"fileid");
	  $storage = @mysqli_result($fileidresult,0,"storage");
	  $notallowed = "false";
	  if ($alloweddownloads && $isupdate == "false") {
		  $downloadsresult = @mysqli_query($db, "SELECT * FROM orderdownloads WHERE fileid='$fileid' AND orderid='$orderid'");
		  $thisdownloads = @mysqli_result($downloadsresult, 0, "downloads");
		  if ($thisdownloads >= $alloweddownloads) $notallowed = "true";
	  }
	  $fileinfo = pathinfo($filename);
	  $extension = strtolower($fileinfo["extension"]);
	  if (($extension == "mp4" || $extensions == "flv") && file_exists("$ashoppath/includes/aws/aws-config.php") && $storage == "1") $downloadscript = "viewstream.php";
	  else $downloadscript = "download.php";
	  if (!$p3psent) header('P3P: CP="IDC DSP COR CURa ADMa OUR IND PHY ONL COM STA"');
	  $p3psent = TRUE;
	  setcookie("fileid","$file");
	  setcookie("password","$password");
	  setcookie("email","$email");
	  if ($notallowed == "false") { 
		  if (strstr($HTTP_USER_AGENT,"Opera")) {
			  if (strstr($SERVER_SOFTWARE, "IIS")) {
				  echo "<html><head><meta http-equiv=\"Refresh\" content=\"0; URL=$downloadscript?dorefresh=true&filename=$filename\"></head></html>";
			  } else header("Location: $downloadscript?dorefresh=true&filename=$filename"); 
			  exit; 
		  } else if (strstr($HTTP_USER_AGENT,"Netscape/7.0")) {
			  if (strstr($SERVER_SOFTWARE, "IIS")) {
				  echo "<html><head><meta http-equiv=\"Refresh\" content=\"0; URL=$downloadscript/?$filename\"></head></html>";
			  } else header("Location: $downloadscript/?$filename"); 
			  exit; 
		  } else { 
			  if (strstr($SERVER_SOFTWARE, "IIS")) {
				  echo "<html><head><meta http-equiv=\"Refresh\" content=\"0; URL=$downloadscript?$filename\"></head></html>";
			  } else header("Location: $downloadscript?$filename");
			  exit;
		  }
	  } else { 
		  if (strstr($SERVER_SOFTWARE, "IIS")) {
				  echo "<html><head><meta http-equiv=\"Refresh\" content=\"0; URL=$downloadscript?notallowed=true\"></head></html>";
		  } else header("Location: $downloadscript?notallowed=true");
		  exit; 
	  }
  } else {
	if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplateheader("$ashoppath$templatepath/delivery-$lang.html");
	else ashop_showtemplateheader("$ashoppath$templatepath/delivery.html");
    echo "<div class=\"span12\">\n";
	if ($isupdate != "true") {
		echo "<p class=\"text-center\">".WELCOME;
		if ($firstname && $lastname) echo " $firstname $lastname";
		echo "!</p>";
	}
	  $downloadstodisplay = 0;
	  if ($items) foreach ($items as $productnumber => $thisproduct) {
		  $awsviewshown = FALSE;
		  $alreadyshown = FALSE;
		  $attributedownload = $thisproduct["download"];
		  $name = $thisproduct["name"];
		  $prodtype = $thisproduct["producttype"];
		  if ($isupdate == "false") $filenames = $thisproduct["filename"];
		  if ($isupdate == "false" && $filenames && $attributedownload != "none") foreach ($filenames as $fileid => $filename) {
			  if ($attributedownload == $fileid || $attributedownload == "all") {
				  $fileidresult = @mysqli_query($db, "SELECT * FROM productfiles WHERE fileid='$fileid' AND productid='{$thisproduct["productid"]}'");
				  $fid = @mysqli_result($fileidresult,0,"id");
				  $storage = @mysqli_result($fileidresult,0,"storage");
				  $downloadsresult = @mysqli_query($db, "SELECT * FROM orderdownloads WHERE orderid='$orderid' AND fileid='$fileid'");
				  $downloadsperitem = @mysqli_result($downloadsresult,0,"downloads");
				  $fileinfo = pathinfo($filename);
				  $extension = strtolower($fileinfo["extension"]);
				  if ($downloadsperitem < $alloweddownloads || !$alloweddownloads) {
					  if (($extension == "mp4" || $extensions == "flv") && file_exists("$ashoppath/includes/aws/aws-config.php") && $storage == "1") {
						  if (!$awsviewshown) {
							  $awsviewshown = TRUE;
							  echo "<p class=\"text-center\">".COPY."&quot;$name";
							  echo "&quot; ".CANBEVIEWED.":</p><p class=\"text-center\"><form action=\"deliver.php\" method=\"post\"><input type=\"hidden\" name=\"file\" value=\"$fid\"><input type=\"hidden\" name=\"email\" value=\"$email\"><input type=\"hidden\" name=\"password\" value=\"$password\"><input type=\"hidden\" name=\"filename\" value=\"$filename\"><button class=\"btn btn-inverse\">".VIEW."</button></form></p>";
							  $downloadstodisplay++;
						  }
					  } else {
						  echo "<p class=\"text-center\">".COPY."&quot;$name";
						  if (count($filenames) > 1 && ($attributedownload == "all" || $isgift)) echo " ($filename)";
						  echo "&quot; ".CAN.":</p><form action=\"deliver.php\" method=\"post\"><input type=\"hidden\" name=\"file\" value=\"$fid\"><input type=\"hidden\" name=\"email\" value=\"$email\"><input type=\"hidden\" name=\"password\" value=\"$password\"><input type=\"hidden\" name=\"filename\" value=\"$filename\"><p class=\"text-center\"><button class=\"btn btn-inverse\">".DOWNLOAD."</button></form></p>";
						  $downloadstodisplay++;
					  }
				  } else if ($downloadsperitem >= $alloweddownloads && !$alreadyshown) {
					  if (($extension == "mp4" || $extensions == "flv") && file_exists("$ashoppath/includes/aws/aws-config.php") && $storage == "1") $alreadyshown = TRUE;
					  echo "<p class=\"text-center\">".ALREADY." &quot;$name&quot; ".ALLOWED."</p>";
				  }
			  }
		  } else if ($isupdate == "true") {
			  echo "<p class=\"text-center\">";
			  if ($updatecaption) echo $updatecaption;
			  else echo UPDATECOPY."&quot;$name&quot; ".CAN.":";
			  echo "</p><p class=\"text-center\"><form action=\"deliver.php\" method=\"post\"><input type=\"hidden\" name=\"file\" value=\"$updateproductid\"><input type=\"hidden\" name=\"email\" value=\"$email\"><input type=\"hidden\" name=\"password\" value=\"$password\"><input type=\"hidden\" name=\"filename\" value=\"$filename\"><input type=\"hidden\" name=\"isupdate\" value=\"true\"><input type=\"submit\" value=\"".DOWNLOAD."\"></form></p>";
			  $downloadstodisplay++;
		  }
	  }
	  $limiteddays = "$alloweddownloaddays";
	  $unlimiteddays = "unlimited";
	  if ($downloaddays = ( $alloweddownloaddays > 0 ? $limiteddays : $unlimiteddays ));

	  $limiteddownloads = "$alloweddownloads";
	  $unlimiteddownloads = "unlimited";
	  if ($downloadtimes = ( $alloweddownloads > 0 ? $limiteddownloads : $unlimiteddownloads ));
	  if ($isupdate == "true") $downloadtimes = "unlimited";
	  if ($downloadstodisplay) echo "<p class=\"text-center\">".WHENCLICK."<b>".SAVE."</b>".BROWSE."</p><p class=\"text-center\">".VALID."$downloadtimes ".PER." $downloaddays".CONNECTION."</p>";
	  echo "<p class=\"text-center\">".CONTACT."<a href='mailto:$ashopemail'>".ADMIN."</a>.</p>\n<br><br><br><br><br><br><br><br>\n</div>\n";
	  if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplatefooter("$ashoppath$templatepath/delivery-$lang.html");
	  else ashop_showtemplatefooter("$ashoppath$templatepath/delivery.html");
  }
} else {
	if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplateheader("$ashoppath$templatepath/delivery-$lang.html");
	else ashop_showtemplateheader("$ashoppath$templatepath/delivery.html");
	echo "<div class=\"span12\">\n<h4 class=\"text-center\">".WRONGDELIV."</h4>
	<p class=\"text-center\">".NOACCESS."</p>
	<p class=\"text-center\"><a href=\"javascript:history.back()\">".TRYAGAIN."</a></p></div>";
	if ($lang != $defaultlanguage && file_exists("$ashoppath$templatepath/delivery-$lang.html")) ashop_showtemplatefooter("$ashoppath$templatepath/delivery-$lang.html");
	else ashop_showtemplatefooter("$ashoppath$templatepath/delivery.html");
}
// Close database connection...
@mysqli_close($db);
?>