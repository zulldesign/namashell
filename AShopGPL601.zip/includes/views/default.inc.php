<?php
// AShop
// Copyright 2018 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

if (preg_match("/\Wdefault.inc.php/",$_SERVER["PHP_SELF"])>0) {
	header("Location: ../../index.php");
	exit;
}

// Default layout...
if (!empty($productid) && !empty($productname)) {
	$thumbnailshown = FALSE;
	if ($shoppingcart == 3 && empty($producturl)) $producturl = "index.php?product=$productid";
	echo "<li class=\"span3\">\n<div class=\"product-box\">\n<span class=\"sale_tag\"></span>\n";
	if ($productimage["thumbnail"]) {
		$imagesize = getimagesize("$ashoppath/prodimg/$productid/{$productimage["thumbnail"]}");
        $imagepaddingv = 0;
        $imagepaddingh = 0;
		if ($imagesize[1] < $imagesize[0]) {
            $imagepaddingpixels = floor(($imagesize[0] - $imagesize[1])/2);
            $imagepaddingpercent = ($imagepaddingpixels/$imagesize[0])*100;
            $imagepaddingv = floor($imagepaddingpercent);
        } else if ($imagesize[0] < $imagesize[1]) {
            $imagepaddingpixels = floor(($imagesize[1] - $imagesize[0])/2);
            $imagepaddingpercent = ($imagepaddingpixels/$imagesize[1])*100;
            $imagepaddingh = floor($imagepaddingpercent);
        }
        if ($imagepaddingv) echo "<div style=\"padding-top: {$imagepaddingv}%; padding-bottom: {$imagepaddingv}%;\">";
        else if ($imagepaddingh) echo "<div style=\"padding-left: {$imagepaddingh}%; padding-right: {$imagepaddingh}%;\">";
        echo "<a href=\"$producturl\"><img alt=\"$safeproductname\" src=\"prodimg/$productid/{$productimage["thumbnail"]}\"></a><br/>\n";
        if ($imagepaddingv || $imagepaddingh) echo "</div>";
    }
	echo "<a href=\"$producturl\" class=\"title\">$productname</a><br/>\n";
	if ($pricehtml) echo $pricehtml;
	else {
		echo "<p class=\"price\">";
		if ($regprice) echo $regprice."<span class=\"ashopproductsale\">";
		echo " $price";
		if ($regprice) echo "</span>";
		echo "</p>";
	}
	echo "</div>\n</li>\n";
}
?>