/* AShop
 * Copyright 2014 - AShop Software - http://www.ashopsoftware.com
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see: http://www.gnu.org/licenses/.
 * --------------------------------------------------------------------*/

var xmlhttp;

function isIE()
{
  return /msie/i.test(navigator.userAgent) && !/opera/i.test(navigator.userAgent);
}

function ajaxput(url) {
	if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest();
	else xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttp.open("GET",url,true);
	xmlhttp.send();
}

function ajaxget(url,cfunc) {
	if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest();
	else xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttp.onreadystatechange=cfunc;
	xmlhttp.open("GET",url,true);
	xmlhttp.send();
}

function updatecounter() {
	var result = new Object();
	var rightnow = new Date().getTime();
	var url = 'paybysurf.php?counteddown=true&dummy='+rightnow;
	if (window.surfstatus==0) window.counter++;
	if (window.counter > 5) {
		window.surfstatus = 1;
		ajaxget(url,function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				result = xmlhttp.responseText;
				result = result.split("|");
				var imagenumber = result[0]-1;
				document.getElementById("buttonanswer").innerHTML = "Click: <img src=\"images/surfbar/"+imagesArray[window.buttons[imagenumber]]+"\" alt=\"\" style=\"vertical-align: -33%\" />";
			}
		});
	} else {
		drawslider(5, window.counter);
	}
}

function buttonclick(buttonnumber) {
	var result = new Object();
	var rightnow = new Date().getTime();
	var url = 'paybysurf.php?buttonclick='+buttonnumber+'&dummy='+rightnow;
	ajaxget(url,function() {
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			result = xmlhttp.responseText;
			result = result.split("|");
			if (result[0] > 0) {
				document.getElementById('surfbox').src=result[1];
				document.getElementById("buttonanswer").innerHTML = "&nbsp;";
			} else {
				if (result[1] == 1) document.getElementById("buttonanswer").innerHTML = "<p style=\"margin-top: 5px;\">You clicked the wrong button!</p>";
				else if (result[1] == 2) document.getElementById("buttonanswer").innerHTML = "<p style=\"margin-top: 5px;\">You clicked too soon!</p>";
			}
			window.surfstatus = 0;
			randomizeimages();
		}
	});
	drawslider(5, 0);
	window.counter = 0;
}

function drawslider(fullwidth, state){
    var percent=Math.round((state*100)/fullwidth);
    document.getElementById("sliderbar").style.width=percent+'%';
}

function in_array(needle, haystack){
    var found = 0;
    for (var i=0, len=haystack.length;i<len;i++) {
        if (haystack[i] == needle) return i;
            found++;
    }
    return -1;
}

function randomizeimages() {

    var num = Math.floor(Math.random() * 3);
	for (var buttonnumber=0; buttonnumber<4; buttonnumber++) {
		window.buttons[buttonnumber] = 25;
	}
	for (var buttonnumber=0; buttonnumber<=3; buttonnumber++) {
		var num = Math.floor(Math.random() * 4);
		while (in_array(num, window.buttons) >= 0) {
			num = Math.floor(Math.random() * 4);
		}
		window.buttons[buttonnumber] = num;
		var imagenumber = buttonnumber+1;
		document.getElementById("buttonimage"+imagenumber).src = "images/surfbar/"+imagesArray[num];
	}
}