<?php
// AShop
// Copyright 2018 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

if (!$databaseserver || !$databaseuser) include "admin/config.inc.php";


$sliderhtml = "<section  class=\"homepage-slider\" id=\"home-slider\">
				<div class=\"flexslider\">
					<ul class=\"slides\">";
for ($slidenumber = 1; $slidenumber <= 3; $slidenumber++) {
    if (file_exists("$ashoppath/images/slides/banner-$slidenumber.jpg")) {
        $sliderhtml .= "
						<li>
                        ";
        if (!empty(${"homebannerurl$slidenumber"})) $sliderhtml .= "<a href=\"".${"homebannerurl$slidenumber"}."\">";
        $sliderhtml .= "<img src=\"images/slides/banner-$slidenumber.jpg\" alt=\"\" />";
        if (!empty(${"homebannerurl$slidenumber"})) $sliderhtml .= "</a>";
        $sliderhtml .= "
						</li>";
    }
}
$sliderhtml .= "
					</ul>
				</div>			
			</section>";

echo $sliderhtml;
?>