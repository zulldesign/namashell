/* AShop
 * Copyright 2014 - AShop Software - http://www.ashopsoftware.com
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see: http://www.gnu.org/licenses/.
 * --------------------------------------------------------------------*/

var xmlhttp;

function isIE()
{
  return /msie/i.test(navigator.userAgent) && !/opera/i.test(navigator.userAgent);
}

function ajaxput(url) {
	if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest();
	else xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttp.open("GET",url,true);
	xmlhttp.send();
}

function ajaxget(url,cfunc) {
	if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest();
	else xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttp.onreadystatechange=cfunc;
	xmlhttp.open("GET",url,true);
	xmlhttp.send();
}

function jwplaying(fileid, email, password) {
	var result = new Object();
	var position = window.jwplayer("videoplayerdiv").getPosition();
	position = parseFloat(position);
	position = Math.round(position);
	var duration = window.jwplayer("videoplayerdiv").getDuration();
	duration = parseFloat(duration);
	duration = Math.round(duration);
	var rightnow = new Date().getTime();
	var url = 'viewstream.php?playing=true&fileid='+fileid+'&email='+email+'&password='+password+'&dummy='+rightnow;
	if (position == 0 || position == duration || position > duration) {
		ajaxget(url,function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				result = xmlhttp.responseText;
				result = result.split("|");
				if (!result || result[0] > 0) {
					document.getElementById("message").innerHTML = result[1];
					window.jwplayer("videoplayerdiv").stop();
				} else {

				}
			}
		});
	}
}

function jwstopped(fileid, email, password) {
	var result = new Object();
	var rightnow = new Date().getTime();
	var url = 'viewstream.php?stopped='+fileid+'&email'+email+'&password'+password+'&dummy='+rightnow;
	ajaxget(url,function() {
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			result = xmlhttp.responseText;
			result = result.split("|");
			if (result[0] > 0) {

			} else {

			}
		}
	});
}