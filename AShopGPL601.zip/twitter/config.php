<?php
if (empty($databaseserver) || empty($databaseuser)) {
	include "../admin/config.inc.php";
}

define('CONSUMER_KEY', 'LekjEZiMYnUBWUNZebvgB5HIM');
define('CONSUMER_SECRET', '4nmXVNjmh9ZUHf2QjGpbG6PlnaOvtvMm3ADbmet6kd37NVolQ5');
define('OAUTH_CALLBACK', "$ashopurl/twitter/callback.php");
?>