<?php
@set_time_limit(0);
if (isset($_POST["action"])) $action = $_POST["action"];
else $action = "";
if (!isset($REQUEST_URI) and isset($_SERVER['SCRIPT_NAME']))
{
    $REQUEST_URI = $_SERVER['SCRIPT_NAME'];
    if (isset($_SERVER['QUERY_STRING']) and
!empty($_SERVER['QUERY_STRING']))
        $REQUEST_URI .= '?' . $_SERVER['QUERY_STRING'];
}

if (ini_get("register_globals") != 1 || !get_magic_quotes_gpc()) {
	foreach ($_SERVER as $key => $value) {
		if (!get_magic_quotes_gpc() && !empty($value) && !is_array($value)) $value = addslashes($value);
		eval("if(!isset(\$$key)) \$$key = \"$value\";");
	}
	foreach ($_COOKIE as $key => $value) {
		if (!get_magic_quotes_gpc()) $value = addslashes($value);
		eval("if(!isset(\$$key)) \$$key = \"$value\";");
	}
	foreach ($_POST as $key => $value) {
		if (!get_magic_quotes_gpc()) $value = addslashes($value);
		eval("if(!isset(\$$key)) \$$key = \"$value\";");
	}
	foreach ($_GET as $key => $value) {
		if (!get_magic_quotes_gpc()) $value = addslashes($value);
		eval("if(!isset(\$$key)) \$$key = \"$value\";");
	}
}
if ($action == "fsockopentest") {
	echo "SUCCESS";
	exit;
}

echo "<html><head><title>AShop Compatibility Test</title></head><body bgcolor=\"#FFFFFF\" textcolor=\"#000000\"><br><br><h3>AShop Compatibility Test</h3><ul>";

// Check if configuration can be read...
if (!function_exists('ini_get')) { echo "<li>Configuration cannot be read! Further testing is not possible!</li>"; exit; }

// Check PHP version...
$phpversion = phpversion();
if ($phpversion < "5.0.0") echo "<li>Too Old Version of PHP - <font color=\"#FF0000\">FAILED</font></li>";
else {
	echo "<li>At least version 5.0.0 of PHP (You have version $phpversion";
	if (php_sapi_name() == "cgi") echo ", CGI";
	if (strstr(php_sapi_name(), "apache")) echo ", Apache Module";
	if (php_sapi_name() == "isapi") echo ", ISAPI Module";
	echo ") - <font color=\"#009900\">PASSED</font></li>";
}

// Check Safe Mode...
$safemode = ini_get("safe_mode");
if ($safemode) echo "<li>Safe Mode = On - <font color=\"#FF0000\">FAILED</font></li>";
else echo "<li>Safe Mode = Off - <font color=\"#009900\">PASSED</font></li>";

// Check File Uploads...
$fileuploads = ini_get("file_uploads");
$uploadsizelimit = ini_get("upload_max_filesize");
if (!$fileuploads) echo "<li>File Uploads = Off - <font color=\"#FF0000\">FAILED</font></li>";
else echo "<li>File Uploads = On (Size limit: $uploadsizelimit) - <font color=\"#009900\">PASSED</font></li>";

// Check MySQL...
if (!function_exists('mysqli_query')) echo "<li>No MySQL Functions - <font color=\"#FF0000\">FAILED</font></li>";
else echo "<li>MySQL Functions Available - <font color=\"#009900\">PASSED</font></li>";

// Check Curl...
if (function_exists('curl_version')) {
	$curlversion = curl_version();
	if ((!is_array($curlversion) && strstr($curlversion, "SSL")) || (is_array($curlversion) && (strstr($curlversion["ssl_version"], "SSL") || strstr($curlversion["ssl_version"], "NSS")))) echo "<li>Curl With SSL Available - <font color=\"#009900\">PASSED</font></li>";
	else echo "<li>No Curl with SSL - <font color=\"#FF0000\">Some payment gateways won't be supported!</font></li>";
} else echo "<li>No Curl with SSL - <font color=\"#FF0000\">Some payment gateways won't be supported!</font></li>";

// Check Error Reporting...
if (ini_get('display_errors')) {
	if (ini_get('error_reporting') & E_NOTICE) echo "<li>Error Reporting Level Too High - <font color=\"#FF0000\">FAILED</font></li>";
	else echo "<li>Run-time notices = Off - <font color=\"#009900\">PASSED</font></li>";
} else echo "<li>Run-time notices = Off - <font color=\"#009900\">PASSED</font></li>";

// Check fsockopen()...
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") $url = "https://";
else $url = "http://";
$url .= $HTTP_HOST.$REQUEST_URI;
$querystring = "action=fsockopentest";
if (@strpos($url, "/", 8)) {
	$urlpath = "/".substr($url, strpos($url, "/", 8)+1);
	$urldomain = substr($url, 0, strpos($url, "/", 8));
} else {
	$urlpath = "/";
	$urldomain = $url;
}
$urldomain = str_replace("http://", "", $urldomain);
$postheader = "POST $urlpath HTTP/1.0\r\nHost: $urldomain\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: ".strlen ($querystring)."\r\n\r\n";
$fp = @fsockopen ($urldomain, 80, $errno, $errstr, 10);
$res = "";
if ($fp) {
	fputs ($fp, $postheader.$querystring);
	while (!feof($fp)) $res .= fgets ($fp, 1024);
	fclose ($fp);
}
if (strstr($res,"SUCCESS")) echo "<li>The fsockopen-function is working - <font color=\"#009900\">PASSED</font></li>";
else echo "<li>The fsockopen-function isn't working, error: $errno $errstr - <font color=\"#FF0000\">FAILED</font></li>";

echo "</ul>";
echo "<p><a href=\"http://www.ashopsoftware.com/ashop-software-requirements.htm\" target=\"_blank\">AShop 
  Software Requirements</a></p>
<p><a href=\"http://www.ashopsoftware.com/tech-service-request.htm\" target=\"_blank\">Request 
  Technical Support</a></p></body></html>";
?>