<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

include "config.inc.php";
include "ashopfunc.inc.php";
include "checklogin.inc.php";
include "template.inc.php";
// Get language module...
include "language/$adminlang/affiliates.inc.php";
// Get context help for this page...
$contexthelppage = "affiliatecodes";
include "help.inc.php";

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

// Handle new and updated link code categories...
if ($submitbutton) {
	if (!$linkcategoryid) {
		$sql="INSERT INTO linkcategories (linkcategoryname) VALUES ('$linkcategoryname')";
	} else {
		$sql = "UPDATE linkcategories SET linkcategoryname='$linkcategoryname' WHERE linkcategoryid=$linkcategoryid";
	}
	$result = @mysqli_query($db, $sql);
}

// Delete link code category...
if ($deletebutton) {
	$sql = "DELETE FROM linkcategories WHERE linkcategoryid=$linkcategoryid";
	$result = @mysqli_query($db, $sql);
}

echo "$header
    <section class=\"content-header\"><h1>".LINKCODECATEGORIES." <a href=\"$help2\" target=\"_blank\"><img src=\"images/icon_helpsm.gif\" width=\"15\" height=\"15\" border=\"0\"></a></h1></section>
    <section class=\"content\">
		<div class=\"row\">
			<div class=\"col-md-6\">
		<div class=\"box box-primary\">
            <form action=\"affiliatecategories.php\" method=\"post\" name=\"addform\">
			    <div class=\"box-header with-border\">
				    <h3 class=\"box-title\">".ADDNEWLINKCATEGORY."</h3>
                </div>
                <div class=\"box-body\">
                    <div class=\"form-group\">".admin_inputfield(array("label" => CATEGORYNAME, "name" => "linkcategoryname"))."</div>
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".ADD."\">".ADD."</button>
				</div>
            </form>
         </div>
		<div class=\"box box-primary\">
            <div class=\"box-header with-border\">
                <h3 class=\"box-title\">".CATEGORIES."</h3>
            </div>
            ";

// Get link code information from database...
$sql="SELECT * FROM linkcategories ORDER BY linkcategoryid ASC";
$result = @mysqli_query($db, "$sql");
for ($i = 0; $i < @mysqli_num_rows($result); $i++) {
    $thislinkcategoryname = @mysqli_result($result, $i, "linkcategoryname");
    $thislinkcategoryid = @mysqli_result($result, $i, "linkcategoryid");
    $result2 = @mysqli_query($db, "SELECT * FROM linkcodes WHERE linkcategoryid='$thislinkcategoryid'");
    if (!@mysqli_num_rows($result2)) $inuse = TRUE;
    else $inuse = FALSE;
    echo "<form action=\"affiliatecategories.php\" method=\"post\"><div class=\"box-body\">";
    if ($inuse) echo "
            <div class=\"form-group\">".admin_inputfield(array("name" => "linkcategoryname", "value" => $thislinkcategoryname, "explanation" => INUSE))."</div>
            </div>
            <div class=\"box-footer\">";
    else echo "
            <div class=\"form-group\">".admin_inputfield(array("name" => "linkcategoryname", "value" => $thislinkcategoryname))."</div>
            </div>
            <div class=\"box-footer\">
                <button type=\"submit\" class=\"btn btn-primary\" name=\"deletebutton\" value=\"".DELETELINK."\">".DELETELINK."</button>";
    echo "
            <button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".UPDATE."\">".UPDATE."</button>
            </div>
            <input type=\"hidden\" name=\"linkcategoryid\" value=\"$thislinkcategoryid\"></form>";
}

echo "</div></div></div></div></section>$footer";
?>