<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

include "config.inc.php";
include "ashopfunc.inc.php";
include "checklogin.inc.php";
include "template.inc.php";
// Get language module...
include "language/$adminlang/editcategory.inc.php";
// Get context help for this page...
$contexthelppage = "addcategory";
include "help.inc.php";

// Set the right member user ID...
if ($userid == 1) $user = 1;
else {
	if (!$membershops) {
		header("Location: index.php");
		exit;
	} else $user = $userid;
}

   $db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

   if ($cat) {
	   $sql="SELECT grandparentcategoryid FROM category WHERE categoryid = '$cat'";
	   $result = @mysqli_query($db,$sql);
       $cat = @mysqli_result($result,0,"grandparentcategoryid");
	   $sql="SELECT * FROM category WHERE categoryid = '$cat'";
	   $result = @mysqli_query($db,$sql);
	   $selectedcategoryname = @mysqli_result($result,0,"name");
	   $parentcategory = @mysqli_result($result,0,"parentcategoryid");
	   $grandparentcategory = @mysqli_result($result,0,"grandparentcategoryid");
	   $parentowner = @mysqli_result($result,0,"userid");
   }

   // Generate Digital Mall member list if needed...
   if ($userid == "1" && file_exists("$ashoppath/members/index.php") && $digitalmall != "OFF") {
	   $memberlist = "<select class=\"form-control\" name=\"memberid\" onChange=\"javascript: if(categoryform.memberid.value != '1') { categoryform.memberclone.checked=false; categoryform.memberclone.disabled=true; } else categoryform.memberclone.disabled=false;\"><option value=\"1\">".ADMINISTRATOR;
	   $result = @mysqli_query($db,"SELECT * FROM user WHERE userid>1 ORDER BY shopname");
	   while ($row = @mysqli_fetch_array($result)) {
		   $memberlist .= "<option value=\"{$row["userid"]}\"";
		   if ($row["userid"] == $parentowner) $memberlist .= " selected";
		   $memberlist .= ">{$row["shopname"]}
		   ";
	   }
	   $memberlist .= "</select>
	   ";
   }

   	// Generate language list...
	$languagelist = "<select class=\"form-control\" name=\"nlanguage\"><option value=\"any\">".ANY;
	$findfile = opendir("$ashoppath/language");
	while ($foundfile = readdir($findfile)) {
		if($foundfile && $foundfile != "." && $foundfile != ".." && is_dir("$ashoppath/language/$foundfile") && !strstr($foundfile, "CVS") && substr($foundfile, 0, 1) != "_" && file_exists("$ashoppath/language/$foundfile/lang.cfg.php")) {
			$fp = fopen ("$ashoppath/language/$foundfile/lang.cfg.php","r");
			while (!feof ($fp)) {
				$fileline = fgets($fp, 4096);
				if (strstr($fileline,"\$langname")) $langnamestring = $fileline;
			}
			fclose($fp);
			eval ($langnamestring);
			$languages["$foundfile"] = $langname;
		}
	}
	if (is_array($languages)) {
		natcasesort($languages);
		foreach ($languages as $langmodule=>$langname) $languagelist .= "<option value=\"$langmodule\">$langname</option>";
	}
    $languagelist .= "</select>";


if (!$name && !$description) {
        echo "$header
    <section class=\"content-header\"><h1>".ADDPRODUCTCATEGORY." <a href=\"javascript:;\" onMouseOut=\"MM_swapImgRestore()\" onMouseOver=\"MM_swapImage('Image1','','images/contexthelpicon_over.gif',1)\"><img src=\"images/contexthelpicon.gif\" width=\"14\" height=\"15\" border=\"0\" name=\"Image1\" align=\"absmiddle\" onclick=\"return overlib('$tip1');\" onmouseout=\"return nd();\"></a></h1></section>
    <section class=\"content\">
		<div class=\"row\">
			<div class=\"col-md-6\">
		<div class=\"box box-primary\">
            <form action=\"addcategory.php\" method=\"post\" name=\"categoryform\" enctype=\"multipart/form-data\">
                <div class=\"box-body\">";
		if ($cat && ($parentcategory == $cat || $grandparentcategory == $cat)) echo "
                    <div class=\"form-group\">
                        <label for=\"cat\">".TYPE.":</label>
                        <div class=\"radio\"><label><input type=\"radio\" name=\"cat\" value=\"0\" checked onClick=\"javascript:if(categoryform.cat.value='0') categoryform.nlanguage.disabled=false;\"> ".TOPCATEGORY."</label></div>
                        <div class=\"radio\"><label><input type=\"radio\" name=\"cat\" value=\"$cat\" onClick=\"javascript:if(categoryform.cat.value='$cat') categoryform.nlanguage.disabled=true;\"> ".SUBCATEGORYTO." $selectedcategoryname</label></div>
                    </div>";
        echo "
                    <div class=\"form-group\">".admin_inputfield(array("label" => NAME, "name" => "name"))."</div>";
		if ($userid == "1" && file_exists("$ashoppath/members/index.php") && $digitalmall != "OFF") {
			echo "
                    <div class=\"form-group\">
                        <label for=\"memberid\">".OWNER."</label>
                        $memberlist
                    </div>
                    <div class=\"form-group\">".admin_checkbox(array("label" => MAKETHISCATEGORYAVAILABLE, "name" => "memberclone"))."</div>";
		}
		echo "
                    <div class=\"form-group\">
                        <label for=\"nlanguage\">".LANGUAGE."</label>
                        $languagelist
                    </div>
					<div class=\"form-group\">".admin_inputfield(array("label" => CATEGORYIMAGE, "name" => "imgfile", "fileupload" => TRUE))."</div>
                    <div class=\"form-group\">".admin_textbox(array("label" => DESCRIPTION, "name" => "description"))."</div>
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary pull-right\" value=\"".SUBMIT."\">".SUBMIT."</button>
				</div>
             </form></div></div></div></section>
        ";
		echo $footer;
} else {
   if ($memberid) $catuser = $memberid;
   else $catuser = $user;
   if ($memberclone == "on") $memberclone = 1;
   else $memberclone = 0;
   $sql="INSERT INTO category (name,description,userid,language,memberclone,productlayout) VALUES ('$name','$description','$catuser','$nlanguage','$memberclone','0')";
   $result = @mysqli_query($db,$sql);
   $categoryid = @mysqli_insert_id($db);
   if (!$cat) {
	   $topcat = $categoryid;
	   $midcat = $categoryid;
   } else if ($parentcategory == $cat && $grandparentcategory == $cat) {
	   $topcat = $cat;
	   $midcat = $categoryid;
   } else {
	   $topcat = $grandparentcategory;
	   $midcat = $cat;
   }
   if (empty($nlanguage)) {
	   $result = @mysqli_query($db,"SELECT language FROM category WHERE grandparentcategoryid='$topcat'");
	   $nlanguage = @mysqli_result($result,0,"language");
	   if (empty($nlanguage)) $nlanguage = "any";
	   $sql="UPDATE category SET grandparentcategoryid='$topcat', parentcategoryid='$midcat', ordernumber='$categoryid', userid='$catuser', language='$nlanguage' WHERE categoryid='$categoryid'";
   } else $sql="UPDATE category SET grandparentcategoryid='$topcat', parentcategoryid='$midcat', ordernumber='$categoryid', userid='$catuser' WHERE categoryid='$categoryid'";
   $result = @mysqli_query($db,$sql);

   // Handle uploaded image file...
   $imgfile = str_replace("\t","\\t",$imgfile);
   if (is_uploaded_file($imgfile)) {
       $fileinfo = pathinfo("$imgfile_name");
       $extension = $fileinfo["extension"];
       if ($extension == "png") {
           move_uploaded_file($imgfile, "$ashoppath/catimg/$categoryid.png");
           @chmod("$ashoppath/catimg/$categoryid.png", 0777);
       }
   }

   header("Location: editcatalogue.php?cat=$categoryid");
}
?>