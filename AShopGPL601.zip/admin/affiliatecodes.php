<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

include "config.inc.php";
include "ashopfunc.inc.php";
include "checklogin.inc.php";
include "template.inc.php";
// Get language module...
include "language/$adminlang/affiliates.inc.php";
// Get context help for this page...
$contexthelppage = "affiliatecodes";
include "help.inc.php";

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");


// Handle new and updated link codes...
if ($submitbutton) {
	if (!$linkid) {
		$imgfile = str_replace("\t","\\t",$imgfile);
		if (is_uploaded_file($imgfile)) {
			$filename = preg_replace("/%28|%29|%2B/","",urlencode(basename($imgfile_name)));
			$filename = preg_replace("/%E5|%E4/","a",$filename);
			$filename = preg_replace("/%F6/","o",$filename);
			$filename = preg_replace("/%C5|%C4/","A",$filename);
			$filename = preg_replace("/%D6/","O",$filename);
			$filename = preg_replace("/\+\+\+|\+\+/","+",$filename);
			$fileinfo = pathinfo("$filename");
			$extension = $fileinfo["extension"];
			if ($extension != "gif" && $extension != "jpg") {
				$error = "extension";
			} else {
				move_uploaded_file($imgfile, "$ashoppath/banners/$filename");
				@chmod("$ashoppath/banners/$filename", 0666);
			}
			$sql="INSERT INTO linkcodes (linkcategoryid,filename,linktext,redirect,alt) VALUES ('$linkcategoryid','$filename','$linktext', '$redirect', '$alt')";
		} else $sql="INSERT INTO linkcodes (linkcategoryid,linktext,redirect) VALUES ('$linkcategoryid','$linktext','$redirect')";
	} else {
		$imgfile = str_replace("\t","\\t",$imgfile);
		if (is_uploaded_file($imgfile)) {
			$filename = preg_replace("/%28|%29|%2B/","",urlencode(basename($imgfile_name)));
			$filename = preg_replace("/%E5|%E4/","a",$filename);
			$filename = preg_replace("/%F6/","o",$filename);
			$filename = preg_replace("/%C5|%C4/","A",$filename);
			$filename = preg_replace("/%D6/","O",$filename);
			$filename = preg_replace("/\+\+\+|\+\+/","+",$filename);
			$fileinfo = pathinfo("$filename");
			$extension = $fileinfo["extension"];
			if ($extension != "gif" && $extension != "jpg") {
				$error = "extension";
			} else {
				move_uploaded_file($imgfile, "$ashoppath/banners/$filename");
				@chmod("$ashoppath/banners/$filename", 0666);
			}
			$sql = "UPDATE linkcodes SET linkcategoryid='$linkcategoryid', linktext='$linktext', redirect='$redirect', alt='$alt', filename='$filename' WHERE linkid=$linkid";
		} else $sql = "UPDATE linkcodes SET linkcategoryid='$linkcategoryid', linktext='$linktext', redirect='$redirect', alt='$alt' WHERE linkid=$linkid";
	}
	$result = @mysqli_query($db, $sql);
}

// Delete link code...
if ($deletebutton) {
	$sql = "DELETE FROM linkcodes WHERE linkid=$linkid";
	$result = @mysqli_query($db, $sql);
}

// Create an array of link categories...
$linkcategories = array();
$result = @mysqli_query($db, "SELECT * FROM linkcategories ORDER BY linkcategoryid ASC");
while ($row = @mysqli_fetch_array($result)) {
	$linkcategoryid = $row["linkcategoryid"];
	$linkcategoryname = $row["linkcategoryname"];
	$linkcategories["$linkcategoryid"] = $linkcategoryname;
}

if (strpos($header, "body") != 0) {
	$newheader = substr($header,1,strpos($header, "body")+3);
	$newheader .= " onUnload=\"closemessage()\" ".substr($header,strpos($header, "body")+4,strlen($header));
} else {
	$newheader = substr($header,1,strpos($header, "BODY")+3);
	$newheader .= " onUnload=\"closemessage()\" ".substr($header,strpos($header, "BODY")+4,strlen($header));
}
echo "$newheader
		<script language=\"JavaScript\">
		function uploadmessagetwotier() 
		{
		  if (document.twotierform.imgfile.value != '') {
			  w = window.open('uploadmessage.html','_blank','toolbar=no,location=no,width=350,height=150');
		  }
	    }
		function uploadmessage() 
		{
		  if (document.addform.imgfile.value != '') {
			  w = window.open('uploadmessage.html','_blank','toolbar=no,location=no,width=350,height=150');
		  }
	    }
        function closemessage()
        {
       	  if (typeof w != 'undefined') w.close();
        }
        </script>
    <section class=\"content-header\"><h1>".LINKCODES." <a href=\"$help1\" target=\"_blank\"><img src=\"images/icon_helpsm.gif\" width=\"15\" height=\"15\" border=\"0\"></a></h1></section>
    <section class=\"content\">
		<div class=\"row\">
			<div class=\"col-md-6\">";

// Show recruitment link...
if ($secondtieractivated) {
	$sql = "SELECT * FROM linkcodes WHERE linkid=1";
	$result = @mysqli_query($db, "$sql");
	if (@mysqli_num_rows($result)) {
		$thislinktext = @mysqli_result($result, 0, "linktext");
		$newlinktext = str_replace("%affiliatelink%","$ashopurl/affiliate.php?id=0",$thislinktext);
		$newlinktext2 = str_replace("&gt;",">",$newlinktext);
		$newlinktext2 = str_replace("&lt;","<",$newlinktext2);
		$thisfilename = @mysqli_result($result, 0, "filename");
		$thisalt = @mysqli_result($result, 0, "alt");
		echo "
		<div class=\"box box-primary\">
            <form action=\"affiliatecodes.php\" method=\"post\" enctype=\"multipart/form-data\" name=\"twotierform\">
			    <div class=\"box-header with-border\">
				    <h3 class=\"box-title\">".RECRUITMENTLINK."</h3>
                </div>
              <div class=\"alert alert-info alert-dismissible\">
                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>";
		if ($thisfilename) echo "<img src=\"../banners/$thisfilename\" alt=\"$thisalt\">";
		echo "
                <p>$newlinktext2</p>
              </div>
                <div class=\"box-body\">
                    <div class=\"form-group\" id=\"url\">".admin_inputfield(array("label" => BANNERIMAGE, "name" => "imgfile", "fileupload" => TRUE, "explanation" => "[".GIFORJPG."]"))."</div>
                    <div class=\"form-group\" id=\"url\">".admin_inputfield(array("label" => IMAGEALTTEXT, "name" => "alt", "value" => $thisalt, "explanation" => "[".THISISTHETEXT."]"))."</div>
                    <div class=\"form-group\" id=\"url\">".admin_textbox(array("label" => LINKTEXT, "name" => "linktext", "value" => $thislinktext, "explanation" => "[".HTMLCODECANBEUSED."]"))."</div>
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".UPDATE."\" onClick=\"uploadmessagetwotier()\">".UPDATE."</button>
				</div>
                <input type=\"hidden\" name=\"linkid\" value=\"1\">
                <input type=\"hidden\" name=\"redirect\" value=\"$ashopurl/affiliate/signupform.php\">
            </form>
        </div>";
	}
}

echo "
		<div class=\"box box-primary\">
            <form action=\"affiliatecodes.php\" method=\"post\" enctype=\"multipart/form-data\" name=\"addform\">
			    <div class=\"box-header with-border\">
				    <h3 class=\"box-title\">".ADDANEWLINK."</h3>
                </div>
                <div class=\"box-body\">
                    <div class=\"form-group\">
                        <label for=\"linkcategoryid\">".CATEGORY."</label><select class=\"form-control\" name=\"linkcategoryid\">";
	  foreach($linkcategories as $linkcategoryid=>$linkcategoryname) echo "<option value=\"$linkcategoryid\">$linkcategoryname</option>";
	  echo "</select></div>
                    <div class=\"form-group\" id=\"url\">".admin_inputfield(array("label" => IMAGE, "name" => "imgfile", "fileupload" => TRUE, "explanation" => "[".GIFORJPG."]"))."</div>
                    <div class=\"form-group\" id=\"url\">".admin_inputfield(array("label" => IMAGEALTTEXT, "name" => "alt", "explanation" => "[".THISISTHETEXT."]"))."</div>
                    <div class=\"form-group\" id=\"url\">".admin_inputfield(array("label" => URL, "name" => "redirect", "value" => $thisredirect, "explanation" => "[".CLICKTHROUGHSWILL."]"))."</div>
                    <div class=\"form-group\" id=\"url\">".admin_textbox(array("label" => LINKTEXT, "name" => "linktext", "value" => $thislinktext, "explanation" => "[".HTMLCODECANBEUSED." ".ORAFFILIATECLOAK."]"))."</div>
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".ADD."\" onClick=\"uploadmessage()\">".ADD."</button>
				</div>
            </form>
        </div>";

// Order by category...
foreach($linkcategories as $linkcategoryid=>$linkcategoryname) {

// Get link code information from database...
$sql="SELECT * FROM linkcodes WHERE linkid > 1 AND linkcategoryid='$linkcategoryid'";
$result = @mysqli_query($db, "$sql");
if (@mysqli_num_rows($result)) echo "<h3>$linkcategoryname</h3>";
for ($i = 0; $i < @mysqli_num_rows($result); $i++) {
	$thislinkcategoryid = @mysqli_result($result, $i, "linkcategoryid");
    $thislinktext = @mysqli_result($result, $i, "linktext");
    $thisfilename = @mysqli_result($result, $i, "filename");
    $thislinkid = @mysqli_result($result, $i, "linkid");
    $thisredirect = @mysqli_result($result, $i, "redirect");
	$newlinktext = str_replace("%affiliatelink%","$ashopurl/affiliate.php?id=0&redirect=$thisredirect",$thislinktext);
	$newlinktext = str_replace("%affiliatecloaklink%","&lt;a href=\"$ashopurl\" onClick=\"window.open('$ashopurl/affiliate.php?id=0', 'PGM', 'scrollbars=yes, toolbar=yes, status=yes, menubar=yes location=yes resizable=yes'); return false;\"&gt;",$thislinktext);
	$newlinktext2 = str_replace("&gt;",">",$newlinktext);
	$newlinktext2 = str_replace("&lt;","<",$newlinktext2);
    $thisalt = @mysqli_result($result, $i, "alt");
    echo "
		<div class=\"box box-primary\">
            <form action=\"affiliatecodes.php\" method=\"post\" enctype=\"multipart/form-data\">
              <div class=\"alert alert-info alert-dismissible\">
                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>";
	if ($thisfilename) echo "<img src=\"../banners/$thisfilename\" alt=\"$thisalt\">";
	echo "<p>$newlinktext2</p>
                </div>
                <div class=\"box-body\">
                    <div class=\"form-group\">
                        <label for=\"linkcategoryid\">".CATEGORY."</label><select class=\"form-control\" name=\"linkcategoryid\">";
	foreach($linkcategories as $linkcategoryid=>$linkcategoryname) {
		echo "<option value=\"$linkcategoryid\"";
		if ($thislinkcategoryid == $linkcategoryid) echo " selected";
		echo ">$linkcategoryname</option>";
	}
	echo "</select></div>
                    <div class=\"form-group\" id=\"url\">".admin_inputfield(array("label" => IMAGE, "name" => "imgfile", "fileupload" => TRUE, "explanation" => "[".GIFORJPG."]"))."</div>
                    <div class=\"form-group\" id=\"url\">".admin_inputfield(array("label" => IMAGEALTTEXT, "name" => "alt", "value" => $thisalt))."</div>
                    <div class=\"form-group\" id=\"url\">".admin_inputfield(array("label" => URL, "name" => "redirect", "value" => $thisredirect, "value" => $thisredirect))."</div>
                    <div class=\"form-group\" id=\"url\">".admin_textbox(array("label" => LINKTEXT, "name" => "linktext", "value" => $thislinktext))."</div>
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-default\" name=\"deletebutton\" value=\"".DELETELINK."\">".DELETELINK."</button>
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".UPDATE."\">".UPDATE."</button>
				</div>
                <input type=\"hidden\" name=\"linkid\" value=\"$thislinkid\">
            </form>
        </div>";
}
}
echo "
            </div>
            </div>
            </section>
            $footer";
?>