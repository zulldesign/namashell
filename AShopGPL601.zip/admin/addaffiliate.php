<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

include "config.inc.php";
include "ashopfunc.inc.php";
include "checklogin.inc.php";
include "template.inc.php";
// Get language module...
include "language/$adminlang/affiliates.inc.php";

if ($userid != 1) {
	header("Location: index.php");
	exit;
}

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

// Store updated data...
if ($update) {
	// Avoid duplicate usernames...
	$result = @mysqli_query($db,"SELECT * FROM affiliate WHERE user='$user'");
	if (@mysqli_num_rows($result)) $errormsg = USERNAMEINUSE;
	else {

		// Generate a unique referral code for manual referral...
		$referralcode = substr(strtolower($firstname),0,2).substr(strtolower($lastname),0,3);
		$referralcode .= str_repeat("0",5-strlen($referralcode));
		$refnumber = 1;
		$newreferralcode = $referralcode;
		$referralcodenumber = $referralcode.sprintf("%03d",$refnumber);
		$unique = 0;
		$n = 0;
		$m = ord("a");
		while(!$unique) {
			while(!$unique && $refnumber < 1000) {
				$result = @mysqli_query($db,"SELECT referralcode FROM affiliate WHERE referralcode='$referralcodenumber'");
				if(@mysqli_num_rows($result)) {
					$refnumber++;
					$referralcodenumber = $newreferralcode.sprintf("%03d",$refnumber);
				} else $unique = 1;
			} if(!$unique) {
				$refnumber = 1;
				$newreferralcode = substr_replace($referralcode, chr($m), $n, 1);
				$referralcodenumber = $newreferralcode.sprintf("%03d",$refnumber);
				if($m == ord("z")) {
					$n++;
					$m = ord("a");
				} else $m++;
			}
		}

		// Set current date and time...
		$date = date("Y-m-d H:i:s", time()+$timezoneoffset);

		$sql="INSERT INTO affiliate (user, password, business, firstname, lastname, email, address, state, zip, city, country, url, phone, paypalid, updated, referralcode, commissionlevel, referedby) VALUES ('$user', '$password', '$business', '$firstname', '$lastname', '$email', '$address', '$state', '$zip', '$city', '$country', '$url', '$phone', '$paypalid', '$date', '$referralcode', '$commissionlevel', '$referredby')";
		$result = @mysqli_query($db,"$sql");
		header("Location: affiliateadmin.php"); 
		exit;
	}
}

// Close database...
@mysqli_close($db);


// Show affiliate page in browser...
	if (strpos($header, "title") != 0) {
	    $newheader = substr($header,1,strpos($header, "title")+5);
	    $newheader .= ADDNEWAFFILIATE." - ".substr($header,strpos($header, "title")+6,strlen($header));
    } else {
		$newheader = substr($header,1,strpos($header, "TITLE")+5);
		$newheader .= ADDNEWAFFILIATE." - ".substr($header,strpos($header, "TITLE")+6,strlen($header));
	}

echo "$newheader
    <section class=\"content-header\"><h1>".ADDNEWAFFILIATE."</h1></section>
    <section class=\"content\">
		<div class=\"row\">
			<div class=\"col-md-6\">
		<div class=\"box box-primary\">
            <form action=\"addaffiliate.php\" method=\"post\"><input type=\"hidden\" name=\"affiliateid\" value=\"$affiliateid\">        ";
if ($errormsg) echo "
              <div class=\"alert alert-danger alert-dismissible\">
                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>
                $errormsg
              </div>";
echo "
                <div class=\"box-body\">
                    <div class=\"form-group\">".admin_inputfield(array("label" => REFERREDBYAFFILIATE, "name" => "referredby", "value" => $referredby, "small" => TRUE))."</div>
                    <div class=\"form-group\"><label for=\"commissionlevel\">".COMMISSIONLEVEL."</label><div class=\"radio\"><label><input type=radio name=\"commissionlevel\" value=\"1\"";
	if ($commissionlevel == "1") echo " checked";
	echo "> ".NORMAL."</label></div><div class=\"radio\"><label><input type=radio name=\"commissionlevel\" value=\"2\"";
	if ($commissionlevel == "2") echo " checked";
	echo "> ".UPGRADED."</label></div></div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => USERNAME, "name" => "user", "value" => $user, "explanation" => MAXTENCHARS, "small" => TRUE))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => PASSWORD, "name" => "password", "value" => $password, "explanation" => MAXSEVENCHARS, "password" => TRUE, "small" => TRUE))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => BUSINESSNAME, "name" => "business", "value" => $business))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => FIRSTNAME, "name" => "firstname", "value" => $firstname))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => LASTNAME, "name" => "lastname", "value" => $lastname))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => EMAIL, "name" => "email", "value" => $email))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => ADDRESS, "name" => "address", "value" => $address))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => CITY, "name" => "city", "value" => $city))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => STATEPROVINCE, "name" => "state", "value" => $state))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => ZIP, "name" => "zip", "value" => $zip, "small" => TRUE))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => COUNTRY, "name" => "country", "value" => $country))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => PHONE, "name" => "phone", "value" => $phone))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => URL, "name" => "url", "value" => $url))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => PAYPALID, "name" => "paypalid", "value" => $paypalid))."</div>
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"update\" value=\"".SUBMIT."\">".SUBMIT."</button>
				</div>
             </form></div></div></div></section>
	$footer";
?>