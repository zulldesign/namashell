<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

include "config.inc.php";
include "ashopfunc.inc.php";
include "checklogin.inc.php";
include "template.inc.php";
// Get language module...
include "language/$adminlang/affiliates.inc.php";

if (!$paymethod && !$affiliateid) {
	header ("Location: affiliatestats.php");	
	exit;
}

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

// Set current date and time...
$date = date("Y-m-d H:i:s", time()+$timezoneoffset);

// Get affiliate information from database...
$sql="SELECT * FROM affiliate WHERE affiliateid='$affiliateid'";
$result = @mysqli_query($db, "$sql");
$firstname = @mysqli_result($result, 0, "firstname");
$lastname = @mysqli_result($result, 0, "lastname");
$address = @mysqli_result($result, 0, "address");
$state = @mysqli_result($result, 0, "state");
$zip = @mysqli_result($result, 0, "zip");
$city = @mysqli_result($result, 0, "city");
$country = @mysqli_result($result, 0, "country");
$paypalid = @mysqli_result($result, 0, "paypalid");

// Set affiliate commission as paid...
$provision = 0;
$sql="SELECT orderaffiliate.orderid, orderaffiliate.commission FROM orders, orderaffiliate WHERE orderaffiliate.affiliateid='$affiliateid' AND (orderaffiliate.paid=0 OR orderaffiliate.paid IS NULL) AND orders.orderid=orderaffiliate.orderid";
$result = @mysqli_query($db, "$sql");
$updatepaid = "off";
for ($i = 0; $i < @mysqli_num_rows($result); $i++) {
	$orderid = @mysqli_result($result, $i, "orderid");
	$thiscommission = @mysqli_result($result, $i, "commission");
    eval ("if (\$paid$orderid == \"on\") \$updatepaid = \"on\";");
	if (!empty($payall) && is_numeric($payall) && $orderid <= $payall) $updatepaid = "on";
    if ($updatepaid == "on") {
		$sql="UPDATE orderaffiliate SET paid='$date', paymethod='$paymethod' WHERE orderid=$orderid AND affiliateid='$affiliateid'";
		$subresult = @mysqli_query($db, "$sql");
		$updatepaid = "off";
		$provision += $thiscommission;
	}
}

$item_name = urlencode("Affiliate commission from $ashopname");
$return = "$ashopurl/admin/affiliatestats.php";
$urlprovision = urlencode(number_format(round($provision,2),2,'.',''));

// Send the shop administrator back to affiliate stats or to PayPal...
if ($paymethod == "Check") echo "$header
    <section class=\"content-header\"><h1>".PAYMENTTO." $firstname $lastname, ".AFFILIATEID." $affiliateid <a href=\"editaffiliate.php?affiliateid=$affiliateid\"><img src=\"images/icon_profile.gif\" alt=\"".PROFILEFORAFFILIATE." $affiliateid\" title=\"".PROFILEFORAFFILIATE." $affiliateid\" border=\"0\"></a>
<a href=\"affiliatedetail.php?affiliateid=$affiliateid\"><img src=\"images/icon_history.gif\" alt=\"".STATISTICSFORAFFILIATE." $affiliateid\" title=\"".STATISTICSFORAFFILIATE." $affiliateid\" border=\"0\"></a>&nbsp;<a href=\"editaffiliate.php?affiliateid=$affiliateid&remove=True&fromstats=True\"><img src=\"images/icon_trash.gif\" alt=\"".DELETEAFFILIATE." $affiliateid ".FROMTHEDATABASE."\" title=\"".DELETEAFFILIATE." $affiliateid ".FROMTHEDATABASE."\" border=\"0\"></a></h1></section>
    <section class=\"content\">
		<div class=\"row\">
			<div class=\"col-md-6\">
		<div class=\"box box-primary\">
            <div class=\"form-group\">".admin_inputfield(array("label" => AMOUNTONCHECK, "name" => "amount", "value" => number_format(round($provision,2),$showdecimals,$decimalchar,$thousandchar), "small" => TRUE, "prefix" => $currencysymbols[$ashopcurrency]["pre"], "suffix" => $currencysymbols[$ashopcurrency]["post"]))."</div>
            <div class=\"form-group\">".admin_inputfield(array("label" => CHECKPAYABLETO, "name" => "name", "value" => "$firstname $lastname"))."</div>
            <div class=\"form-group\">".admin_textbox(array("label" => SENDCHECKTO, "name" => "recipient", "value" => "$firstname $lastname\n$address\n$city\n$state $zip\n$country"))."</div>
        </div>
        </div>
        </div>
    </section>
    $footer";


else if ($paymethod == "PayPal") {
	$paypalcurrency = "&currency_code=".strtoupper($ashopcurrency);	
	header ("Location: https://www.paypal.com/cgi-bin/webscr?business=$paypalid&item_name=$item_name&cmd=_xclick&undefined_quantity=0&no_shipping=1&no_note=1$paypalcurrency&return=$return&amount=$urlprovision&currency_code=".strtoupper($ashopcurrency));
}
?>