<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

include "config.inc.php";
include "ashopfunc.inc.php";
include "checklogin.inc.php";
include "template.inc.php";
// Get language module...
include "language/$adminlang/affiliates.inc.php";
// Get context help for this page...
$contexthelppage = "affiliatecodes";
include "help.inc.php";

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

// Handle new and updated affiliate tags...
if ($submitbutton) {
	if (!$affiliatetagid) {
		$sql="INSERT INTO affiliatetags (fieldname,tagname,rows) VALUES ('$fieldname','$tagname','$rows')";
	} else {
		$sql = "UPDATE affiliatetags SET fieldname='$fieldname',tagname='$tagname',rows='$rows' WHERE affiliatetagid='$affiliatetagid'";
	}
	$result = @mysqli_query($db, $sql);
}

// Delete affiliate tag...
if ($deletebutton) {
	$sql = "DELETE FROM affiliatetags WHERE affiliatetagid='$affiliatetagid'";
	$result = @mysqli_query($db, $sql);
}

echo "$header
    <section class=\"content-header\"><h1>".CUSTOMTAGS." <a href=\"$help3\" target=\"_blank\"><img src=\"images/icon_helpsm.gif\" width=\"15\" height=\"15\" border=\"0\"></a></h1></section>
    <section class=\"content\">
		<div class=\"row\">
			<div class=\"col-md-6\">
		<div class=\"box box-primary\">
            <form action=\"affiliatetags.php\" method=\"post\" name=\"addform\">
			    <div class=\"box-header with-border\">
				    <h3 class=\"box-title\">".ADDNEWCUSTOMTAG."</h3>
                </div>
                <div class=\"box-body\">
                    <div class=\"form-group\">".admin_inputfield(array("label" => FIELDNAME, "name" => "fieldname"))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => HTMLTAG, "name" => "tagname", "prefix" => "&lt;!-- AShop_affiliate_", "suffix" => "--&gt;"))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => NUMBEROFROWS, "name" => "rows", "small" => TRUE))."</div>
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".ADD."\">".ADD."</button>
				</div>
            </form>
        </div>";

// Get tag information from database...
$sql="SELECT * FROM affiliatetags ORDER BY fieldname ASC";
$result = @mysqli_query($db, "$sql");
if (@mysqli_num_rows($result)) echo "
		<div class=\"box box-primary\">
			    <div class=\"box-header with-border\">
				    <h3 class=\"box-title\">".AVAILABLETAGS."</h3>
                </div>";
for ($i = 0; $i < @mysqli_num_rows($result); $i++) {
    $thisfieldname = @mysqli_result($result, $i, "fieldname");
    $thisaffiliatetagid = @mysqli_result($result, $i, "affiliatetagid");
	$thistagname = @mysqli_result($result, $i, "tagname");
	$thisrows = @mysqli_result($result, $i, "rows");
    echo "<form action=\"affiliatetags.php\" method=\"post\"><div class=\"box-body\">
                    <div class=\"form-group\">".admin_inputfield(array("label" => FIELDNAME, "name" => "fieldname", "value" => $thisfieldname))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => HTMLTAG, "name" => "tagname", "value" => $thistagname, "prefix" => "&lt;!-- AShop_affiliate_", "suffix" => "--&gt;"))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => NUMBEROFROWS, "name" => "rows", "value" => $thisrows, "small" => TRUE))."</div>
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary\" name=\"deletebutton\" value=\"".DELETELINK."\">".DELETELINK."</button>
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".UPDATE."\">".UPDATE."</button>
				</div>
                <input type=\"hidden\" name=\"affiliatetagid\" value=\"$thisaffiliatetagid\">
           </form>";
}

echo "</div></div></div></section>$footer";
?>