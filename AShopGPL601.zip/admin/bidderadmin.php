<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

error_reporting(E_ALL ^ E_NOTICE);

include "config.inc.php";
include "ashopfunc.inc.php";
if ($noinactivitycheck == "false") {
	if ($msg) $noinactivitycheck = "true";
	else $noinactivitycheck = "false";
}

include "checklogin.inc.php";
include "ashopconstants.inc.php";

// Validate variables...
if (!is_numeric($resultpage)) unset($resultpage);
if (!is_numeric($admindisplayitems)) unset($admindisplayitems);
else {
	$c_admindisplayitems = $admindisplayitems;
	if (!$p3psent) header('P3P: CP="IDC DSP COR CURa ADMa OUR IND PHY ONL COM STA"');
	$p3psent = TRUE;
	setcookie("c_admindisplayitems","$admindisplayitems");
}
if (!is_numeric($c_admindisplayitems)) unset($c_admindisplayitems);
$namefilter = str_replace("<","",$namefilter);
$namefilter = str_replace(">","",$namefilter);
$emailfilter = str_replace("<","",$emailfilter);
$emailfilter = str_replace(">","",$emailfilter);

if ($userid != "1") {
	header("Location: salesreport.php");
	exit;
}

include "template.inc.php";
// Get language module...
include "language/$adminlang/customers.inc.php";

// Get context help for this page...
$contexthelppage = "salesadmin";
include "help.inc.php";

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

// Check if penny auctions are used...
$bidderresult = @mysqli_query($db, "SELECT productid FROM floatingprice LIMIT 1");
if (!@mysqli_num_rows($bidderresult)) {
	header("Location: salesadmin.php");
	exit;
}

echo "$header
    <section class=\"content-header\"><h1>".CUSTOMERSANDMESSAGING." <a href=\"$help1\" target=\"_blank\"><img src=\"images/icon_helpsm.gif\" width=\"15\" height=\"15\" border=\"0\"></a></h1></section>
    <section class=\"content\">
		<div class=\"row\">
        <div class=\"col-xs-12\">
          <div class=\"box\">
            <div class=\"box-body\">";
if ($wholesalecatalog) {
    if (file_exists("$ashoppath/emerchant/quote.php")) {
	    echo "
                    <div class=\"btn-group\">
                      <a href=\"salesadmin.php\" class=\"btn btn-default\">".ALLCUSTOMERS."</a>
                      <a href=\"wssalesadmin.php\" class=\"btn btn-default\">".WHOLESALECUSTOMERS."</a>
                      <a href=\"salesadmin.php?recurring=true\" class=\"btn btn-default\">".RECURRINGBILLINGCUSTOMERS."</a>
                      <button type=\"button\" class=\"btn btn-default active\">".AUCTIONBIDDERS."</button>
                    </div><br>";
	} else echo "
                    <div class=\"btn-group\">
                      <a href=\"salesadmin.php\" class=\"btn btn-default\">".ALLCUSTOMERS."</a>
                      <a href=\"wssalesadmin.php\" class=\"btn btn-default\">".WHOLESALECUSTOMERS."</a>
                      <button type=\"button\" class=\"btn btn-default active\">".AUCTIONBIDDERS."</button>
                    </div><br>";
} else {
    if (file_exists("$ashoppath/emerchant/quote.php")) {
        echo "
                    <div class=\"btn-group\">
                      <a href=\"salesadmin.php\" class=\"btn btn-default\">".ALLCUSTOMERS."</a>
                      <a href=\"salesadmin.php?recurring=true\" class=\"btn btn-default\">".RECURRINGBILLINGCUSTOMERS."</a>
                      <button type=\"button\" class=\"btn btn-default active\">".AUCTIONBIDDERS."</button>
                    </div><br>";
	}
}

echo "<br>

              <table class=\"table table-bordered\">
                <thead><tr><th>".IDNAME."</th><th>".EMAIL."</th><th>".SCREENNAME."</th><th>".BIDS."</th><th>".ACTION."</th></tr></thead>
                <tbody>";

// Get bidder information from database...
$sql = "SELECT * FROM pricebidder";
$result = @mysqli_query($db, $sql);
$numberofrows = intval(@mysqli_num_rows($result));
if (!$admindisplayitems) {
	if ($c_admindisplayitems) $admindisplayitems = $c_admindisplayitems;
	else $admindisplayitems = 10;
}
$numberofpages = ceil($numberofrows/$admindisplayitems);
if ($resultpage > 1) $startrow = (intval($resultpage)-1) * $admindisplayitems;
else {
	$resultpage = 1;
	$startrow = 0;
}
$startpage = $resultpage - 9;
if ($numberofpages - $resultpage < 10) {
	$pagesleft = $numberofpages - $resultpage;
	$startpage = $startpage - (10 - $pagesleft);
}
if ($startpage < 1) $startpage = 1;
$stoprow = $startrow + $admindisplayitems;
@mysqli_data_seek($result, $startrow);
$thisrow = $startrow;
while (($row = @mysqli_fetch_array($result)) && ($thisrow < $stoprow)) {
	$customerid = $row["customerid"];
	$screenname = $row["screenname"];
	if (!$screenname) $screenname = "Unknown";
	$bids = $row["numberofbids"];
	$bidderid = $row["bidderid"];
	if (!$bids) $bids = 0;
	if ($customerid) {
		$customerresult = @mysqli_query($db, "SELECT firstname,lastname,email FROM customer WHERE customerid='$customerid'");
		$customerrow = @mysqli_fetch_array($customerresult);
		$firstname = $customerrow["firstname"];
		$lastname = $customerrow["lastname"];
		$email = $customerrow["email"];
	} else {
		$firstname = "";
		$lastname = "";
		$email = "";
	}
	$thisrow++;
	echo "<tr>
	<td>";
	if ($customerid && $email) echo "<a href=\"editcustomer.php?customerid=$customerid\">$customerid</a>, $firstname $lastname";
	else echo "&nbsp;";
	echo "</td><td><a href=\"mailto:$email\">$email</a>";
	echo "</td><td>$screenname</td><td>$bids</a><td><a href=\"editbidder.php?bidderid=$bidderid\"><img src=\"images/icon_profile.gif\" alt=\"".EDITBIDDER." $bidderid\" title=\"".EDITBIDDER." $bidderid\" border=\"0\"></a>&nbsp;<a href=\"editbidder.php?bidderid=$bidderid&remove=True\"><img src=\"images/icon_trash.gif\" alt=\"".DELETEBIDDER." $bidderid ".FROMDB."\" title=\"".DELETEBIDDER." $bidderid ".FROMDB."\" border=\"0\"></a>";
	echo "</td></tr>";
}

echo "</tbody></table>\n";
if ($numberofrows > 5) {
	echo "
        <div class=\"row\">
        <div class=\"col-md-4\"></div>
        <div class=\"col-md-4 text-center\">
        <nav aria-label=\"".PAGE."\">
            <ul class=\"pagination text-center\">";
	if ($numberofpages > 1) {
		if ($resultpage > 1) {
			$previouspage = $resultpage-1;
			echo "<li class=\"page-item\"><a class=\"page-link\" href=\"bidderadmin.php?resultpage=$previouspage&admindisplayitems=$admindisplayitems\">".PREVIOUS."</a></li>";
		}
		$page = 1;
		for ($i = $startpage; $i <= $numberofpages; $i++) {
			if ($page > 20) break;
			if ($i != $resultpage) echo "<li class=\"page-item\"><a class=\"page-link\" href=\"bidderadmin.php?resultpage=$i&admindisplayitems=$admindisplayitems\">";
			else echo "<li class=\"page-item active\"><span class=\"page-link\">";
			echo "$i";
			if ($i != $resultpage) echo "</a>";
            else echo "</span>";
            echo "</li>";
			$page++;
		}
		if ($resultpage < $numberofpages) {
			$nextpage = $resultpage+1;
			echo "<li class=\"page-item\"><a class=\"page-link\" href=\"bidderadmin.php?resultpage=$nextpage&admindisplayitems=$admindisplayitems\">".NEXTPAGE."</a></li>";
		}
	}
	echo "</ul>
    </nav></div>
    </div>
        <div class=\"row\">
        <div class=\"col-md-4\"></div>
        <div class=\"col-md-4\">
        <div class=\"form-group\"><label for=\"admindisplayitems\" class=\"col-sm-2 control-label\">".DISPLAY.":</label><div class=\"col-sm-10\"><select name=\"admindisplayitems\" class=\"form-control\" onChange=\"document.location.href='bidderadmin.php?resultpage=$resultpage&admindisplayitems='+document.admindisplayitems.value;\"><option value=\"$numberofrows\">".SELECT."</option>
		<option value=\"5\"";
		if ($c_admindisplayitems == "5") echo " selected";
		echo ">5</option><option value=\"10\"";
		if ($c_admindisplayitems == "10") echo " selected";
		echo ">10</option><option value=\"20\"";
		if ($c_admindisplayitems == "20") echo " selected";
		echo ">20</option><option value=\"40\"";
		if ($c_admindisplayitems == "40") echo " selected";
		echo ">40</option><option value=\"$numberofrows\"";
		if ($c_admindisplayitems == "$numberofrows") echo " selected";
		echo ">".ALL."</option></select><p class=\"help-block\">".CUSTOMERS2."</p></div></div></div></div>
	";
}
	
echo "</div></div></div></div></section>$footer";
?>