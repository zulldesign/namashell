<?php
include "version.inc.php"; echo $version;
?>