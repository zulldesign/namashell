<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

include "config.inc.php";
include "ashopfunc.inc.php";
include "checklogin.inc.php";
// Get context help for this page...
$contexthelppage = "editcontent";
include "help.inc.php";
include "template.inc.php";
// Get language module...
include "language/$adminlang/editcontent.inc.php";

   $db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

if (!$description) {
	$description = SAMPLECONTENTITEM;

  $sql="SELECT name FROM category WHERE categoryid = $cat";
  $result = @mysqli_query($db,$sql);
  $categoryname = @mysqli_result($result, $j, "name");
  echo "$header";
	  if (is_dir("$ashoppath/admin/ckeditor") && file_exists("$ashoppath/admin/ckeditor/ckeditor.js")) {
		  echo "
<script type=\"text/javascript\" src=\"ckeditor/ckeditor.js\"></script>
";
	  }
	  echo "
    <section class=\"content-header\"><h1>";
		if ($firstpage == "true") echo ADDFIRSTPAGE;
		else if ($aboutpage == "true") echo ADDABOUTPAGE;
		else if ($termspage == "true") echo ADDTERMSPAGE;
		else if ($privacypage == "true") echo ADDPRIVACYPAGE;
		else if ($cat == "pages") echo ADDPAGE;
		else echo ADDCONTENTTOCATEGORY.": $categoryname";
		echo "</h1></section>
    <section class=\"content\">
		<div class=\"row\">
			<div class=\"col-md-6\">
		<div class=\"box box-primary\">
            <form action=\"addcontent.php\" method=\"post\" name=\"productform\">
                <div class=\"box-body\">";
	   if ($cat != "pages") {
		   echo "
                    <div class=\"form-group\"><label><a href=\"javascript:;\" onMouseOut=\"MM_swapImgRestore()\" onMouseOver=\"MM_swapImage('Image5','','images/contexthelpicon_over.gif',1)\"><img src=\"images/contexthelpicon.gif\" width=\"14\" height=\"15\" border=\"0\" name=\"Image5\" align=\"absmiddle\" onclick=\"return overlib('$tip5');\" onmouseout=\"return nd();\"></a> ".CATALOGSTATUS."</label>
                    ";
                    if($wholesalecatalog) echo admin_checkbox(array("label" => ACTIVE." ".RETAIL, "name" => "active", "checked" => TRUE)).admin_checkbox(array("label" => WHOLESALE, "name" => "wholesale", "checked" => TRUE));
                    else echo admin_checkbox(array("label" => ACTIVE." ".RETAIL, "name" => "active", "checked" => TRUE));
                    echo "
                    </div>";
	   } else {
		   // Generate Digital Mall member list if needed...
		   if ($userid == "1" && file_exists("$ashoppath/members/index.php") && $digitalmall != "OFF") {
			   $memberlist = "<select class=\"form-control\" name=\"memberid\"><option value=\"1\">".ADMINISTRATOR;
			   $result = @mysqli_query($db,"SELECT * FROM user WHERE userid>1 ORDER BY shopname");
			   while ($row = @mysqli_fetch_array($result)) {
				   $memberlist .= "<option value=\"{$row["userid"]}\"";
				   if ($row["userid"] == $parentowner) $memberlist .= " selected";
				   $memberlist .= ">{$row["shopname"]}
				   ";
			   }
			   $memberlist .= "</select>";
		   }

		   // Generate language list...
		   $languagelist = "<select class=\"form-control\" name=\"nlanguage\"><option value=\"any\">".ANY;
		   $findfile = opendir("$ashoppath/language");
		   while ($foundfile = readdir($findfile)) {
			   if($foundfile && $foundfile != "." && $foundfile != ".." && is_dir("$ashoppath/language/$foundfile") && !strstr($foundfile, "CVS") && substr($foundfile, 0, 1) != "_" && file_exists("$ashoppath/language/$foundfile/lang.cfg.php")) {
				   $fp = fopen ("$ashoppath/language/$foundfile/lang.cfg.php","r");
				   while (!feof ($fp)) {
					   $fileline = fgets($fp, 4096);
					   if (strstr($fileline,"\$langname")) $langnamestring = $fileline;
				   }
				   fclose($fp);
				   eval ($langnamestring);
				   $languages["$foundfile"] = $langname;
			   }
		   }
		   if (is_array($languages)) {
			   natcasesort($languages);
			   foreach ($languages as $langmodule=>$langname) $languagelist .= "<option value=\"$langmodule\">$langname</option>";
		   }
           $languagelist .= "</select>";
		   echo "
		   <script language=\"JavaScript\" type=\"text/javascript\">
		   function updatefields() {
			   if (document.getElementById('typeselector').value == 'generic') {
				   document.getElementById('caption').style.display = '';
				   document.getElementById('url').style.display = 'none';
				   document.getElementById('contentbox').style.display = '';
			   } else if (document.getElementById('typeselector').value == 'link') {
				   document.getElementById('caption').style.display = '';
				   document.getElementById('url').style.display = '';
				   document.getElementById('contentbox').style.display = 'none';
			   } else {
				   document.getElementById('caption').style.display = 'none';
				   document.getElementById('url').style.display = 'none';
				   document.getElementById('contentbox').style.display = '';
			   }
		   }
		   </script>
		            <div class=\"form-group\"><label for=\"nlanguage\">".PAGETYPE."</label><select class=\"form-control\" id=\"typeselector\" name=\"pagetype\" onChange=\"updatefields();\"><option value=\"generic\">".GENERIC."</option><option value=\"link\">".EXTERNALLINK."</option><option value=\"firstpage\">".WELCOMEMESSAGE."</option><option value=\"firstpagemobile\">".WELCOMEMESSAGEMOBILE."</option><option value=\"about\">".ABOUTUS."</option><option value=\"terms\">".TERMS."</option><option value=\"privacy\">".PRIVACY."</option></select></div>";
		   if ($userid == "1" && file_exists("$ashoppath/members/index.php") && $digitalmall != "OFF") echo "<div class=\"form-group\"><label for=\"memberid\">".OWNER."</label>$memberlist</div>";
		   echo "
                    <div class=\"form-group\"><label for=\"nlanguage\">".LANGUAGE."</label>$languagelist</div>
                    <div class=\"form-group\" id=\"caption\">".admin_inputfield(array("label" => CAPTION, "name" => "ncaption"))."</div>
                    <div class=\"form-group\" id=\"url\" style=\"display: none;\">".admin_inputfield(array("label" => URL, "name" => "nurl"))."</div>";

	   }
	   if (is_dir("$ashoppath/admin/ckeditor") && file_exists("$ashoppath/admin/ckeditor/ckeditor.js")) echo "
                    <div class=\"form-group\" id=\"contentbox\">".admin_textbox(array("label" => DESCRIPTION, "name" => "description", "value" => $description, "helpnumber" => 9, "helptext" => $tip9, "WYSIWYG" => TRUE))."</div>";
	   else echo "
                    <div class=\"form-group\" id=\"contentbox\">".admin_textbox(array("label" => DESCRIPTION, "name" => "description", "value" => $description, "helpnumber" => 9, "helptext" => $tip9))."</div>";
       echo "
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".SUBMIT."\">".SUBMIT."</button>
				</div>
                <input type=\"hidden\" name=\"cat\" value=\"$cat\">
                <input type=\"hidden\" name=\"resultpage\" value=\"$resultpage\">
                <input type=\"hidden\" name=\"search\" value=\"$search\">
                <input type=\"hidden\" name=\"firstpage\" value=\"$firstpage\">
                <input type=\"hidden\" name=\"aboutpage\" value=\"$aboutpage\">
                <input type=\"hidden\" name=\"termspage\" value=\"$termspage\">
                <input type=\"hidden\" name=\"privacypage\" value=\"$privacypage\">
            </form>
            </div>
            </div>
            </div>
            </section>
            $footer";
} else {
   if ($pagetype == "firstpage") $productname = "AShopFirstPage";
   else if ($pagetype == "firstpagemobile") $productname = "AShopFirstPageMobile";
   else if ($pagetype == "about") $productname = "AShopAboutPage";
   else if ($pagetype == "terms") $productname = "AShopTermsPage";
   else if ($pagetype == "privacy") $productname = "AShopPrivacyPage";
   else if ($pagetype == "generic" || $pagetype == "link") $productname = $ncaption;
   else $productname = "AShopContent";
   if ($pagetype == "link") $description = "";
   if (!isset($memberid) || !is_numeric($memberid)) $memberid = $userid;
   $sql="INSERT INTO product (name,description, userid, prodtype, detailsurl, language) VALUES ('$productname','$description','$memberid','content','$nurl','$nlanguage')";
   $result = @mysqli_query($db,$sql);
   $product_id = @mysqli_insert_id($db);
   $sql="UPDATE product SET ordernumber='$product_id'";
   if ($userid != "1" && $memberactivate) $active = "on";
   if ($active == "on") $sql.=", active='1'";
   else $sql.=", active='0'";
   if ($wholesale == "on") $sql.=", wholesaleactive='1'";
   else $sql.=", wholesaleactive='0'";
   $sql.=" WHERE productid='$product_id'";
   $result = @mysqli_query($db,$sql);

   if (isset($cat) && is_numeric($cat)) {
	   $sql="INSERT INTO productcategory (productid,categoryid) VALUES ($product_id,$cat)";
	   $result = @mysqli_query($db,$sql);
   }

   if ($userid != "1" && !$memberactivate) {
	   $result = @mysqli_query($db,"SELECT prefvalue FROM preferences WHERE prefname='ashopname'");
	   $ashopname = @mysqli_result($result, 0, "prefvalue");
	   $result = @mysqli_query($db,"SELECT * FROM user WHERE userid='$userid'");
	   $membershopname = @mysqli_result($result, 0, "shopname");
	   $membershopemail = @mysqli_result($result, 0, "email");
	   $message="<html><head><title>$ashopname - ".MEMBERCONTENTACTIVATION."</title></head><body><font face=\"$font\"><p>".MEMBER." <b>$userid: $membershopname</b> ".HASADDEDNEW." <a href=\"$ashopurl/admin/login.php?prodactivate=$product_id\">".VERIFYCONTENT."</a></p></font></body></html>";
	   $headers = "From: ".un_html($membershopname)."<$membershopemail>\nX-Sender: <$membershopemail>\nX-Mailer: PHP\nX-Priority: 3\nReturn-Path: <$membershopemail>\nMIME-Version: 1.0\nContent-Type: text/html; charset=iso-8859-1\n";

	   @ashop_mail("$ashopemail",un_html($ashopname)." - ".MEMBERCONTENTACTIVATION,"$message","$headers");
   }

   if ($error) header ("Location: editcatalogue.php?cat=$cat&error=$error&resultpage=$resultpage&search=$search");
   else header ("Location: editcatalogue.php?cat=$cat&pid=$pid&search=$search&resultpage=$resultpage");
}
?>