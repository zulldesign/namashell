<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

include "config.inc.php";
include "ashopfunc.inc.php";
include "checklogin.inc.php";
include "template.inc.php";
// Get language module...
include "language/$adminlang/customers.inc.php";
include "ashopconstants.inc.php";
include "customers.inc.php";

if ($userid != "1") {
	header("Location: index.php");
	exit;
}

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

// Store updated data...
if ($update || $newlevel) {
	// Avoid duplicate email addresses...
	$result = @mysqli_query($db,"SELECT * FROM customer WHERE email='$email'");
	if (@mysqli_num_rows($result)) $errormsg = EMAILINUSE;
	else {
		if ($allowemail == "on") $allowemail = 1;
		else $allowemail = 0;
		if ($affiliateid == "0") $affiliateid = "";
		if ($newlevel) $newlevel = 1;
		// Convert money format...
		$virtualcash = str_replace($thousandchar,"",$virtualcash);
		$virtualcash = str_replace($decimalchar,".",$virtualcash);
		if (!empty($addvirtualcash)) {
			$addvirtualcash = str_replace($thousandchar,"",$addvirtualcash);
			$addvirtualcash = str_replace($decimalchar,".",$addvirtualcash);
			$virtualcash += $addvirtualcash;
		}
		// Encrypt password if encryption key is available...
		$password = trim($password);
		if (!empty($customerencryptionkey)) $password = ashop_encrypt($password, $customerencryptionkey);
		$sql="INSERT INTO customer (username, password, firstname, lastname, email, address, state, zip, city, country, phone, allowemail, extrainfo, affiliateid, level, virtualcash) VALUES ('$nusername', '$password', '$firstname', '$lastname', '$email', '$address', '$state', '$zip', '$city', '$country', '$phone', '$allowemail', '$extrainfo', '$affiliateid', '$newlevel', '$virtualcash')";
		$result = @mysqli_query($db,"$sql");
		$customerid = @mysqli_insert_id($db);

		$sql="INSERT INTO shipping (shippingbusiness, shippingfirstname, shippinglastname, shippingaddress, shippingaddress2, shippingzip, shippingcity, shippingstate, shippingcountry, vat, customerid) VALUES ('$shippingbusiness', '$shippingfirstname', '$shippinglastname', '$shippingaddress', '$shippingaddress2', '$shippingzip', '$shippingcity', '$shippingstate', '$shippingcountry', '$vat', '$customerid')";
		$result = mysqli_query($db,"$sql");

		header("Location: salesadmin.php"); 
		exit;
	}
}

// Close database...
@mysqli_close($db);


// Show customer page in browser...
	if (strpos($header, "title") != 0) {
	    $newheader = substr($header,1,strpos($header, "title")+5);
	    $newheader .= ADDNEWCUSTOMER." - ".substr($header,strpos($header, "title")+6,strlen($header));
    } else {
		$newheader = substr($header,1,strpos($header, "TITLE")+5);
		$newheader .= ADDNEWCUSTOMER." - ".substr($header,strpos($header, "TITLE")+6,strlen($header));
	}

echo "$newheader
    <section class=\"content-header\"><h1>".ADDNEWCUSTOMER."</h1></section>
    <section class=\"content\">
		<div class=\"row\">
			<div class=\"col-md-6\">
		<div class=\"box box-primary\">";
if ($userid == "1") echo "
            <form action=\"addcustomer.php\" method=\"post\">";
if ($errormsg) echo "
              <div class=\"alert alert-danger alert-dismissible\">
                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>
                $errormsg
              </div>";
echo "
                <div class=\"box-body\">
                    <div class=\"form-group\">".admin_inputfield(array("label" => USERNAME, "name" => "nusername", "value" => $nusername, "small" => TRUE))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => PASSWORD, "name" => "password", "value" => $password, "password" => TRUE, "small" => TRUE))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => REFERREDBY, "name" => "affiliateid", "value" => $affiliateid, "small" => TRUE))."</div>
                </div>
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">".BILLINGINFO."</h3>
                </div>
                <div class=\"box-body\">
                    <div class=\"form-group\">".admin_inputfield(array("label" => BUSINESSNAME, "name" => "shippingbusiness", "value" => $shippingbusiness))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => FIRSTNAME, "name" => "firstname", "value" => $firstname))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => LASTNAME, "name" => "lastname", "value" => $lastname))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => EMAIL, "name" => "email", "value" => $email))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => ADDRESS, "name" => "address", "value" => $address))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => CITY, "name" => "city", "value" => $city))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => STATEPROVINCE, "name" => "state", "value" => $state))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => ZIP, "name" => "zip", "value" => $zip, "small" => TRUE))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => COUNTRY, "name" => "country", "value" => $country))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => PHONE, "name" => "phone", "value" => $phone))."</div>";
	if ($requestabn) echo "
                    <div class=\"form-group\">".admin_inputfield(array("label" => ABN." ".NUMBER, "name" => "vat", "value" => $vat))."</div>";
	else echo "
                    <div class=\"form-group\">".admin_inputfield(array("label" => VAT." ".NUMBER, "name" => "vat", "value" => $vat))."</div>";
    echo "
                    <div class=\"form-group\">".admin_textbox(array("label" => ADDITIONAL." ".INFORMATION, "name" => "extrainfo", "value" => $extrainfo))."</div>
                </div>
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">".SHIPPINGINFO."</h3>
                </div>
                <div class=\"box-body\">
                    <div class=\"form-group\">".admin_inputfield(array("label" => FIRSTNAME, "name" => "shippingfirstname", "value" => $shippingfirstname))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => LASTNAME, "name" => "shippinglastname", "value" => $shippinglastname))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => ADDRESS, "name" => "shippingaddress", "value" => $shippingaddress))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => ADDRESS2, "name" => "shippingaddress2", "value" => $shippingaddress2))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => CITY, "name" => "shippingcity", "value" => $shippingcity))."</div>
                    <div class=\"form-group\">
                        <label for=\"shippingstate\">".STATEPROVINCE."</label>
                        <select class=\"form-control\" name=\"shippingstate\"><option value=none>".CHOOSESTATE;
		foreach ($americanstates as $longstate => $shortstate) {
			echo "<option value=$shortstate";
			if ($shortstate == $shippingstate) echo " selected";
			echo ">$longstate\n";
		}
 
echo "</select></div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => ZIP, "name" => "shippingzip", "value" => $shippingzip, "small" => TRUE))."</div>
                    <div class=\"form-group\">".admin_inputfield(array("label" => COUNTRY, "name" => "shippingcountry", "value" => $shippingcountry))."</div>
                    <div class=\"form-group\">".admin_checkbox(array("label" => SENDINGEMAILALLOWED, "name" => "allowemail", "checked" => $allowemail == "1"?TRUE:FALSE))."</div>
                </div>";
if ($userid == "1") echo "
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"update\" value=\"".SUBMIT."\">".SUBMIT."</button>
				</div>
                <input type=\"hidden\" name=\"customerid\" value=\"$customerid\">
            </form>";
echo "</div></div></div></section>$footer";
?>