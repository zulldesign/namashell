<?php
// AShop
// Copyright 2017 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

error_reporting(E_ALL ^ E_NOTICE);

include "config.inc.php";
include "ashopfunc.inc.php";
include "checklogin.inc.php";

if ($userid != "1") {
	header("Location: salesreport.php");
	exit;
}

include "template.inc.php";
// Get language module...
include "language/$adminlang/customers.inc.php";

// Get context help for this page...
$contexthelppage = "blacklist";
include "help.inc.php";

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

// Handle new and updated black list items...
if ($submitbutton && !empty($blacklistitem)) {
	if (!$blacklistitemid) {
		$sql="INSERT INTO customerblacklist (blacklistitem) VALUES ('$blacklistitem')";
	} else {
		$sql = "UPDATE customerblacklist SET blacklistitem='$blacklistitem' WHERE blacklistitemid='$blacklistitemid'";
	}
	$result = @mysqli_query($db, $sql);
}

// Delete black list item...
if ($deletebutton) {
	$sql = "DELETE FROM customerblacklist WHERE blacklistitemid=$blacklistitemid";
	$result = @mysqli_query($db, $sql);
}

echo "$header
    <section class=\"content-header\"><h1>".BLACKLISTEDCUSTOMERS." <a href=\"$help1\" target=\"_blank\"><img src=\"images/icon_helpsm.gif\" width=\"15\" height=\"15\" border=\"0\"></a></h1></section>
    <section class=\"content\">
		<div class=\"row\">
			<div class=\"col-md-6\">
		<div class=\"box box-primary\">
			<div class=\"box-header with-border\">
				<h3 class=\"box-title\">".BLACKLISTACUSTOMER."</h3>
			</div>
            <form action=\"bannedcustomers.php\" method=\"post\" name=\"addform\">
                <div class=\"box-body\">
                    <div class=\"form-group\">".admin_inputfield(array("label" => IPNUMBEROREMAIL, "name" => "blacklistitem"))."</div>
				</div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".ADD."\">".ADD."</button>
				</div>
			</form>
        </div>
      </div>
      </div>
";

// Get blacklist items from database...
$sql="SELECT * FROM customerblacklist ORDER BY blacklistitemid ASC";
$result = @mysqli_query($db, "$sql");
if (@mysqli_num_rows($result)) {
	echo "
		<div class=\"row\">
			<div class=\"col-md-6\">
		<div class=\"box box-primary\">
			<div class=\"box-header with-border\">
				<h3 class=\"box-title\">".CURRENTLYBLACKLISTED."</h3>
			</div>";
	for ($i = 0; $i < @mysqli_num_rows($result); $i++) {
		$thisblacklistitem = @mysqli_result($result, $i, "blacklistitem");
		$thisblacklistitemid = @mysqli_result($result, $i, "blacklistitemid");
		echo "
			<form action=\"bannedcustomers.php\" method=\"post\">
                <div class=\"box-body\">
                    <div class=\"form-group\">".admin_inputfield(array("label" => "", "name" => "blacklistitem", "value" => $thisblacklistitem))."</div>
                </div>
				<div class=\"box-footer\">
					<button type=\"submit\" class=\"btn btn-primary\" name=\"deletebutton\" value=\"".DELETEBLACKLISTED."\">".DELETEBLACKLISTED."</button>
					<button type=\"submit\" class=\"btn btn-primary pull-right\" name=\"submitbutton\" value=\"".UPDATE."\">".UPDATE."</button>
				</div>
                <input type=\"hidden\" name=\"blacklistitemid\" value=\"$thisblacklistitemid\">
             </form>";
	}
}

echo "</div></section>$footer";
?>