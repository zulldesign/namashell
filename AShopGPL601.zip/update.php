<?php
// AShop
// Copyright 2018 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

@set_time_limit(0);
error_reporting (E_ALL ^ E_NOTICE);

// AShop database initialization...

   $updating = TRUE;
   include "admin/version.inc.php";
   include "admin/config.inc.php";
   include "admin/ashopfunc.inc.php";

// Open database...

   $db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");
   if (!$db) $error = 1;

// Check if privileges are sufficient...
@mysqli_query($db, "DROP TABLE privtesttable");
@mysqli_query($db, "CREATE TABLE privtesttable (testid int not null, orderid int)");
if (@mysqli_error()) {
	echo "<html><head><title>Database error!</title></head>
         <body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
	     <tr bordercolor=\"#000000\" align=\"center\"><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
 		 <tr align=\"center\"><td> <img src=\"admin/images/logo.gif\"><br><hr width=\"50%\" size=\"0\" noshade>
		 </td></tr></table><p><font face=\"Arial, Helvetica, sans-serif\"><p><font size=\"3\"><b>Database error!</b></font>
	     <p><font size=\"2\">The database user does not have privileges to add tables!<br>Ask your hosting provider to give your database user privileges to add and modify database tables!</font></p></font></td></tr></table></body></html>";
	exit;
} else {
	@mysqli_query($db, "ALTER TABLE privtesttable ADD anotherfield VARCHAR(3)");
	if (@mysqli_error()) {
		echo "<html><head><title>Database error!</title></head>
         <body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
	     <tr bordercolor=\"#000000\" align=\"center\"><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
 		 <tr align=\"center\"><td> <img src=\"admin/images/logo.gif\"><br><hr width=\"50%\" size=\"0\" noshade>
		 </td></tr></table><p><font face=\"Arial, Helvetica, sans-serif\"><p><font size=\"3\"><b>Database error!</b></font>
	     <p><font size=\"2\">The database user does not have privileges to modify tables!<br>Ask your hosting provider to give your database user privileges to modify the structure of database tables!</font></p></font></td></tr></table></body></html>";
		 @mysqli_query($db, "DROP TABLE privtesttable");
		 exit;
	} else {
		@mysqli_query($db, "DROP TABLE privtesttable");
		if (@mysqli_error()) {
			echo "<html><head><title>Database error!</title></head>
			<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
			<tr bordercolor=\"#000000\" align=\"center\"><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
			<tr align=\"center\"><td> <img src=\"admin/images/logo.gif\"><br><hr width=\"50%\" size=\"0\" noshade>
			</td></tr></table><p><font face=\"Arial, Helvetica, sans-serif\"><p><font size=\"3\"><b>Database error!</b></font>
			<p><font size=\"2\">The database user does not have privileges to delete tables!<br>Ask your hosting provider to give your database user privileges to delete database tables!</font></p></font></td></tr></table></body></html>";
			exit;
		}
	}
}

@mysqli_query($db, "CREATE TABLE notification (
	notificationid int auto_increment not null,
	type varchar(15),
	message text,
	PRIMARY KEY (notificationid)
)");

@mysqli_query($db, "CREATE TABLE downloadslog (
	orderid int,
    fileid int,
	date varchar(30),
	ip varchar(15),
	INDEX (orderid),
	INDEX (fileid)
)");

@mysqli_query($db, "CREATE TABLE tempdllinks (
	dlcode varchar(5),
	fileid int,
	email varchar(50),
	password varchar(15),
	timestamp varchar(30),
	PRIMARY KEY (dlcode)
)");

@mysqli_query($db, "CREATE TABLE orderrequests (
    requestid int not null auto_increment,
    orderid int,
    date varchar(30),
    PRIMARY KEY (requestid),
    INDEX (orderid),
    INDEX (date)
)");

@mysqli_query($db, "CREATE TABLE productpreviewfiles (
	fileid int auto_increment not null,
	productid int,
	storage int,
	filename varchar(255),
	url text,
	PRIMARY KEY (fileid),
	INDEX (productid)
)");

@mysqli_query($db, "CREATE TABLE shippingstatus (
	shippingstatusid int4 not null auto_increment,
	orderid int,
	productname varchar(200),
	quantity int,
	status int,
	date varchar(30),
	PRIMARY KEY (shippingstatusid),
	INDEX (orderid),
	INDEX (status),
	INDEX (date)
)");

@mysqli_query($db, "CREATE TABLE party (
    partyid int not null auto_increment,
	customerid int,
    affiliateid int,
	description varchar(500),
	location varchar(500),
	date varchar(30),
	approved int,
	ended int,
	PRIMARY KEY (partyid),
	INDEX (customerid),
	INDEX (affiliateid),
	INDEX (approved)
)");

@mysqli_query($db, "CREATE TABLE partyrewards (
    rewardid int auto_increment not null,
	result decimal(8,2),
	value int,
	PRIMARY KEY (rewardid),
	INDEX (result)
)");

@mysqli_query($db, "CREATE TABLE partyinvitations (
    invitationid int auto_increment not null,
	partyid int,
	email varchar(50),
	date varchar(30),
	response varchar(10),
	PRIMARY KEY (invitationid),
	INDEX (email),
	INDEX (partyid)
)");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='mailertype'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('180', 'mailertype', 'mailfunction')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='mailerserver'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('181', 'mailerserver', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='mailerport'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('182', 'mailerport', '25')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='maileruser'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('183', 'maileruser', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='mailerpass'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('184', 'mailerpass', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='wholesalepercent'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('185', 'wholesalepercent', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='displaywswithtax'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('186', 'displaywswithtax', '0')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='memberpayoptions'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('187', 'memberpayoptions', '0')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='referrallength'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('188', 'referrallength', '0')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='aweberauthcode'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('189', 'aweberauthcode', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='shoppingmallinfo'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('190', 'shoppingmallinfo', 'This service will provide you with a plug and play shopping cart for your business. You can sell and securely deliver digital goods and/or shipped goods without the need for a merchant account. We will handle the payment from your customer and send it to you. Our fee is currently 10% of the price of your products. Your application will be reviewed by a live person before your membership is activated. Once approved, a password and link to your shop will be emailed to you.')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='mailchimpapikey'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('191', 'mailchimpapikey', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='maintenancemessage'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('192', 'maintenancemessage', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='eucookiecheck'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('193', 'eucookiecheck', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='includesubcategories'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('198', 'includesubcategories', '0')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='minfraudkey'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('199', 'minfraudkey', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='minfraudthreshold'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('200', 'minfraudthreshold', '10')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='minfraudgeoipkey'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('201', 'minfraudgeoipkey', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='fedexkey'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('205', 'fedexkey', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='fedexpassword'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('206', 'fedexpassword', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='showdecimals'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('207', 'showdecimals', '2')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='numberoffeatures'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('208', 'numberoffeatures', '3')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='massmailthrottle'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('209', 'massmailthrottle', '200')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='arpreachpath'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('210', 'arpreachpath', '')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='enablepartyplanner'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('212', 'enablepartyplanner', '0')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='homebannerurl1'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('213', 'homebannerurl1', 'index.php')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='homebannerurl2'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('214', 'homebannerurl2', 'index.php')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='homebannerurl3'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('215', 'homebannerurl3', 'index.php')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='enablemall'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('216', 'enablemall', '0')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='slogan'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('217', 'slogan', 'Catchy company slogan goes here.')");

$result = @mysqli_query($db, "SELECT * FROM preferences WHERE prefname='mapembed'");
if (!@mysqli_num_rows($result)) @mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('218', 'mapembed', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d4797.836151621091!2d-73.98005786281355!3d40.75218483738816!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sapple+store!5e0!3m2!1ssv!2sus!4v1453158441009\" width=\"95%\" height=\"300\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>')");

if (!$ashoptheme || $ashoptheme == "none") @mysqli_query($db, "UPDATE preferences SET prefvalue='default' WHERE prefname='ashoptheme'");

// Add separate wholesale affiliate commission field...
$result = @mysqli_query($db, "SELECT * FROM product");
while ($property = @mysqli_fetch_field($result)) {
    $producttablefields[] = $property->name;
}
if (!in_array("affiliatewscom",$producttablefields)) {
	@mysqli_query($db, "ALTER TABLE product ADD affiliatewscom varchar(50)");
	if ($wholesaleaffiliate == "1") @mysqli_query($db, "UPDATE product SET affiliatewscom=affiliatecom");
}

// Add field for the repeat commission option...
if (!in_array("affiliaterepeatcommission",$producttablefields)) {
	@mysqli_query($db, "ALTER TABLE product ADD affiliaterepeatcommission int");
	@mysqli_query($db, "UPDATE product SET affiliaterepeatcommission='1'");
}

// Add field for recommended products option...
@mysqli_query($db, "ALTER TABLE product ADD activaterecommended INT");

// Make sure the productname field for shipping status has room for attributes...
@mysqli_query($db, "ALTER TABLE shippingstatus MODIFY productname VARCHAR(200)");

// Track SKU codes in the shipping status table for partial refunds or activations...
@mysqli_query($db, "ALTER TABLE shippingstatus ADD skucode varchar(25)");

// Add field for ARP Reach integration...
@mysqli_query($db, "ALTER TABLE product ADD arpreachresponder int");

// Add field for country specific shipping rates...
@mysqli_query($db, "ALTER TABLE product ADD countryshipping varchar(500)");

// Add override for recurring period per product...
@mysqli_query($db, "ALTER TABLE product ADD recurringperiod VARCHAR(30)");

// Add userid field to payoptions table...
unset($payopttablefields);
$result = @mysqli_query($db, "SELECT * FROM payoptions");
while ($property = @mysqli_fetch_field($result)) {
    $payopttablefields[] = $property->name;
}
if (!in_array("userid",$payopttablefields)) {
	$sql = "ALTER TABLE payoptions ADD userid int";
	$result = @mysqli_query($db, "$sql");
	@mysqli_query($db, "UPDATE payoptions SET userid='1'");
}

// Make the secret field larger to hold First Data Global Connect 2 shared secrets...
$sql = "ALTER TABLE payoptions MODIFY secret VARCHAR(255)";
$result = @mysqli_query($db, "$sql");

// Add category ID field to store discounts...
$sql = "ALTER TABLE storediscounts ADD categoryid int";
$result = @mysqli_query($db, "$sql");

// Add quantity limit field to products...
$sql = "ALTER TABLE product ADD qtylimit int";
$result = @mysqli_query($db, "$sql");
$sql = "ALTER TABLE product ADD qtytlimit int";
$result = @mysqli_query($db, "$sql");
$sql = "ALTER TABLE productinventory ADD qtylimit int";
$result = @mysqli_query($db, "$sql");
$sql = "ALTER TABLE productinventory ADD qtytlimit int";
$result = @mysqli_query($db, "$sql");

// Add MailChimp list id to products...
$sql = "ALTER TABLE product ADD mailchimplist VARCHAR(20)";
$result = @mysqli_query($db, "$sql");

// Add product layout field to categories...
$sql = "ALTER TABLE category ADD productlayout int";
$result = @mysqli_query($db, "$sql");

// Add new referral date for time based affiliate tracking...
@mysqli_query($db, "ALTER TABLE orders ADD referral VARCHAR(8)");
@mysqli_query($db, "ALTER TABLE orders ADD pricelevel INT");
@mysqli_query($db, "ALTER TABLE orders ADD status VARCHAR(255)");
@mysqli_query($db, "ALTER TABLE orders ADD partyid INT");
@mysqli_query($db, "ALTER TABLE orders ADD storediscount INT");
@mysqli_query($db, "ALTER TABLE customer ADD referral VARCHAR(8)");
@mysqli_query($db, "ALTER TABLE customer MODIFY password VARCHAR(100)");

// Add new field for affiliate server to server reporting API...
@mysqli_query($db, "ALTER TABLE affiliate ADD apiurl varchar(255)");

// Add new field for sequential invoice IDs, required by some countries...
unset($ordertablefields);
$result = @mysqli_query($db, "SELECT * FROM orders");
while ($property = @mysqli_fetch_field($result)) {
    $ordertablefields[] = $property->name;
}
if (!in_array("invoiceid",$ordertablefields)) {
	@mysqli_query($db, "ALTER TABLE orders ADD invoiceid INT");
	@mysqli_query($db, "UPDATE orders SET invoiceid=orderid");
	@mysqli_query($db, "ALTER TABLE orders ADD INDEX (invoiceid)");
}

// Add new field for prerequisite to store discounts...
@mysqli_query($db, "ALTER TABLE storediscounts ADD prerequisite int");

// Clean up categories that no longer exists...
$result = @mysqli_query($db, "SELECT DISTINCT(categoryid) FROM productcategory");
while ($row = @mysqli_fetch_array($result)) {
	$categoryid = $row["categoryid"];
	$checkcategory = @mysqli_query($db, "SELECT * FROM category WHERE categoryid='$categoryid'");
	if (!@mysqli_num_rows($checkcategory)) @mysqli_query($db, "DELETE FROM productcategory WHERE categoryid='$categoryid'");
}

// Change AlertPay payoptions to Payza...
$result = @mysqli_query($db, "UPDATE payoptions SET gateway='payza' WHERE gateway='alertpay'");

// Add table and default items for the menu editor...
@mysqli_query($db, "CREATE TABLE menuitem (
	itemid int auto_increment not null,
	userid int,
	parentitemid int,
	language varchar(3),
	caption varchar(100),
	ordernumber int,
	memberclone int,
	url text,
	PRIMARY KEY (itemid),
	INDEX (caption),
	INDEX (language),
	INDEX (parentitemid),
	INDEX (userid)
)");

// Add affiliate ID to per product discounts...
$result = @mysqli_query($db, "ALTER TABLE discount ADD affiliate int");

// Add default menu items...
$result = @mysqli_query($db, "SELECT itemid FROM menuitem");
if (!@mysqli_num_rows($result)) {
	@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','Home','index.php')");
	@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE caption='Home'");
	@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','About Us','aboutus.php')");
	@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE caption='About Us'");
	@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','Terms &amp; Conditions','terms.php')");
	@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE caption='Terms &amp; Conditions'");
	@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','Affiliates','affiliate/signupform.php')");
	$parentitemid = @mysqli_insert_id($db);
	@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE itemid='$parentitemid'");
	@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url, parentitemid) VALUES ('1','1','any','Sign Up','affiliate/signupform.php','$parentitemid')");
	$itemid = @mysqli_insert_id($db);
	@mysqli_query($db, "UPDATE menuitem SET ordernumber=itemid WHERE itemid='$itemid'");
	@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url, parentitemid) VALUES ('1','1','any','Login','affiliate/login.php','$parentitemid')");
	$itemid = @mysqli_insert_id($db);
	@mysqli_query($db, "UPDATE menuitem SET ordernumber=itemid WHERE itemid='$itemid'");
	@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','Wholesale','wholesale/signupform.php')");
	$parentitemid = @mysqli_insert_id($db);
	@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE itemid='$parentitemid'");
	@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url, parentitemid) VALUES ('1','1','any','Sign Up','wholesale/signupform.php','$parentitemid')");
	$itemid = @mysqli_insert_id($db);
	@mysqli_query($db, "UPDATE menuitem SET ordernumber=itemid WHERE itemid='$itemid'");
	@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url, parentitemid) VALUES ('1','1','any','Login','wholesale/login.php','$parentitemid')");
	$itemid = @mysqli_insert_id($db);
	@mysqli_query($db, "UPDATE menuitem SET ordernumber=itemid WHERE itemid='$itemid'");
}

// Convert orderid field in unlockkeys table to proper field type...
$result = @mysqli_query($db, "ALTER TABLE unlockkeys MODIFY orderid INT");

// Convert old format product images...
$result = @mysqli_query($db, "SELECT productid FROM product ORDER BY productid");
while ($row = @mysqli_fetch_array($result)) {
	$productid = $row["productid"];
	if (!is_dir("$ashoppath/prodimg/$productid") && (file_exists("$ashoppath/prodimg/$productid.jpg") || file_exists("$ashoppath/prodimg/$productid.gif"))) {
		mkdir("$ashoppath/prodimg/$productid");
		chmod("$ashoppath/prodimg/$productid",0777);
	}
	$suffix = "jpg";
	if (file_exists("$ashoppath/prodimg/b$productid.$suffix")) rename("$ashoppath/prodimg/b$productid.$suffix","$ashoppath/prodimg/$productid/$productid.$suffix");
	if (file_exists("$ashoppath/prodimg/p$productid.$suffix")) rename("$ashoppath/prodimg/p$productid.$suffix","$ashoppath/prodimg/$productid/p-$productid.$suffix");
	if (file_exists("$ashoppath/prodimg/$productid.$suffix")) rename("$ashoppath/prodimg/$productid.$suffix","$ashoppath/prodimg/$productid/t-$productid.$suffix");
	if (file_exists("$ashoppath/prodimg/m$productid.$suffix")) rename("$ashoppath/prodimg/m$productid.$suffix","$ashoppath/prodimg/$productid/m-$productid.$suffix");
	$suffix = "gif";
	if (file_exists("$ashoppath/prodimg/b$productid.$suffix")) rename("$ashoppath/prodimg/b$productid.$suffix","$ashoppath/prodimg/$productid/$productid.$suffix");
	if (file_exists("$ashoppath/prodimg/p$productid.$suffix")) rename("$ashoppath/prodimg/p$productid.$suffix","$ashoppath/prodimg/$productid/p-$productid.$suffix");
	if (file_exists("$ashoppath/prodimg/$productid.$suffix")) rename("$ashoppath/prodimg/$productid.$suffix","$ashoppath/prodimg/$productid/t-$productid.$suffix");
	if (file_exists("$ashoppath/prodimg/m$productid.$suffix")) rename("$ashoppath/prodimg/m$productid.$suffix","$ashoppath/prodimg/$productid/m-$productid.$suffix");
	$imagenumber = 1;
	$suffix = "jpg";
	while (file_exists("$ashoppath/prodimg/{$productid}_$imagenumber.$suffix")) {
		if (!is_dir("$ashoppath/prodimg/$productid/$imagenumber")) {
			mkdir("$ashoppath/prodimg/$productid/$imagenumber");
			chmod("$ashoppath/prodimg/$productid/$imagenumber",0777);
		}
		if (file_exists("$ashoppath/prodimg/b{$productid}_$imagenumber.$suffix")) rename("$ashoppath/prodimg/b{$productid}_$imagenumber.$suffix","$ashoppath/prodimg/$productid/$imagenumber/$productid.$suffix");
		if (file_exists("$ashoppath/prodimg/p{$productid}_$imagenumber.$suffix")) rename("$ashoppath/prodimg/p{$productid}_$imagenumber.$suffix","$ashoppath/prodimg/$productid/$imagenumber/p-$productid.$suffix");
		if (file_exists("$ashoppath/prodimg/{$productid}_$imagenumber.$suffix")) rename("$ashoppath/prodimg/{$productid}_$imagenumber.$suffix","$ashoppath/prodimg/$productid/$imagenumber/t-$productid.$suffix");
		if (file_exists("$ashoppath/prodimg/m{$productid}_$imagenumber.$suffix")) rename("$ashoppath/prodimg/m{$productid}_$imagenumber.$suffix","$ashoppath/prodimg/$productid/$imagenumber/m-$productid.$suffix");
		$imagenumber++;
	}
	$imagenumber = 1;
	$suffix = "gif";
	while (file_exists("$ashoppath/prodimg/{$productid}_$imagenumber.$suffix")) {
		if (!is_dir("$ashoppath/prodimg/$productid/$imagenumber")) {
			mkdir("$ashoppath/prodimg/$productid/$imagenumber");
			chmod("$ashoppath/prodimg/$productid/$imagenumber",0777);
		}
		if (file_exists("$ashoppath/prodimg/b{$productid}_$imagenumber.$suffix")) rename("$ashoppath/prodimg/b{$productid}_$imagenumber.$suffix","$ashoppath/prodimg/$productid/$imagenumber/$productid.$suffix");
		if (file_exists("$ashoppath/prodimg/p{$productid}_$imagenumber.$suffix")) rename("$ashoppath/prodimg/p{$productid}_$imagenumber.$suffix","$ashoppath/prodimg/$productid/$imagenumber/p-$productid.$suffix");
		if (file_exists("$ashoppath/prodimg/{$productid}_$imagenumber.$suffix")) rename("$ashoppath/prodimg/{$productid}_$imagenumber.$suffix","$ashoppath/prodimg/$productid/$imagenumber/t-$productid.$suffix");
		if (file_exists("$ashoppath/prodimg/m{$productid}_$imagenumber.$suffix")) rename("$ashoppath/prodimg/m{$productid}_$imagenumber.$suffix","$ashoppath/prodimg/$productid/$imagenumber/m-$productid.$suffix");
		$imagenumber++;
	}
}

// Add fields for extended product file info...
@mysqli_query($db, "ALTER TABLE productfiles ADD name varchar(100)");
@mysqli_query($db, "ALTER TABLE productfiles ADD description text");
@mysqli_query($db, "ALTER TABLE productfiles ADD tags varchar(255)");
@mysqli_query($db, "ALTER TABLE productfiles ADD storage int");

// Create and store paidproductprices strings for all current orders...
$result = @mysqli_query($db, "SELECT * FROM orders WHERE paidproductprices<>''");
if (!@mysqli_num_rows($result)) {
	@mysqli_query($db, "ALTER TABLE orders ADD paidproductprices VARCHAR(255) NOT NULL");
	$result = @mysqli_query($db, "SELECT * FROM orders");
	$sql="UPDATE orders SET paidproductprices=productprices";
	$result2 = @mysqli_query($db, "$sql");
}

// Update version number...
@mysqli_query($db, "UPDATE preferences SET prefvalue='$version' WHERE prefname='ashopversion'");

// Create indexes...
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM customer WHERE Key_name='sessionid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE customer ADD INDEX (sessionid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM customer WHERE Key_name='email'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE customer ADD INDEX (email)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM customer WHERE Key_name='facebookid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE customer ADD INDEX (facebookid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM pendingcustomer WHERE Key_name='confirmationcode'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE pendingcustomer ADD INDEX (confirmationcode)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM pendingcustomer WHERE Key_name='email'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE pendingcustomer ADD INDEX (email)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM shipping WHERE Key_name='customerid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE shipping ADD INDEX (customerid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM affiliate WHERE Key_name='referralcode'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE affiliate ADD INDEX (referralcode)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM affiliate WHERE Key_name='user'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE affiliate ADD INDEX (user)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM affiliate WHERE Key_name='sessionid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE affiliate ADD INDEX (sessionid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM affiliatepm WHERE Key_name='toaffiliateid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE affiliatepm ADD INDEX (toaffiliateid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM affiliatereferer WHERE Key_name='affiliateid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE affiliatereferer ADD INDEX (affiliateid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM affiliatereferer WHERE Key_name='referer'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE affiliatereferer ADD INDEX (referer)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM affiliatetaginfo WHERE Key_name='affiliateid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE affiliatetaginfo ADD INDEX (affiliateid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM affiliatetaginfo WHERE Key_name='affiliatetagid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE affiliatetaginfo ADD INDEX (affiliatetagid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM pendingaffiliate WHERE Key_name='password'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE pendingaffiliate ADD INDEX (password)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM user WHERE Key_name='sessionid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE user ADD INDEX (sessionid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM user WHERE Key_name='username'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE user ADD INDEX (username)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM qtypricelevels WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE qtypricelevels ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM orders WHERE Key_name='customerid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE orders ADD INDEX (customerid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM orders WHERE Key_name='date'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE orders ADD INDEX (date)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM paymentinfo WHERE Key_name='orderid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE paymentinfo ADD INDEX (orderid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM paymentinfo WHERE Key_name='payoptionid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE paymentinfo ADD INDEX (payoptionid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM orderaffiliate WHERE Key_name='affiliateid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE orderaffiliate ADD INDEX (affiliateid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM orderaffiliate WHERE Key_name='orderid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE orderaffiliate ADD INDEX (orderid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM pendingorderaff WHERE Key_name='affiliateid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE pendingorderaff ADD INDEX (affiliateid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM pendingorderaff WHERE Key_name='orderid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE pendingorderaff ADD INDEX (orderid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM payoptions WHERE Key_name='gateway'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE payoptions ADD INDEX (gateway)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM formfields WHERE Key_name='payoptionid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE formfields ADD INDEX (payoptionid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM formfields WHERE Key_name='name'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE formfields ADD INDEX (name)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM fulfiloptions WHERE Key_name='method'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE fulfiloptions ADD INDEX (method)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM category WHERE Key_name='name'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE category ADD INDEX (name)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM category WHERE Key_name='grandparentcategoryid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE category ADD INDEX (grandparentcategoryid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM category WHERE Key_name='parentcategoryid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE category ADD INDEX (parentcategoryid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM product WHERE Key_name='skucode'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE product ADD INDEX (skucode)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM product WHERE Key_name='ebayid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE product ADD INDEX (ebayid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM product WHERE Key_name='detailsurl'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE product ADD INDEX (detailsurl)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM membershiplog WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE membershiplog ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM membershiplog WHERE Key_name='customerid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE membershiplog ADD INDEX (customerid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM reviews WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE reviews ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM reviews WHERE Key_name='customerid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE reviews ADD INDEX (customerid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM maillog WHERE Key_name='mailingid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE maillog ADD INDEX (mailingid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM productinventory WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE productinventory ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM productinventory WHERE Key_name='skucode'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE productinventory ADD INDEX (skucode)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM productfiles WHERE Key_name='fileid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE productfiles ADD INDEX (fileid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM orderdownloads WHERE Key_name='orderid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE orderdownloads ADD INDEX (orderid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM orderdownloads WHERE Key_name='fileid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE orderdownloads ADD INDEX (fileid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM discount WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE discount ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM discount WHERE Key_name='customerid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE discount ADD INDEX (customerid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM storediscounts WHERE Key_name='affiliate'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE storediscounts ADD INDEX (affiliate)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM storediscounts WHERE Key_name='code'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE storediscounts ADD INDEX (code)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM storediscounts WHERE Key_name='customerid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE storediscounts ADD INDEX (customerid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM onetimediscounts WHERE Key_name='discountid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE onetimediscounts ADD INDEX (discountid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM onetimediscounts WHERE Key_name='customerid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE onetimediscounts ADD INDEX (customerid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM updates WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE updates ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM updates WHERE Key_name='password'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE updates ADD INDEX (password)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM unlockkeys WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE unlockkeys ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM packages WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE packages ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM shipdiscounts WHERE Key_name='quantity'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE shipdiscounts ADD INDEX (quantity)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM zipzones WHERE Key_name='zip'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE zipzones ADD INDEX (zip)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM zipzones WHERE Key_name='zonename'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE zipzones ADD INDEX (zonename)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM zonerates WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE zonerates ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM zonerates WHERE Key_name='zone'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE zonerates ADD INDEX (zone)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM quantityrates WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE quantityrates ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM quantityrates WHERE Key_name='quantity'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE quantityrates ADD INDEX (quantity)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM parameters WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE parameters ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM parametervalues WHERE Key_name='parameterid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE parametervalues ADD INDEX (parameterid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM customparametervalues WHERE Key_name='parameterid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE customparametervalues ADD INDEX (parameterid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM productcategory WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE productcategory ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM productcategory WHERE Key_name='categoryid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE productcategory ADD INDEX (categoryid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM linkcodes WHERE Key_name='linkcategoryid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE linkcodes ADD INDEX (linkcategoryid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM customerblacklist WHERE Key_name='blacklistitem'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE customerblacklist ADD INDEX (blacklistitem)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM visitcounter_online WHERE Key_name='ip'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE visitcounter_online ADD INDEX (ip)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM visitcounter_online WHERE Key_name='time'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE visitcounter_online ADD INDEX (time)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM visitcounter_today WHERE Key_name='ip'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE visitcounter_today ADD INDEX (ip)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM visitcounter_today WHERE Key_name='time'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE visitcounter_today ADD INDEX (time)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM savedcarts WHERE Key_name='customerid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE savedcarts ADD INDEX (customerid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM preferences WHERE Key_name='prefname'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE preferences ADD INDEX (prefname)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM wholesalepaymentinfo WHERE Key_name='orderid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE wholesalepaymentinfo ADD INDEX (orderid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM searchstatistics WHERE Key_name='keyword'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE searchstatistics ADD INDEX (keyword)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM searchstatistics WHERE Key_name='date'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE searchstatistics ADD INDEX (date)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM floatingprice WHERE Key_name='bidderid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE floatingprice ADD INDEX (bidderid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM pricebidder WHERE Key_name='bidcode'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE pricebidder ADD INDEX (bidcode)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM pricebidder WHERE Key_name='customerid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE pricebidder ADD INDEX (customerid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM relatedproducts WHERE Key_name='productid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE relatedproducts ADD INDEX (productid)");
$checkindexresult = @mysqli_query($db, "SHOW INDEX FROM autoresponders WHERE Key_name='responderid'");
if (!@mysqli_num_rows($checkindexresult)) @mysqli_query($db, "ALTER TABLE autoresponders ADD INDEX (responderid)");


// Redirect user to admin area...

if (!$error) header("Location: admin/index.php");
else header("Location: admin/index.php?error=$error");
?>