<?php
####################################################################################
##                                                                                ##
##			Signup Customer With S2 Member Site - Automation Example		      ##
##                                                                                ##
##                            Installation instructions:                          ##
##                                                                                ##
##              1. Change the $ashoppath variable to the path where AShop is      ##
##                 installed on the server.										  ##
##              2. Change the $password variable to a personal password.		  ##
##                                                                                ##
####################################################################################

$ashoppath = "c:\apache\htdocs\ashopdeluxe";
$password = "yourownpassword";

####################################################################################
##                                                                                ##
##                           Do not edit below this.                              ##
##                                                                                ##
####################################################################################

if ($_POST["password"] != $password) exit;

include "$ashoppath/admin/config.inc.php";
include "$ashoppath/admin/ashopfunc.inc.php";

$debugtext = "";
$debugtexthtml = "";

// Validate variables...
foreach($_POST as $variable=>$value) {
	$debugtext .= "$variable = $value\n";
	$debugtexthtml .= "$variable = $value<br>";
}


if ($receiptformat == "html") $message="<tr><td colspan=\"2\"><table width=\"100%\" cellpadding=\"5\"><tr><td bgcolor=\"#ffffff\" align=\"left\"><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">$debugtexthtml</font></td></tr></table></td></tr>";
else $message = "
		$debugtext
		";
echo $message;
exit;
?>