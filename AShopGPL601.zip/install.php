<?php
// AShop
// Copyright 2018 - AShop Software - http://www.ashopsoftware.com
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, see: http://www.gnu.org/licenses/.

// Get the correct path to the scripts...
	$path = (substr(PHP_OS, 0, 3) == 'WIN') ? strtolower(getcwd()) : getcwd();
	$path = str_replace("\\","/",$path);
	if (!isset($ashoppath)) $ashoppath = $path;

// REQUEST_URI fix for Windows+IIS...
if (!isset($REQUEST_URI) and isset($_SERVER['SCRIPT_NAME'])) {
    $REQUEST_URI = $_SERVER['SCRIPT_NAME'];
    if (isset($_SERVER['QUERY_STRING']) and !empty($_SERVER['QUERY_STRING'])) $REQUEST_URI .= '?' . $_SERVER['QUERY_STRING'];
}

// AShop database initialization
$updating = TRUE;
include "admin/version.inc.php";
include "admin/config.inc.php";
include "admin/ashopfunc.inc.php";

// Open database...
$db = @mysqli_connect("$databaseserver", "$databaseuser", "$databasepasswd", "$databasename");

// Check if the database configuration is working...
if (!$db) {
	if (is_writeable("$ashoppath/admin/config.inc.php")) {
		if ($_POST["ndatabaseserver"] && $_POST["ndatabaseuser"] && $_POST["ndatabasepasswd"] && $_POST["ndatabasename"]) {
			// Store new database configuration options...
			$configfile = "";
			$fp = @fopen ("$ashoppath/admin/config.inc.php","r");
			if ($fp) {
				while (!feof ($fp)) $configfile .= fgets($fp, 4096);
				fclose($fp);
				$configfile = str_replace("\"$databaseserver\"","\"".$_POST["ndatabaseserver"]."\"",$configfile);
				$configfile = str_replace("\"$databaseuser\"","\"".$_POST["ndatabaseuser"]."\"",$configfile);
				$configfile = str_replace("\"$databasepasswd\"","\"".$_POST["ndatabasepasswd"]."\"",$configfile);
				$configfile = str_replace("\"$databasename\"","\"".$_POST["ndatabasename"]."\"",$configfile);
				$fp = fopen ("$ashoppath/admin/config.inc.php","w");
				fwrite($fp, $configfile);
				fclose($fp);
			}
			header("Location: install.php");
			exit;
		} else {
			echo "<html><head><title>AShop Installation</title></head>
			<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"700\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
			<tr><td align=\"center\"><img src=\"admin/images/logo.gif\"><br><hr width=\"100%\" size=\"0\" noshade><br><font face=\"Arial, Helvetica, sans-serif\" size=\"3\"><b>Database Configuration</b></font><br><br>
			</td></tr><tr><td><font face=\"Arial, Helvetica, sans-serif\">";
			if ($databasename != "ashop" || $databaseuser != "user" || $databasepasswd != "password") echo "<p><font size=\"2\" color=\"#FF0000\">The user name, password or host you entered are incorrect!</font></p>";
			echo "
			<form action=\"install.php\" method=\"post\">
			<p><font size=\"2\">Enter your database connection details...</font></p>
			<table width=\"100%\" cellpadding=\"5\" cellspacing=\"0\" border=\"0\">
			<tr><td align=\"left\" width=\"150\"><font size=\"2\">Database Name: </font></td><td align=\"left\"><input type=\"text\" size=\"30\" name=\"ndatabasename\" value=\"$databasename\"></td><td align=\"left\"><font size=\"2\">The name of the database you want to use for your AShop.</font></td></tr>
			<tr><td align=\"left\"><font size=\"2\">User Name: </font></td><td align=\"left\"><input type=\"text\" size=\"30\" name=\"ndatabaseuser\" value=\"$databaseuser\"></td><td align=\"left\"><font size=\"2\">Your MySQL username</font></td></tr>
			<tr><td align=\"left\"><font size=\"2\">Password: </font></td><td align=\"left\"><input type=\"text\" size=\"30\" name=\"ndatabasepasswd\" value=\"$databasepasswd\"></td><td align=\"left\"><font size=\"2\">...and MySQL password.</font></td></tr>
			<tr><td align=\"left\"><font size=\"2\">Database Host: </font></td><td align=\"left\"><input type=\"text\" size=\"30\" name=\"ndatabaseserver\" value=\"$databaseserver\"></td><td align=\"left\"><font size=\"2\">Usually <i>localhost</i>. Check with your hosting provider if this does not work.</font></td></tr>
			</table>
			<p align=\"right\"><input type=\"submit\" value=\"Continue Installation >>\"></p>
			</form></font></td></tr></table></body></html>";
			exit;
		}
	} else {
		$error = 1;
		echo "<html><head><title>Database error!</title></head>
         <body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
	     <tr bordercolor=\"#000000\" align=\"center\"><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
 		 <tr align=\"center\"><td> <img src=\"admin/images/logo.gif\"><br><hr width=\"50%\" size=\"0\" noshade>
		 </td></tr></table><p><font face=\"Arial, Helvetica, sans-serif\"><p><font size=\"3\"><b>Database error!</b></font>
	     <p><font size=\"2\">Cannot connect to database on <b>$databaseserver</b>.<br><br>Check the settings for database server, database user and<br>database password in admin/config.inc.php!</font></p></font></td></tr></table></body></html>";
		 @mysqli_close($db);
		 exit;
	}
}
if (!$error && !$db) {
	if (is_writeable("$ashoppath/admin/config.inc.php")) {
		if ($_POST["ndatabaseserver"] && $_POST["ndatabaseuser"] && $_POST["ndatabasepasswd"] && $_POST["ndatabasename"]) {
			// Store new database configuration options...
			$configfile = "";
			$fp = @fopen ("$ashoppath/admin/config.inc.php","r");
			if ($fp) {
				while (!feof ($fp)) $configfile .= fgets($fp, 4096);
				fclose($fp);
				$configfile = str_replace("\"$databaseserver\"","\"".$_POST["ndatabaseserver"]."\"",$configfile);
				$configfile = str_replace("\"$databaseuser\"","\"".$_POST["ndatabaseuser"]."\"",$configfile);
				$configfile = str_replace("\"$databasepasswd\"","\"".$_POST["ndatabasepasswd"]."\"",$configfile);
				$configfile = str_replace("\"$databasename\"","\"".$_POST["ndatabasename"]."\"",$configfile);
				$fp = fopen ("$ashoppath/admin/config.inc.php","w");
				fwrite($fp, $configfile);
				fclose($fp);
			}
			header("Location: install.php");
			exit;
		} else {
			echo "<html><head><title>AShop Installation</title></head>
			<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"700\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
			<tr><td align=\"center\"><img src=\"admin/images/logo.gif\"><br><hr width=\"100%\" size=\"0\" noshade><br><font face=\"Arial, Helvetica, sans-serif\" size=\"3\"><b>Database Configuration</b></font><br><br>
			</td></tr><tr><td><font face=\"Arial, Helvetica, sans-serif\">
			<form action=\"install.php\" method=\"post\">
			<p><font size=\"2\" color=\"#FF0000\">The database name: <b>$databasename</b> is incorrect! Check the settings!</font></p>
			<p><font size=\"2\">Enter your database connection details...</font></p>
			<table width=\"100%\" cellpadding=\"5\" cellspacing=\"0\" border=\"0\">
			<tr><td align=\"left\" width=\"150\"><font size=\"2\">Database Name: </font></td><td align=\"left\"><input type=\"text\" size=\"30\" name=\"ndatabasename\" value=\"$databasename\"></td><td align=\"left\"><font size=\"2\">The name of the database you want to user for your AShop.</font></td></tr>
			<tr><td align=\"left\"><font size=\"2\">User Name: </font></td><td align=\"left\"><input type=\"text\" size=\"30\" name=\"ndatabaseuser\" value=\"$databaseuser\"></td><td align=\"left\"><font size=\"2\">Your MySQL username</font></td></tr>
			<tr><td align=\"left\"><font size=\"2\">Password: </font></td><td align=\"left\"><input type=\"text\" size=\"30\" name=\"ndatabasepasswd\" value=\"$databasepasswd\"></td><td align=\"left\"><font size=\"2\">...and MySQL password.</font></td></tr>
			<tr><td align=\"left\"><font size=\"2\">Database Host: </font></td><td align=\"left\"><input type=\"text\" size=\"30\" name=\"ndatabaseserver\" value=\"$databaseserver\"></td><td align=\"left\"><font size=\"2\">Usually <i>localhost</i>. Check with your hosting provider if this does not work.</font></td></tr>
			</table>
			<p align=\"right\"><input type=\"submit\" value=\"Continue Installation >>\"></p>
			</form></font></td></tr></table></body></html>";
			exit;
		}
	} else {
		echo "<html><head><title>Database error!</title></head>
         <body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
	     <tr bordercolor=\"#000000\" align=\"center\"><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
 		 <tr align=\"center\"><td> <img src=\"admin/images/logo.gif\"><br><hr width=\"50%\" size=\"0\" noshade>
		 </td></tr></table><p><font face=\"Arial, Helvetica, sans-serif\"><p><font size=\"3\"><b>Database error!</b></font>
	     <p><font size=\"2\">The database name: <b>$databasename</b> is incorrect! Check the settings in your admin/config.inc.php!</font></p></font></td></tr></table></body></html>";
	}
	@mysqli_close($db);
	exit;
}

// Check if privileges are sufficient...
@mysqli_query($db, "DROP TABLE privtesttable");
@mysqli_query($db, "CREATE TABLE privtesttable (testid int not null, orderid int)");
if (@mysqli_error()) {
	echo "<html><head><title>Database error!</title></head>
         <body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
	     <tr bordercolor=\"#000000\" align=\"center\"><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
 		 <tr align=\"center\"><td> <img src=\"admin/images/logo.gif\"><br><hr width=\"50%\" size=\"0\" noshade>
		 </td></tr></table><p><font face=\"Arial, Helvetica, sans-serif\"><p><font size=\"3\"><b>Database error!</b></font>
	     <p><font size=\"2\">The database user does not have privileges to add tables!<br>Ask your hosting provider to give your database user privileges to add and modify database tables!</font></p></font></td></tr></table></body></html>";
	exit;
} else {
	@mysqli_query($db, "ALTER TABLE privtesttable ADD anotherfield VARCHAR(3)");
	if (@mysqli_error()) {
		echo "<html><head><title>Database error!</title></head>
         <body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
	     <tr bordercolor=\"#000000\" align=\"center\"><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
 		 <tr align=\"center\"><td> <img src=\"admin/images/logo.gif\"><br><hr width=\"50%\" size=\"0\" noshade>
		 </td></tr></table><p><font face=\"Arial, Helvetica, sans-serif\"><p><font size=\"3\"><b>Database error!</b></font>
	     <p><font size=\"2\">The database user does not have privileges to modify tables!<br>Ask your hosting provider to give your database user privileges to modify the structure of database tables!</font></p></font></td></tr></table></body></html>";
		 @mysqli_query($db, "DROP TABLE privtesttable");
		 exit;
	} else {
		@mysqli_query($db, "DROP TABLE privtesttable");
		if (@mysqli_error()) {
			echo "<html><head><title>Database error!</title></head>
			<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
			<tr bordercolor=\"#000000\" align=\"center\"><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
			<tr align=\"center\"><td> <img src=\"admin/images/logo.gif\"><br><hr width=\"50%\" size=\"0\" noshade>
			</td></tr></table><p><font face=\"Arial, Helvetica, sans-serif\"><p><font size=\"3\"><b>Database error!</b></font>
			<p><font size=\"2\">The database user does not have privileges to delete tables!<br>Ask your hosting provider to give your database user privileges to delete database tables!</font></p></font></td></tr></table></body></html>";
			exit;
		}
	}
}


// Check if the database has been setup already...
$result = @mysqli_query($db, "SELECT * FROM preferences");
if (@mysqli_num_rows($result)) {

	// Create an affiliate account for AShop Software to support development of AShop...
	if ( ! function_exists('makePassword') ) {
		function makePassword() {
			$alphaNum = array(2, 3, 4, 5, 6, 7, 8, 9, a, b, c, d, e, f, g, h, i, j, k, m, n, p, q, r, s, t, u, v, w, x, y, z);
			srand ((double) microtime() * 1000000);
			$pwLength = "7"; // this sets the limit on how long the password is.
			for($i = 1; $i <=$pwLength; $i++) {
				$newPass .= $alphaNum[(rand(0,31))];
			}
			return ($newPass);
		}
	}
	$affpassword = makePassword();
	$date = date("Y-m-d H:i:s", time());
	@mysqli_query($db, "INSERT INTO affiliate (user, password, business, firstname, lastname, email, address, state, zip, city, country, phone, url, paypalid, signedup, updated, referralcode, commissionlevel, extrainfo) VALUES ('ashopsoft', '$affpassword', 'AShop Software', 'AShop', 'Software', 'affiliate@ashopsoftware.com', 'Ringvagen 25', 'Skane', '28020', 'Bjarnum', 'SE', '555', 'http://www.ashopsoftware.com', 'affiliate@ashopsoftware.com', '$date', '$date', 'ashop001', 1, '')");
	@ashop_mail("affiliate@ashopsoftware.com","New AShop Affiliate Account","URL: $ashopurl/affiliate/login.php\nUsername: ashopsoft\nPassword: $affpassword\n");
	@mysqli_close($db);
	header("Location: admin/login.php");
	exit;
} else if (!$_POST["startinstall"]) {
	echo "<html><head><title>AShop Installation</title></head>
			<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"40%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
			<tr><td align=\"center\"><img src=\"admin/images/logo.gif\"><br><hr width=\"100%\" size=\"0\" noshade><br><font face=\"Arial, Helvetica, sans-serif\" size=\"3\"><b>Welcome to AShop!</b></font><br><br>
			</td></tr><tr><td><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">
			<P>When you click the button below the database tables for AShop will be created and default settings will be stored. After this you will be able to login to the AShop administration panel from where you can modify the settings of AShop to fit your needs.</p><p>If you want to support further development of AShop visit our website at: <a href=\"http://www.ashopsoftware.com\" target=\"_blank\">www.ashopsoftware.com</a> to buy addon products or donate to the project.</P></font>
			<p align=\"right\"><form action=\"install.php\" method=\"post\"><input type=\"hidden\" name=\"startinstall\" value=\"true\"><input type=\"submit\" value=\"Start Installation >>\"></form></p>
			</font></td></tr></table></body></html>";
	@mysqli_close($db);
	exit;
} else {

	// Make sure the correct path and url can be found...
	if ($_SERVER['HTTPS'] == "on") $url = "https://";
	else $url = "http://";
	$url .= $HTTP_HOST.$REQUEST_URI;
	$url = str_replace("/install.php","",$url);

	if (!$path || !$url) {
		if (!$_POST["ashoppath"] && !$_POST["ashopurl"]) {
			echo "<html><head><title>AShop Installation</title></head>
			<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\"><table width=\"40%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
			<tr><td align=\"center\"><img src=\"admin/images/logo.gif\"><br><hr width=\"100%\" size=\"0\" noshade><br><font face=\"Arial, Helvetica, sans-serif\" size=\"3\"><b>The following parameter(s) could not be automatically set...</b></font><br><br>
			</td></tr><tr><td><font face=\"Arial, Helvetica, sans-serif\">
			<form action=\"install.php\" method=\"post\">";
			if (!$path) echo "
			<p><font size=\"2\"><b>File system path to this AShop</b></font></p>
			<blockquote><font size=\"2\">Enter path: <input type=\"text\" size=\"40\" name=\"ashoppath\" value=\"$ashoppath\"></font></blockquote>";
			if (!$url) echo "
			<p><font size=\"2\"><b>The URL to this AShop</b>:</font></p><blockquote><font size=\"2\">Enter URL: <input type=\"text\" size=\"40\" name=\"ashopurl\" value=\"$ashopurl\"></font></blockquote>";
			echo "
			<p align=\"right\"><input type=\"hidden\" name=\"startinstall\" value=\"true\"><input type=\"submit\" value=\"Continue Installation >>\"></p>
			</form></font></td></tr></table></body></html>";
			@mysqli_close($db);
			exit;
		} else {
			if ($_POST["ashoppath"]) $path = $_POST["ashoppath"];
			if ($_POST["ashopurl"]) $url = $_POST["ashopurl"];
			
		}
	}

	// Create default secure URL...
	$secureurl = str_replace("http://", "https://", $url);
}

// Create tables...
@mysqli_query($db, "CREATE TABLE customer (
	username varchar(50),
	password varchar(100),
	sessionid varchar(50),
	ip varchar(15),
	activity varchar(30),
	level int default 0,
	businessname varchar(50),
	businesstype varchar(15),
	url varchar(50),
	resellerid varchar(30),
	firstname varchar(50),
	lastname varchar(50),
	email varchar(50) not null,
	alternativeemails text,
	address varchar(50),
	zip varchar(10),
	city varchar(30),
	state varchar(30),
	country varchar(30),
	phone varchar(20),
	alternativephones text,
	extrainfo text,
	customerid int4 not null auto_increment,
	preflanguage varchar(2),
	allowemail int,
	affiliateid varchar(255),
	referral varchar(8),
	virtualcash decimal(10,2),
	facebookid varchar(20),
	PRIMARY KEY (customerid),
	INDEX (sessionid),
	INDEX (email),
	INDEX (facebookid)
)");

@mysqli_query($db, "CREATE TABLE pendingcustomer (
	username varchar(50),
	password varchar(30),
	firstname varchar(50),
	lastname varchar(50),
	email varchar(50),
	customerid int4 not null auto_increment,
	allowemail int,
	confirmationcode varchar(50),
	affiliateid varchar(255),
	PRIMARY KEY (customerid),
	INDEX (confirmationcode),
	INDEX (email)
)");

@mysqli_query($db, "CREATE TABLE shippingstatus (
	shippingstatusid int4 not null auto_increment,
	orderid int,
	productname varchar(200),
	skucode varchar(25),
	quantity int,
	status int,
	date varchar(30),
	PRIMARY KEY (shippingstatusid),
	INDEX (orderid),
	INDEX (status),
	INDEX (date)
)");

@mysqli_query($db, "CREATE TABLE currencies (
	currencycode varchar(3),
	rate decimal(10,2),
	updated varchar(30),
	PRIMARY KEY (currencycode)
)");

@mysqli_query($db, "CREATE TABLE tempdllinks (
	dlcode varchar(5),
	fileid int,
	email varchar(50),
	password varchar(15),
	timestamp varchar(30),
	PRIMARY KEY (dlcode)
)");

@mysqli_query($db, "CREATE TABLE shipping (
	shippingbusiness varchar(50),
	shippingfirstname varchar(50),
	shippinglastname varchar(50),
	shippingaddress varchar(50),
	shippingaddress2 varchar(50),
	shippingzip varchar(10),
	shippingcity varchar(30),
	shippingstate varchar(30),
	shippingcountry varchar(30),
	shippingphone varchar(20),
	shippingemail varchar(50),
	sameasbilling int,
	selectedoption int,
	vat varchar(255),
	customerid int,
	shippingid int not null auto_increment,
	PRIMARY KEY (shippingid),
	INDEX (customerid)
)");

@mysqli_query($db, "CREATE TABLE affiliate (
	user varchar(50),
	password varchar(50),
	sessionid varchar(50),
	ip varchar(15),
	activity varchar(30),
	business varchar(50),
    firstname varchar(50),
	lastname varchar(50),
    email varchar(50),
	paypalid varchar(50),
    address varchar(50),
    state varchar(50),
    zip varchar(10),
    city varchar(30),
	country varchar(30),
	signedup varchar(30),
	updated varchar(30),
	lastdate varchar(30),
    url varchar(255),
	apiurl varchar(255),
    phone varchar(20),
	clicks int,
	referedby int,
    affiliateid int not null auto_increment,
	referralcode varchar(10),
	commissionlevel int,
	extrainfo text,
	confirmcode varchar(10),
    PRIMARY KEY (affiliateid),
	INDEX (referralcode),
	INDEX (user),
	INDEX (sessionid)
)");

@mysqli_query($db, "CREATE TABLE affiliatepm (
	affiliatepmid int not null auto_increment,
	toaffiliateid int,
	fromaffiliateid int,
	hasbeenread int,
	sentdate varchar(30),
	subject varchar(255),
	message text,
    PRIMARY KEY (affiliatepmid),
	INDEX (toaffiliateid)
)");

@mysqli_query($db, "CREATE TABLE affiliatereferer (
	affiliateid int,
	referer varchar(255),
	clicks int,
	INDEX (affiliateid),
	INDEX (referer)
)");

@mysqli_query($db, "CREATE TABLE affiliatetags (
	affiliatetagid int not null auto_increment,
	fieldname varchar(255),
	tagname varchar(255),
	rows int,
    PRIMARY KEY (affiliatetagid)
)");

@mysqli_query($db, "CREATE TABLE affiliatetaginfo (
    affiliateid int not null,
	affiliatetagid int not null,
	value text,
	INDEX (affiliateid),
	INDEX (affiliatetagid)
)");

@mysqli_query($db, "CREATE TABLE pendingaffiliate (
	user varchar(50),
	password varchar(50),
	business varchar(50),
    firstname varchar(50),
	lastname varchar(50),
    email varchar(50),
	paypalid varchar(50),
    address varchar(50),
    state varchar(50),
    zip varchar(10),
    city varchar(30),
	country varchar(30),
    url varchar(255),
    phone varchar(20),
	referedby int,
	extrainfo text,
	INDEX (password)
)");

@mysqli_query($db, "CREATE TABLE user (
    userid int not null auto_increment,
	admin int default 0,
	username varchar(30),
	password varchar(64),
	passwordreset varchar(64),
	sessionid varchar(50),
	ip varchar(15),
	activity varchar(30),
	loginlock varchar(30),
	licensekey varchar(30),
	licensecheck varchar(10),
	modules varchar(30),
	shopname varchar(50),
	shopdescription text,
	url varchar(255),
	businesstype varchar(15),
    firstname varchar(50),
	lastname varchar(50),
    email varchar(50),
    address varchar(50),
    state varchar(50),
    zip varchar(10),
    city varchar(30),
	country varchar(30),
    phone varchar(20),
	paymentdetails varchar(255),
	commissionlevel varchar(5),
	mallmode varchar(15),
	requestpayment int,
	theme varchar(30),
	pageheader text,
	pagefooter text,
	metakeywords text,
	metadescription text,
	bgcolor varchar(7),
	textcolor varchar(7),
	linkcolor varchar(7),
	formsbgcolor varchar(7),
	formstextcolor varchar(7),
	itembordercolor varchar(7),
	itembgcolor varchar(7),
	itemtextcolor varchar(7),
	categorycolor varchar(7),
	categorytextcolor varchar(7),
	selectedcategory varchar(7),
	selectedcategorytext varchar(7),
	font varchar(30),
	alertcolor varchar(7),
	catalogheader varchar(7),
	catalogheadertext varchar(7),
	formsbordercolor varchar(7),
	itemborderwidth int,
	fontsize1 int,
	fontsize2 int,
	fontsize3 int,
	tablesize1 int,
	tablesize2 int,
	movelock int default 0,
	htmllock int default 0,
	PRIMARY KEY (userid),
	INDEX (sessionid),
	INDEX (username)
)");

@mysqli_query($db, "CREATE TABLE pendingorders (
    orderid varchar(100),
	products text,
	date varchar(30),
	amount varchar(15),
	description blob,
	firstname varchar(50),
	lastname varchar(50),
	email varchar(50),
	address varchar(50),
	zip varchar(10),
	city varchar(30),
	state varchar(30),
	country varchar(30),
	phone varchar(20),
	affiliateid int,
	PRIMARY KEY (orderid)
)");

@mysqli_query($db, "CREATE TABLE qtypricelevels (
  levelid int auto_increment not null,
  levelprice decimal(8,2),
  levelquantity int,
  customerlevel int default 0,
  productid int,
  PRIMARY KEY (levelid),
  INDEX (productid)
)");

@mysqli_query($db, "CREATE TABLE orders (
	customerid int,
    orderid int not null auto_increment,
	invoiceid int,
	purchaseorder varchar(40),
	reference varchar(40),
	userid varchar(255),
	payoptionid int,
	remoteorderid varchar(100),
	products text not null,
	productprices varchar(255),
	paidproductprices varchar(255),
	productdiscounts varchar(255),
	storediscount int,
	description text,
	tempdate varchar(30),
	date varchar(30),
	paid varchar(30),
	billdate varchar(30),
	duedate varchar(30),
	price decimal(10,2),
	pricelevel int,
	tax varchar(30),
	shipping varchar(15),
	discount varchar(15),
	ip varchar(15),
	password varchar(15),
	telesigncode varchar(4),
	language varchar(2),
	comment blob,
	returnurl varchar(255),
	allowemail int,
	source varchar(15),
	vendors varchar(255),
	shipped varchar(30),
	wholesale int,
	affiliateid varchar(255),
	partyid int,
	referral varchar(8),
	virtualcash decimal(10,2),
	recurringfee decimal(10,2),
	recurringorder int,
	originalorderid int,
	status varchar(255),
	PRIMARY KEY (orderid),
	INDEX (customerid),
	INDEX (date)
)");

@mysqli_query($db, "CREATE TABLE orderrequests (
    requestid int not null auto_increment,
    orderid int,
    date varchar(30),
    PRIMARY KEY (requestid),
    INDEX (orderid),
    INDEX (date)
)");

@mysqli_query($db, "CREATE TABLE paymentinfo (
    orderid int,
	payoptionid int,
	cardtype varchar(15),
	cardnumber blob,
	expdate blob,
	seccode blob,
	INDEX (orderid),
	INDEX (payoptionid)
)");

@mysqli_query($db, "CREATE TABLE orderaffiliate (
	affiliateid int,
	orderid int,
	paid varchar(30),
	paymethod varchar(30),
	secondtier int,
	commission varchar(15),
	INDEX (affiliateid),
	INDEX (orderid)
)");

@mysqli_query($db, "CREATE TABLE pendingorderaff (
	affiliateid int,
	orderid int,
	secondtier int,
	commission varchar(15),
	INDEX (affiliateid),
	INDEX (orderid)
)");

@mysqli_query($db, "CREATE TABLE payoptions (
	payoptionid int not null auto_increment,
	userid int,
	ordernumber int,
	emerchantonly int,
	retailonly int,
	wholesaleonly int,
	gateway varchar(30),
	name varchar(30),
	merchantid varchar(100),
	secret varchar(255),
	transactionkey varchar(100),
	paypalid varchar(100),
	logourl varchar(255),
	vspartner varchar(30),
	pageid int,
	testmode int,
	autodelivery int,
	deliverpending int,
	smspayment int,
	telesign int,
	bgcolor varchar(10),
	bgurl varchar(255),
	description blob,
	orderpagetext blob,
	thankyoutext blob,
	fee decimal(8,2),
	initialperiod varchar(30),
	recurringperiod varchar(30),
	rebills int,
	PRIMARY KEY (payoptionid),
	INDEX (gateway)
)");

@mysqli_query($db, "INSERT INTO payoptions (userid,gateway,name,description,thankyoutext) VALUES ('1','manual','Send a check','Sample manual payment option. Modify this payment option on the page Configuration->Payment in your AShop administration panel.','<h4>Thank you for your order!</h4><p>A store receipt has been sent to the e-mail address that you entered in the payment form. Depending on how busy the mail server is, it may take 1 to 15 minutes to arrive at your mailbox. If you purchased downloadable products, the receipt will include a password and link to the download area. Use the e-mail address that you entered in the payment form and the password from the receipt to access the downloadable products.</p>
<p>If you have any questions you are welcome to contact us at:<br>
phone: 555-555555<br>
email: you@yourdomain.com<br>
mail: 1234 Yourstreet, Yourtown</p>')");

@mysqli_query($db, "CREATE TABLE formfields (
  formfieldid int auto_increment not null,
  payoptionid int,
  label varchar(30),
  name varchar(30),
  size int,
  rows int,
  required int,
  PRIMARY KEY (formfieldid),
  INDEX (payoptionid),
  INDEX (name)
)");

@mysqli_query($db, "CREATE TABLE fulfiloptions (
	fulfiloptionid int not null auto_increment,
	method varchar(30),
	name varchar(30),
	userid varchar(100),
	password varchar(100),
	email varchar(100),
	message blob,
	url varchar(255),
	parameternames text,
	extrafields text,
	returnmessage int,
	perorder int,
	discount decimal(8,2),
	discounttype varchar(5),
	ecardimage varchar(50),
	ecardfont varchar(50),
	ecardtextcolor varchar(10),
	ecardtexttop int,
	ecardtextleft int,
	ecardtextright int,
	level int,
	PRIMARY KEY (fulfiloptionid),
	INDEX (method)
)");

@mysqli_query($db, "CREATE TABLE category (
	categoryid int auto_increment not null,
	userid int,
	grandparentcategoryid int,
	parentcategoryid int,
	language varchar(3),
	name varchar(100),
	description blob,
	ordernumber int,
	memberclone int,
	productlayout int,
	PRIMARY KEY (categoryid),
	INDEX (name),
	INDEX (grandparentcategoryid),
	INDEX (parentcategoryid)
)");

@mysqli_query($db, "INSERT INTO category (userid, language, name, description) VALUES ('1','any','Mobile Devices','')");
@mysqli_query($db, "INSERT INTO category (userid, language, name, description) VALUES ('1','any','TV & Video','')");
@mysqli_query($db, "UPDATE category SET grandparentcategoryid=categoryid, parentcategoryid=categoryid, ordernumber=categoryid");

@mysqli_query($db, "CREATE TABLE menuitem (
	itemid int auto_increment not null,
	userid int,
	parentitemid int,
	language varchar(3),
	caption varchar(100),
	ordernumber int,
	memberclone int,
	url text,
	PRIMARY KEY (itemid),
	INDEX (caption),
	INDEX (language),
	INDEX (parentitemid),
	INDEX (userid)
)");

@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','Home','index.php')");
@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE caption='Home'");
@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','About Us','aboutus.php')");
@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE caption='About Us'");
@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','Terms &amp; Conditions','terms.php')");
@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE caption='Terms &amp; Conditions'");
@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','Affiliates','affiliate/signupform.php')");
$parentitemid = @mysqli_insert_id($db);
@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE itemid='$parentitemid'");
@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url, parentitemid) VALUES ('1','1','any','Sign Up','affiliate/signupform.php','$parentitemid')");
$itemid = @mysqli_insert_id($db);
@mysqli_query($db, "UPDATE menuitem SET ordernumber=itemid WHERE itemid='$itemid'");
@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url, parentitemid) VALUES ('1','1','any','Login','affiliate/login.php','$parentitemid')");
$itemid = @mysqli_insert_id($db);
@mysqli_query($db, "UPDATE menuitem SET ordernumber=itemid WHERE itemid='$itemid'");
@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url) VALUES ('1','1','any','Wholesale','wholesale/signupform.php')");
$parentitemid = @mysqli_insert_id($db);
@mysqli_query($db, "UPDATE menuitem SET parentitemid=itemid, ordernumber=itemid WHERE itemid='$parentitemid'");
@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url, parentitemid) VALUES ('1','1','any','Sign Up','wholesale/signupform.php','$parentitemid')");
$itemid = @mysqli_insert_id($db);
@mysqli_query($db, "UPDATE menuitem SET ordernumber=itemid WHERE itemid='$itemid'");
@mysqli_query($db, "INSERT INTO menuitem (userid, memberclone, language, caption, url, parentitemid) VALUES ('1','1','any','Login','wholesale/login.php','$parentitemid')");
$itemid = @mysqli_insert_id($db);
@mysqli_query($db, "UPDATE menuitem SET ordernumber=itemid WHERE itemid='$itemid'");

@mysqli_query($db, "CREATE TABLE product (
	productid int auto_increment not null,
	copyof int default null,
	userid int,
	vendorid int,
	featured int,
	qtylimit int,
	qtytlimit int,
	inventory int,
	useinventory int,
	lowlimit int,
	skucode varchar(25),
	cost varchar(15),
	recurringprice decimal(8,2),
	recurringperiod varchar(30),
	avail varchar(30),
	billtemplate int,
	inmainshop int,
	name varchar(100),
	active int,
	wholesaleactive int,
	manufacturer varchar(255),
	detailsurl varchar(255),
	receipttext varchar(255),
	description text,
	longdescription text,
	licensetext text,
	metakeywords varchar(255),
	metadescription varchar(255),
	price decimal(8,2),
	pricetext text,
	qtytype int,
	qtycategory int,
	wholesaleprice decimal(8,2),
	wspricelevels varchar(255),
	ebayid varchar(30),
	shipping varchar(255),
	intshipping varchar(255),
	countryshipping varchar(500),
	subscriptiondir varchar(255),
	prodtype varchar(15),
	protectedurl text,
	affiliatecom varchar(50),
	affiliatecom2 varchar(50),
	affiliatetiercom varchar(50),
	affiliatewscom varchar(50),
	affiliaterepeatcommission int,
	ordernumber int,
	listmessengergroup int,
	listmaillist int,
	phpbbgroup int,
	arpresponder int,
	arpreachresponder int,
	infresponder int,
	infresponderoff int,
	fitlistresponder int,
	iemlist int,
	mailchimplist varchar(20),
	autoresponder varchar(20),
	autoresponderoff varchar(20),
	taxable int,
	length int,
	fulfilment int,
	weight varchar(20),
	ffproductid text,
	fflabelnumber varchar(100),
	ffpackagenumber varchar(100),
	ffparamnames text,
	exportedtosaasu int default 0,
	language varchar(3),
	activatereviews int,
	activatesocialnetworking int,
	activaterecommended int,
	PRIMARY KEY (productid),
	INDEX (skucode),
	INDEX (ebayid),
	INDEX (detailsurl)
)");

@mysqli_query($db, "CREATE TABLE membershiplog (
	loginitemid int auto_increment not null,
	productid int,
	customerid int,
	logindate varchar(30),
	ipnumber varchar(15),
	email varchar(50),
	password varchar(30),
	remainingdays int,
	PRIMARY KEY (loginitemid),
	INDEX (productid),
	INDEX (customerid)
)");

@mysqli_query($db, "CREATE TABLE reviews (
	reviewid int auto_increment not null,
	productid int, 
	customerid int, 
	rating int(1), 
	time varchar(32), 
	comment text,
	PRIMARY KEY (reviewid),
	INDEX (productid),
	INDEX (customerid)
)");

@mysqli_query($db, "CREATE TABLE mailing (
	mailingid int auto_increment not null,
	logfile varchar(50),
	type varchar(15),
	format varchar(5),
	subject text,
	message text,
	sessionkey varchar(30),
	timestamp varchar(30),
	paused int,
	PRIMARY KEY (mailingid)
)");

@mysqli_query($db, "CREATE TABLE maillog (
	mailingid int,
	recipientid int4,
	email varchar(100),
	INDEX (mailingid)
)");

@mysqli_query($db, "CREATE TABLE notification (
	notificationid int auto_increment not null,
	type varchar(15),
	message text,
	PRIMARY KEY (notificationid)
)");

@mysqli_query($db, "CREATE TABLE export (
	exportid int auto_increment not null,
	saasuassetaccount varchar(20),
	saasuincomeaccount varchar(20),
	saasucosaccount varchar(20),
	saasupurchasetaxcode varchar(20),
	saasusalestaxcode varchar(20),
	numberofitems int,
	PRIMARY KEY (exportid)
)");

@mysqli_query($db, "INSERT INTO product (userid, name, active, wholesaleactive, detailsurl, manufacturer, description, longdescription, price, wholesaleprice, featured) VALUES ('1','Apple iPad 32 GB Wifi','1','1','$url/catalog/Apple_iPad_32_GB_Wifi.html','Apple','','<p><strong>Stunning Retina display.</strong></p><p>Whether you&rsquo;re enjoying photos, shopping, or building a presentation, the vivid 9.7-inch Retina display has the detail and size to really bring them to&nbsp;life.</p><p><strong>Fast, fluid performance.</strong></p><p>The 64-bit A9&nbsp;chip delivers performance that makes every app feel fast and fluid. Explore rich learning apps, play graphics-intensive games, or even use two apps at once. All while enjoying up to 10&nbsp;hours of battery life.</p><p><strong>Apps for everything.</strong></p><p>Every iPad app has been designed specifically for the power and scale of iPad. And with so many great iPad apps in the App Store, there&rsquo;s sure to be an app for whatever you love to&nbsp;do.</p><p><strong>iPad. Turned up to 11.</strong></p><p>iOS 11 brings iPad to life like never before. New features and capabilities let you get more done, more quickly and easily, making it a phenomenally powerful and personal&nbsp;experience.</p><p><strong>Advanced security at your fingertip.</strong></p><p>Your fingerprint is the perfect password because it&rsquo;s unique and always with you. Touch ID lets you unlock your iPad instantly and secure private data in apps. You can also use it to make purchases with Apple Pay in apps and websites.</p>','329.00','250.00','1')");
@mysqli_query($db, "INSERT INTO product (userid, name, active, wholesaleactive, detailsurl, manufacturer, description, longdescription, price, wholesaleprice, featured) VALUES ('1','Samsung Galaxy S8 Black','1','1','$url/catalog/samsung_galaxy_s8.html','Samsung','','<p><strong>Infinitely amazing</strong></p>
<p><strong>The world&#39;s first Infinity Display.</strong></p><p>The Galaxy S8&rsquo;s expansive display stretches from edge to edge, giving you the most amount of screen in the least amount of space. And the Galaxy S8+ is even more expansive.</p><p><strong>Catch every shot.</strong></p><p>The Galaxy S8&#39;s camera still takes amazing photos in low light, and now has an enhanced front-facing camera so you can take better, clearer selfies.&nbsp;</p><p><strong>Unlock with a look.</strong></p><p>Featuring iris scanning for enhanced security, face recognition for unlocking your phone right away, and defense-grade security that stands guard around the clock.</p><p><strong>Meet Bixby</strong></p><p>Bixby is the smarter way to get things done. Say a command, identify what you&#39;re looking at or set a reminder just by pressing a button. Whatever you need, Bixby it.</p><p><strong>Create and Explore in 360.</strong></p><p>A whole new VR experience with completely intuitive responses on the in-hand controller, and a Gear 360 that shoots in 4k and fits in your pocket.</p><p><strong>Do even more.</strong></p><p>Unlock new possibilities, from your wallet to your home, with apps and services designed to help you live better.</p>','700.00','600.00','2')");
@mysqli_query($db, "INSERT INTO product (userid, name, active, wholesaleactive, detailsurl, manufacturer, description, longdescription, price, wholesaleprice, featured) VALUES ('1','LG 49&quot; ULTRA HD 4K TV','1','1','$url/catalog/lg_tv_49UJ701V.html','LG','','<p><strong>A vibrant and vivid picture from any angle</strong></p><p>Our latest Ultra HD innovation is built into the unique IPS 4K panel meaning your entertainment is viewable from any angle without distortion</p><p><strong>HDR Effect &ndash; new heights of picture quality</strong></p><p>Make the ordinary, extraordinary. Advanced picture processing produces an HDR effect for standard dynamic range content. Lift your ordinary entertainment to a new level of colour and contrast.</p><p><strong>Ultra Luminance &ndash; The science of light control</strong></p><p>Enjoy brighter whites and darker blacks thanks to local dimming technology which lifts the brightest scenes to brilliant new levels and the darkest shadows to life.</p><p><strong>Scale new heights of resolution</strong></p><p>Take your entertainment to a new level with LG&rsquo;s 4K Upscaler and HEVC decoder for 4K streaming.</p>
<p><strong>Immersive sound from audio experts</strong></p><p>With years of experience in high-quality sound harman/kardon&reg; are the perfect partners to design your speaker system. Now you can enjoy a whole new level of audio immersion.</p>','645.00','500.00','3')");
@mysqli_query($db, "INSERT INTO product (name,description,prodtype,userid,language) VALUES ('AShopFirstPage','<p>Welcome to a brand new AShop!</p>','content','1','any')");
@mysqli_query($db, "INSERT INTO product (name,description,prodtype,userid,language) VALUES ('AShopAboutPage','<p>Your Shop Name is a company that does what you put in here instead of this sample text. Some sample text about how long you have been in business, where you are located, why the visitor should choose to buy from your company.</p>
<p>Another paragraph describing your line of products. Let the visitor know the advantages of your product(s).</p>','content','1','any')");
@mysqli_query($db, "INSERT INTO product (name,description,prodtype,userid,language) VALUES ('AShopTermsPage','PLEASE READ THESE TERMS CAREFULLY, AND PRINT AND KEEP A COPY OF THEM FOR YOUR REFERENCE.<br />
<br />
1. GENERAL TERMS<br />
<br />
When you place an order with us, you are making an offer to buy goods.  We will send you an e-mail to confirm that we have received your order.  Once we have checked the price and availability of the goods, we will e-mail you again to confirm that we accept your order, and that a contract has been made between us.  We will not take payment from you until we have accepted your order.  In the unlikely event that the goods are no longer available, or that we have made a pricing mistake, we will advise you of this.  You will not receive an e-mail confirming acceptance of your order, and there will be no contract between us.  If the goods you order are not available, we may supply you with substitute goods.  If you decide not to accept the substitute goods, you will not have to pay to return them to us.<br />
<br />
2. DELIVERY<br />
<br />
If the goods are lost or damaged in transit, please let us know promptly, so that we can make a claim against the carriers. We will offer you the choice of a replacement or a full refund.<br />
<br />
3. CANCELLATION AND RETURNS<br />
<br />
This cancellation policy does not affect your rights when we are at fault - for example, if goods are faulty or misdescribed.<br />
You can cancel your contract before delivery, and up to 7 working days after delivery.  To do this, please e-mail us or write to us.<br />
We will refund your money, including the original postage charges, within 30 days.  You do not have to give any reason for cancellation.  However, a brief explanation will help us to improve the service we offer to customers in the future.<br />
If you cancel, you must return the goods to us at your own expense.  You are responsible for the risk of loss or damage when you return goods, so you should take out enough postal insurance to cover their value.<br />
If you fail to do return the goods, we will collect them, and we will charge you the direct cost of collection.  If you fail to take reasonable care of the goods before they are returned to us, and this results in damage or deterioration, we will charge you for the reduction in value.<br />
<br />
4. FAULTY GOODS<br />
<br />
If there is a problem with the goods, please contact us to discuss the matter further.  If the goods are found to be faulty within a reasonable time after delivery, you may reject them and claim a full refund, plus compensation for your losses.  If a fault is found later on, or if you delay in making a complaint, you will still be entitled to a repair or, if a repair cannot be done without causing you significant inconvenience, a replacement.  If a replacement is not available, you may be able to claim a part or full refund of your money, plus compensation for any other losses incurred.<br />
<br />
5. CHANGES TO THESE TERMS<br />
These terms apply to your order.  We may change our terms and conditions at any time, so please do not assume that the same terms will apply to future orders.<br /><br /><br />','content','1','any')");
@mysqli_query($db, "INSERT INTO product (name,description,prodtype,userid,language) VALUES ('AShopPrivacyPage','<br />
<div class=\"ashoppageheadertext2\" align=\"center\"><span style=\"font-size: 18px;\"><b>Privacy Policy</b></span></div><br /><span class=\"maintext\">
Your privacy is of the highest importance to us, and we promise never to release your personal details to any outside company for mailing or marketing purposes.<br />
<br />
Our payment processor collects the information needed to verify and authorise your payment and to process your order. All such organisations are under strict obligation to keep your personal information private and secure.<br />
<br />
<br />
<strong>COOKIES</strong><br />
<br />
Cookies are tiny text files stored on your computer when you visit certain web pages. We use cookies to keep track of what you have in your basket and to let you login as a customer and manage your order history. We also use cookies to check if you were refered by one of our affiliates and give them credit.
<br /><br />
To order products on this website, you need to have cookies enabled. If you don't wish to enable cookies, you'll still be able to browse the site and use it for research purposes.
<br /><br />
Please note that cookies can't harm your computer. Most web browsers have cookies enabled by default. If you still wish to prevent cookies from being stored, you can do this by changing the settings of your web browser.<br /><br /><br />
</span>','content','1','any')");
@mysqli_query($db, "INSERT INTO product (name,detailsurl,prodtype,language,userid) VALUES ('AShop Software','http://www.ashopsoftware.com','content','any','1')");
@mysqli_query($db, "INSERT INTO product (name,detailsurl,prodtype,language,userid) VALUES ('AShop Forum','http://forum.ashopsoftware.com','content','any','1')");
@mysqli_query($db, "INSERT INTO product (name,detailsurl,prodtype,language,userid) VALUES ('Autoresponder Service','http://www.autoresponder-service.com','content','any','1')");
@mysqli_query($db, "INSERT INTO product (name,detailsurl,prodtype,language,userid) VALUES ('Shopping Cart Free Trial','http://www.ashopsoftware.com/dlcounter/trialform.html','content','any','1')");

@mysqli_query($db, "UPDATE product SET ordernumber=productid");

@mysqli_query($db, "CREATE TABLE productinventory (
	productid int not null,
    type varchar(30),
	skucode varchar(25),
	inventory int,
	qtylimit int,
	qtytlimit int,
	exportedtosaasu int default 0,
	INDEX (productid),
	INDEX (skucode)
)");

@mysqli_query($db, "CREATE TABLE productfiles (
	id int auto_increment not null,
    fileid int,
	ordernumber int,
	productid int,
	storage int,
	name varchar(100),
	description text,
	tags varchar(255),
	filename varchar(255),
	url text,
	PRIMARY KEY (id),
	INDEX (fileid)
)");

@mysqli_query($db, "CREATE TABLE productpreviewfiles (
	fileid int auto_increment not null,
	productid int,
	storage int,
	filename varchar(255),
	url text,
	PRIMARY KEY (fileid),
	INDEX (productid)
)");

@mysqli_query($db, "CREATE TABLE orderdownloads (
	orderid int,
    fileid int,
	downloads int,
	INDEX (orderid),
	INDEX (fileid)
)");

@mysqli_query($db, "CREATE TABLE downloadslog (
	orderid int,
    fileid int,
	date varchar(30),
	ip varchar(15),
	INDEX (orderid),
	INDEX (fileid)
)");

@mysqli_query($db, "CREATE TABLE discount (
    discountid int auto_increment not null,
	productid int,
	code varchar(50),
	value decimal(8,2),
	type varchar(5),
	onetime int,
	affiliate int,
	customerid int4,
	PRIMARY KEY (discountid),
	INDEX (productid),
	INDEX (customerid)
)");

@mysqli_query($db, "CREATE TABLE storediscounts (
    discountid int auto_increment not null,
	code varchar(50),
	value decimal(8,2),
	type varchar(5),
	prerequisite int,
	affiliate int,
	customerid int4,
	categoryid int,
	giftcertificate int,
	used int,
	PRIMARY KEY (discountid),
	INDEX (affiliate),
	INDEX (code),
	INDEX (customerid)
)");

@mysqli_query($db, "CREATE TABLE onetimediscounts (
    discountid int,
	customerid int,
	INDEX (discountid),
	INDEX (customerid)
)");

@mysqli_query($db, "CREATE TABLE updates (
	productid int,
	title varchar(255),
	password varchar(15),
	date varchar(30),
	alloweddays int,
	filename varchar(255),
	INDEX (productid),
	INDEX (password)
)");

@mysqli_query($db, "CREATE TABLE unlockkeys (
	keyid int auto_increment not null,
	productid int,
	orderid int,
	keytext text,
	PRIMARY KEY (keyid),
	INDEX (productid)
)");

@mysqli_query($db, "CREATE TABLE packages (
    packageid int auto_increment not null,
	productid int,
	originzip varchar(10),
	origincountry varchar(30),
    originstate varchar(30),
	weight decimal(8,2),
	freightclass varchar(10),
	PRIMARY KEY (packageid),
	INDEX (productid)
)");

@mysqli_query($db, "CREATE TABLE shipoptions (
  shipoptionid int auto_increment not null,
  description varchar(255),
  fee decimal(8,2),
  shipped varchar(15),
  disableshipping int,
  PRIMARY KEY (shipoptionid)
)");

@mysqli_query($db, "CREATE TABLE shipdiscounts (
  shipdiscountid int auto_increment not null,
  value decimal(8,2),
  quantity int,
  local int,
  shipoptionid int,
  PRIMARY KEY (shipdiscountid),
  INDEX (quantity)
)");

@mysqli_query($db, "CREATE TABLE zipzones (
  zip varchar(10),
  zone int(11),
  zonename varchar(50),
  INDEX (zip),
  INDEX (zonename)
)");

@mysqli_query($db, "CREATE TABLE zonerates (
  productid int(11),
  zone int(11),
  rate double default NULL,
  INDEX (productid),
  INDEX (zone)
 )");

@mysqli_query($db, "CREATE TABLE localtax (
  city varchar(50),
  rate decimal(8,2),
  PRIMARY KEY (city)
 )");

@mysqli_query($db, "CREATE TABLE quantityrates (
  productid int(11),
  quantity int(11),
  rate double default NULL,
  INDEX (productid),
  INDEX (quantity)
)");

@mysqli_query($db, "CREATE TABLE parameters (
    parameterid int auto_increment not null,
	productid int,
	caption varchar(255),
	buybuttons int,
	inputrows int,
	PRIMARY KEY (parameterid),
	INDEX (productid)
)");

@mysqli_query($db, "CREATE TABLE parametervalues (
    valueid int auto_increment not null,
	parameterid int,
	download varchar(10),
	noshipping int,
	notax int,
	nofulfilment int,
	price varchar(255),
	value varchar(255),
	PRIMARY KEY (valueid),
	INDEX (parameterid)
)");

@mysqli_query($db, "CREATE TABLE customparametervalues (
    valueid int auto_increment not null,
	parameterid int,
	value varchar(255),
	timestamp varchar(10),
	PRIMARY KEY (valueid),
	INDEX (parameterid)
)");

@mysqli_query($db, "CREATE TABLE productflags (
    flagid int auto_increment not null,
	name varchar(255),
	PRIMARY KEY (flagid)
)");

@mysqli_query($db, "CREATE TABLE flagvalues (
    flagid int,
	productid int
)");

@mysqli_query($db, "CREATE TABLE productcategory (
	productid int,
	categoryid int,
	INDEX (productid),
	INDEX (categoryid)
)");

@mysqli_query($db, "INSERT INTO productcategory (productid,categoryid) VALUES ('1','1')");
@mysqli_query($db, "INSERT INTO productcategory (productid,categoryid) VALUES ('2','1')");
@mysqli_query($db, "INSERT INTO productcategory (productid,categoryid) VALUES ('3','2')");

@mysqli_query($db, "CREATE TABLE linkcodes (
	linkid int auto_increment not null,
	linkcategoryid int,
	userid int,
	linktext blob,
	filename varchar(255),
	redirect varchar(255),
	alt varchar(255),
	PRIMARY KEY (linkid),
	INDEX (linkcategoryid)
)");

@mysqli_query($db, "CREATE TABLE linkcategories (
	linkcategoryid int auto_increment not null,
	userid int,
	linkcategoryname varchar(100),
	PRIMARY KEY (linkcategoryid)
)");

@mysqli_query($db, "INSERT INTO linkcategories (userid,linkcategoryname) VALUES ('1','Banners')");
@mysqli_query($db, "INSERT INTO linkcategories (userid,linkcategoryname) VALUES ('1','Text Ads')");

@mysqli_query($db, "CREATE TABLE customerblacklist (
	blacklistitemid int auto_increment not null,
	blacklistitem varchar(255),
	PRIMARY KEY (blacklistitemid),
	INDEX (blacklistitem)
)");

@mysqli_query($db, "CREATE TABLE visitcounter (
	id int(7) NOT NULL auto_increment,
	total varchar(255) NOT NULL default '',
	date varchar(255) NOT NULL default '',
	extrafield varchar(255) NOT NULL default '',
	keepcurrent varchar(255) NOT NULL default '',
	extrafield2 varchar(255) NOT NULL default '',
	today varchar(255) NOT NULL default '',
	currenttoday varchar(255) NOT NULL default '',
	installdate varchar(255) NOT NULL default '',
	PRIMARY KEY (id)
)");

@mysqli_query($db, "CREATE TABLE visitcounter_online (
	id int(7) NOT NULL auto_increment,
	ip varchar(255) NOT NULL default '',
	time varchar(255) NOT NULL default '',
	PRIMARY KEY (id),
	INDEX (ip),
	INDEX (time)
)");

@mysqli_query($db, "CREATE TABLE visitcounter_today (
	id int(7) NOT NULL auto_increment,
	ip varchar(255) NOT NULL default '',
	time varchar(255) NOT NULL default '',
	PRIMARY KEY (id),
	INDEX (ip),
	INDEX (time)
)");

@mysqli_query($db, "CREATE TABLE savedcarts (
	cartid int NOT NULL auto_increment,
	customerid int,
	cartname varchar(30),
	productstring text,
	PRIMARY KEY (cartid),
	INDEX (customerid)
)");

@mysqli_query($db, "CREATE TABLE preferences (
	prefid int NOT NULL default '0',
	prefname varchar(30),
	prefvalue text,
	PRIMARY KEY (prefid),
	INDEX (prefname)
)");

@mysqli_query($db, "CREATE TABLE wholesalepaymentinfo (
    orderid int,
	payoptionid int,
	cardtype varchar(15),
	cardnumber blob,
	expdate blob,
	seccode blob,
	firstname varchar(50),
	lastname varchar(50),
	address varchar(50),
	zip varchar(10),
	city varchar(30),
	state varchar(30),
	country varchar(30),
	INDEX (orderid)
)");

@mysqli_query($db, "CREATE TABLE searchstatistics (
    keyword varchar(50),
	date varchar(30),
	INDEX (keyword),
	INDEX (date)
)");

@mysqli_query($db, "CREATE TABLE floatingprice (
	productid int,
	orderid int,
	length int,
	activatetime varchar(50),
	starttime varchar(50),
	startprice decimal(8,2),
	originalstartprice decimal(8,2),
	endprice decimal(8,2),
	priceincrement decimal(8,2),
	bids int,
	bidderid int,
	type varchar(10),
	PRIMARY KEY (productid),
	INDEX (bidderid)
)");

@mysqli_query($db, "CREATE TABLE pricebidder (
	bidderid int NOT NULL auto_increment,
	bidcode varchar(30),
	screenname varchar(15),
	numberofbids int,
	refill int,
	customerid int,
	PRIMARY KEY (bidderid),
	INDEX (bidcode),
	INDEX (customerid)
)");

@mysqli_query($db, "CREATE TABLE relatedproducts (
	relationid int NOT NULL auto_increment,
	productid int,
	relatedproductid int,
	priority int,
	PRIMARY KEY (relationid),
	INDEX (productid)
)");

@mysqli_query($db, "CREATE TABLE autoresponders (
	responderid bigint,
	profileid bigint,
	name varchar(255),
	INDEX (responderid)
)");

@mysqli_query($db, "CREATE TABLE party (
    partyid int not null auto_increment,
	customerid int,
    affiliateid int,
	description varchar(500),
	location varchar(500),
	date varchar(30),
	approved int,
	ended int,
	PRIMARY KEY (partyid),
	INDEX (customerid),
	INDEX (affiliateid),
	INDEX (approved)
)");

@mysqli_query($db, "CREATE TABLE partyrewards (
    rewardid int auto_increment not null,
	result decimal(8,2),
	value int,
	PRIMARY KEY (rewardid),
	INDEX (result)
)");

@mysqli_query($db, "CREATE TABLE partyinvitations (
    invitationid int auto_increment not null,
	partyid int,
	email varchar(50),
	date varchar(30),
	response varchar(10),
	PRIMARY KEY (invitationid),
	INDEX (email),
	INDEX (partyid)
)");

// Initiate password hashing...
include "includes/PasswordHash.php";
$passhasher = new PasswordHash(8, FALSE);
$passhash = $passhasher->HashPassword("ashopadmin");

// Check if AWS SDK is available...
if (file_exists("$ashoppath/includes/aws/aws-config.php")) {
	// Generate a unique bucket directory name...
	if ( ! function_exists('makeBucketDir') ) {
		function makeBucketDir() {
			$alphaNum = array(2, 3, 4, 5, 6, 7, 8, 9, a, b, c, d, e, f, g, h, i, j, k, m, n, p, q, r, s, t, u, v, w, x, y, z);
			srand ((double) microtime() * 1000000);
			$bucketDirLength = "12"; // this sets the limit on how long the password is.
			for($i = 1; $i <=$bucketDirLength; $i++) {
				$newBucketDir .= $alphaNum[(rand(0,31))];
			}
			return ($newBucketDir);
		}
	}
	$awsdirectory = makeBucketDir();
} else $awsdirectory = "";

// Store default preferences...
$visitcounterinstalldate = date("d.m.Y", time()+$timezoneoffset);
@mysqli_query($db, "INSERT INTO visitcounter VALUES (1, '0', '$visitcounterinstalldate', 'ashopadmin', '300', '-', '1', '86400', '$visitcounterinstalldate')");
@mysqli_query($db, "INSERT INTO user (userid, username, password) VALUES ('1', 'ashopadmin', '$passhash')");
@mysqli_query($db, "INSERT INTO linkcodes (linkid, linktext, filename, redirect, alt) VALUES (1, '&lt;a href=\"%affiliatelink%\"&gt;Join the affiliate program at $ashopname!&lt;/a&gt;', '', '$url/affiliate/signupform.php', '')");

@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('1', 'ashopname', 'Your Shop Name')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('2', 'ashopphone', '555-555555')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('3', 'ashopemail', 'you@yourdomain.com')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('4', 'ashopaddress', '1234 Yourstreet, Yourtown')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('5', 'ashopurl', '$url')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('6', 'ashoppath', '{$ashoppath}')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('7', 'timezoneoffset', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('8', 'shoppingcart', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('9', 'confirmaddtocart', 'no')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('10', 'alloweddownloaddays', '3')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('11', 'alloweddownloads', '3')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('12', 'orderpagelink', '$url')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('13', 'randomkeycodes', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('14', 'affiliateinfo', 'Join our affiliate sales program and earn cash for each sale that clicks through from your link. This is an easy way to make money while offering a useful product to your website visitors or newsletter subscribers!')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('15', 'affiliaterecipient', 'you@yourdomain.com')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('16', 'affiliatepercent', '10')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('17', 'secondtieractivated', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('18', 'secondtierpercent', '3')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('19', 'affiliateredirect', '$url')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('20', 'bgcolor', '#FFFFFF')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('21', 'textcolor', '#000000')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('22', 'linkcolor', '#000000')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('23', 'formsbgcolor', '#FFFFFF')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('24', 'formstextcolor', '#000000')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('25', 'categorytextcolor', '#000000')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('26', 'itembordercolor', '#D0D0D0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('27', 'itemborderwidth', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('28', 'itembgcolor', '#FFFFFF')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('29', 'categorycolor', '#E0E0E0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('30', 'selectedcategory', '#F0F0F0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('31', 'font', 'Arial, Helvetica, sans-serif')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('32', 'thumbnailwidth', '342')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('33', 'imagewidth', '342')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('34', 'taxstate', 'AL')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('35', 'taxpercentage', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('36', 'shippingtax', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('37', 'shipfromcountry', 'US')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('38', 'handlinglocal', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('39', 'handlingint', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('40', 'listmessengerpath', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('41', 'listmailurl', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('42', 'phpbbpath', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('43', 'papluspath', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('44', 'arpluspath', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('45', 'ashopcurrency', 'usd')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('46', 'requestvat', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('47', 'wholesalecatalog', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('48', 'discountlevel1', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('49', 'discountlevel2', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('50', 'discountlevel3', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('51', 'salestaxtype', 'ussalestax')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('52', 'pstpercentage', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('53', 'vatorigincountry', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('54', 'enablecustomerlogin', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('55', 'requirepaypalid', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('56', 'localshipping', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('57', 'ashoptheme', 'default')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('58', 'phpbburl', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('59', 'itemtextcolor', '#000000')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('60', 'ashopaffiliateid', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('61', 'usecondensedlayout', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('62', 'ashopsurl', '$secureurl')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('63', 'memberpercent', '90')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('64', 'displayitems', '20')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('65', 'affiliatepercent2', '20')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('66', 'secondtierpercent2', '6')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('67', 'receiptformat', 'html')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('68', 'ashopversion', '$version')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('69', 'fontsize1', '10')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('70', 'fontsize2', '12')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('71', 'fontsize3', '14')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('72', 'defaultlanguage', 'en')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('73', 'membershops', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('74', 'telesignid', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('75', 'memberprodmanage', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('76', 'selectedcategorytext', '#000000')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('77', 'probotpath', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('78', 'ashopspath', '$path')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('79', 'memberactivate', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('80', 'memberproducttemplate', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('81', 'keeplargeprodimg', 'true')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('82', 'storeshippingmethod', 'none')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('83', 'storeshippingmaxweight', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('84', 'storeshippingfromzip', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('85', 'storeshippingfromstate', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('86', 'storeshippingbasecharge', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('87', 'storeshippingperpound', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('88', 'upsserviceusa', '03')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('89', 'upsserviceworld', '07')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('90', 'upspackagetype', '02')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('91', 'upspickuptype', '01')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('92', 'upspackagetypeworld', '02')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('93', 'fedexserviceusa', '92')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('94', 'fedexserviceworld', '92')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('95', 'fedexpackagetype', '01')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('96', 'shippingmethod', 'custom')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('97', 'fedexpackagetypeworld', '01')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('98', 'dmshowcustomers', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('99', 'collectcustomerinfo', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('100', 'upscountry', 'US')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('101', 'upsdropofftype', '2')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('102', 'upsdailypickup', 'yes')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('103', 'hstpercentage', 'AB:5:0:0|BC:12:0:0|MB:5:7:0|NB:13:0:0|NL:13:0:0|NT:5:0:0|NS:15:0:0|NU:5:0:0|ON:13:0:0|PE:5:10:1|QC:5:8.5:1|SK:5:5:1|YT:5:0:0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('104', 'tablesize1', '700')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('105', 'tablesize2', '600')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('106', 'displaywithtax', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('107', 'upsservicecanusa', '11')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('108', 'shipoptionstype', 'custom')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('109', 'formsbordercolor', '#D0D0D0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('110', 'fedexaccount', '256711745')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('111', 'fedexmeternumber', '1022899')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('112', 'upsaccesskey', 'EB91030B94D70E64')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('113', 'downloadsavedialogue', 'on')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('114', 'alertcolor', '#FF0000')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('115', 'showfileinfo', 'true')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('116', 'telesignauthid', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('117', 'itemsperrow', '3')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('118', 'topformlayout', '2')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('119', 'taxpercentage2', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('120', 'catalogheader', '#909090')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('121', 'catalogheadertext', '#FFFFFF')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('122', 'upsellitems', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('123', 'infinitypath', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('124', 'showimagesincart', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('125', 'advancedmallmode', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('126', 'affiliateconfirm', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('127', 'fitlisturl', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('128', 'ashopsortorder', 'ASC')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('129', 'autoapprovemembers', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('130', 'requestabn', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('131', 'freeshippinglimit', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('132', 'saasuwsaccesskey', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('133', 'saasufileid', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('134', 'saasubankaccountid', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('135', 'saasutaxcode', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('136', 'twitteruser', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('137', 'twitterpass', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('138', 'cmsurl', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('139', 'hideemptycategories', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('140', 'customerconfirm', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('141', 'cartlistoncheckout', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('142', 'freeshippingonlylocal', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('143', 'autoresponderid', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('144', 'activateautoresponder', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('145', 'ashopdate', '2010-03-18')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('146', 'newsresponderid', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('147', 'pappath', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('148', 'seourls', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('149', 'priceshipping', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('150', 'iemurl', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('151', 'iemuser', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('152', 'iemtoken', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('153', 'readannouncement', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('154', 'discountoncheckout', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('155', 'discountmessage', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('156', 'maxaffiliatetiers', '10')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('157', 'upgradeaffiliate', '50')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('158', 'activateleads', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('159', 'memberuploadsize', '5')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('160', 'enableproductcount', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('161', 'virtualcashpercent', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('162', 'wholesaleaffiliate', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('163', 'facebookappid', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('164', 'facebooksecret', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('165', 'ashopmetakeywords', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('166', 'ashopmetadescription', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('167', 'ashopnewsfeed', '$url/ashop.rss.php?cat=pageslinks')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('168', 'decimalchar', '.')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('169', 'thousandchar', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('170', 'weightshipping', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('171', 'pricelevels', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('172', 'wordpresspath', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('173', 'uspsuserid', '371MILLE2051')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('174', 'uspsserviceusa', 'PRIORITY')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('175', 'uspsserviceworld', 'Priority Mail International')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('176', 'uspsmachinable', 'True')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('177', 'uspssize', 'REGULAR')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('178', 'uspscontainer', 'RECTANGULAR')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('179', 'customermustregister', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('180', 'mailertype', 'mailfunction')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('181', 'mailerserver', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('182', 'mailerport', '25')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('183', 'maileruser', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('184', 'mailerpass', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('185', 'wholesalepercent', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('186', 'displaywswithtax', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('187', 'memberpayoptions', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('188', 'referrallength', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('189', 'aweberauthcode', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('190', 'shoppingmallinfo', 'This service will provide you with a plug and play shopping cart for your business. You can sell and securely deliver digital goods and/or shipped goods without the need for a merchant account. We will handle the payment from your customer and send it to you. Our fee is currently 10% of the price of your products. Your application will be reviewed by a live person before your membership is activated. Once approved, a password and link to your shop will be emailed to you.')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('191', 'mailchimpapikey', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('192', 'maintenancemessage', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('193', 'eucookiecheck', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('198', 'includesubcategories', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('199', 'minfraudkey', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('200', 'minfraudthreshold', '10')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('201', 'minfraudgeoipkey', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('205', 'fedexkey', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('206', 'fedexpassword', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('207', 'showdecimals', '2')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('208', 'numberoffeatures', '3')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('209', 'massmailthrottle', '200')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('210', 'arpreachpath', '')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('211', 'awsdirectory', '$awsdirectory')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('212', 'enablepartyplanner', '1')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('213', 'homebannerurl1', 'index.php')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('214', 'homebannerurl2', 'index.php')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('215', 'homebannerurl3', 'index.php')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('216', 'enablemall', '0')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('217', 'slogan', 'Catchy company slogan goes here.')");
@mysqli_query($db, "INSERT INTO preferences (prefid, prefname, prefvalue) VALUES ('218', 'mapembed', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d4797.836151621091!2d-73.98005786281355!3d40.75218483738816!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sapple+store!5e0!3m2!1ssv!2sus!4v1453158441009\" width=\"95%\" height=\"300\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>')");

// Show the next step in the installation guide...
header("Location: install.php");
?>